// Quotation Types (manual - not in generated database.ts)
export interface QuotationRow {
  id: string;
  quotation_number: string;
  ticket_id: string | null;
  // Customer
  customer_name: string;
  customer_company: string | null;
  customer_email: string | null;
  customer_phone: string | null;
  customer_whatsapp: string | null;
  customer_address: string | null;
  // Cargo
  cargo_description: string;
  cargo_category: string | null;
  quantity: number | null;
  unit_of_measure: string | null;
  weight_kg: number | null;
  volume_cbm: number | null;
  hs_code: string | null;
  // Shipment
  shipment_type: string | null;
  incoterm: string | null;
  fleet_type: string | null;
  fleet_custom: string | null;
  container_type: string | null;
  container_quantity: number | null;
  // Origin
  origin_address: string | null;
  origin_city: string | null;
  origin_country: string | null;
  origin_port: string | null;
  // Destination
  destination_address: string | null;
  destination_city: string | null;
  destination_country: string | null;
  destination_port: string | null;
  // Cost
  cost_type: string;
  base_cost: number | null;
  cost_details: unknown | null;
  margin_type: string | null;
  margin_value: number | null;
  selling_rate: number | null;
  currency: string | null;
  // Terms
  validity_days: number | null;
  valid_until: string | null;
  payment_terms: string | null;
  included_services: string | null;
  excluded_services: string | null;
  terms_conditions: string | null;
  additional_notes: string | null;
  // Status
  status: string | null;
  sent_via: string | null;
  sent_at: string | null;
  pdf_url: string | null;
  // Audit
  created_by: string;
  created_at: string;
  updated_at: string;
  // Creator (joined from users table)
  creator?: {
    id: string;
    full_name: string;
    email: string;
    department_id: string | null;
  } | null;
}

export interface QuotationInsert {
  id?: string;
  quotation_number?: string;
  ticket_id?: string | null;
  customer_name: string;
  customer_company?: string | null;
  customer_email?: string | null;
  customer_phone?: string | null;
  customer_whatsapp?: string | null;
  customer_address?: string | null;
  cargo_description: string;
  cargo_category?: string | null;
  quantity?: number | null;
  unit_of_measure?: string | null;
  weight_kg?: number | null;
  volume_cbm?: number | null;
  hs_code?: string | null;
  shipment_type?: string | null;
  incoterm?: string | null;
  fleet_type?: string | null;
  fleet_custom?: string | null;
  container_type?: string | null;
  container_quantity?: number | null;
  origin_address?: string | null;
  origin_city?: string | null;
  origin_country?: string | null;
  origin_port?: string | null;
  destination_address?: string | null;
  destination_city?: string | null;
  destination_country?: string | null;
  destination_port?: string | null;
  cost_type: string;
  base_cost?: number | null;
  cost_details?: unknown | null;
  margin_type?: string | null;
  margin_value?: number | null;
  selling_rate?: number | null;
  currency?: string | null;
  validity_days?: number | null;
  valid_until?: string | null;
  payment_terms?: string | null;
  included_services?: string | null;
  excluded_services?: string | null;
  terms_conditions?: string | null;
  additional_notes?: string | null;
  status?: string | null;
  sent_via?: string | null;
  sent_at?: string | null;
  pdf_url?: string | null;
  created_by: string;
  created_at?: string;
  updated_at?: string;
}

export interface QuotationUpdate {
  id?: string;
  quotation_number?: string;
  ticket_id?: string | null;
  customer_name?: string;
  customer_company?: string | null;
  customer_email?: string | null;
  customer_phone?: string | null;
  customer_whatsapp?: string | null;
  customer_address?: string | null;
  cargo_description?: string;
  cargo_category?: string | null;
  quantity?: number | null;
  unit_of_measure?: string | null;
  weight_kg?: number | null;
  volume_cbm?: number | null;
  hs_code?: string | null;
  shipment_type?: string | null;
  incoterm?: string | null;
  fleet_type?: string | null;
  fleet_custom?: string | null;
  container_type?: string | null;
  container_quantity?: number | null;
  origin_address?: string | null;
  origin_city?: string | null;
  origin_country?: string | null;
  origin_port?: string | null;
  destination_address?: string | null;
  destination_city?: string | null;
  destination_country?: string | null;
  destination_port?: string | null;
  cost_type?: string;
  base_cost?: number | null;
  cost_details?: unknown | null;
  margin_type?: string | null;
  margin_value?: number | null;
  selling_rate?: number | null;
  currency?: string | null;
  validity_days?: number | null;
  valid_until?: string | null;
  payment_terms?: string | null;
  included_services?: string | null;
  excluded_services?: string | null;
  terms_conditions?: string | null;
  additional_notes?: string | null;
  status?: string | null;
  sent_via?: string | null;
  sent_at?: string | null;
  pdf_url?: string | null;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface CostDetailItem {
  name?: string;
  amount?: number;
  unit?: string;
  description?: string;
}
