﻿// Re-export types for backwards compatibility
export type { TicketStatus, TicketPriority, TicketType, QuoteStatus } from "./index";
