"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Bell, LogOut, Settings, User, Search, Loader2, Check, Ticket } from "lucide-react";
import { toast } from "sonner";
import { useNotifications, useMarkNotificationsRead } from "@/hooks/useNotifications";
import { formatDistanceToNow } from "date-fns";

interface HeaderProps {
  profile: {
    full_name: string;
    email: string;
    roles: { display_name: string } | null;
  };
}

export function Header({ profile }: HeaderProps) {
  const router = useRouter();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);

  const { data: notifData, isLoading: notifLoading } = useNotifications();
  const markReadMutation = useMarkNotificationsRead();

  const unreadCount = notifData?.unreadCount || 0;
  const notifications = notifData?.data || [];

  const handleLogout = async () => {
    setIsLoggingOut(true);

    try {
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      if (response.ok) {
        toast.success("Logged out successfully");
      }
    } catch (err) {
      console.error("Logout error:", err);
    }

    if (typeof window !== "undefined") {
      localStorage.clear();
      sessionStorage.clear();
    }

    window.location.replace("/login");
  };

  const handleMarkAllRead = () => {
    markReadMutation.mutate({ mark_all: true });
  };

  const handleNotifClick = (notif: any) => {
    // Mark as read
    if (!notif.is_read) {
      markReadMutation.mutate({ notification_ids: [notif.id] });
    }
    // Navigate to ticket if exists
    if (notif.ticket_id) {
      setIsNotifOpen(false);
      router.push(`/tickets/${notif.ticket_id}`);
    }
  };

  const getNotifIconColor = (type: string) => {
    switch (type) {
      case "new_ticket":
        return "text-blue-400";
      case "quote_submitted":
        return "text-green-400";
      case "status_changed":
        return "text-orange-400";
      case "sla_warning":
      case "sla_breached":
        return "text-red-400";
      default:
        return "text-slate-400";
    }
  };

  return (
    <header className="fixed top-0 right-0 left-0 lg:left-64 z-40 h-16 bg-[#0a1628]/80 backdrop-blur-xl border-b border-white/10">
      <div className="flex h-full items-center justify-between px-4 lg:px-6">
        {/* Welcome Message */}
        <div className="hidden md:block">
          <h2 className="text-lg font-semibold text-white">
            Welcome back, {profile.full_name?.split(" ")[0]}
          </h2>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-4 hidden md:block">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search tickets..."
              className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/10 rounded-lg text-white placeholder:text-slate-400 focus:outline-none focus:border-orange-500/50 focus:ring-1 focus:ring-orange-500/50"
            />
          </div>
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <DropdownMenu open={isNotifOpen} onOpenChange={setIsNotifOpen}>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative text-slate-300 hover:text-white hover:bg-white/10">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-5 h-5 flex items-center justify-center bg-orange-500 rounded-full text-xs font-bold text-white">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 bg-[#1a2942] border-white/10 text-white">
              <div className="flex items-center justify-between px-3 py-2 border-b border-white/10">
                <span className="font-semibold">Notifications</span>
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleMarkAllRead}
                    className="text-xs text-orange-400 hover:text-orange-300 hover:bg-white/10"
                  >
                    <Check className="h-3 w-3 mr-1" />
                    Mark all read
                  </Button>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto">
                {notifLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-orange-500" />
                  </div>
                ) : notifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-8 text-slate-400">
                    <Bell className="h-8 w-8 mb-2" />
                    <p>No notifications</p>
                  </div>
                ) : (
                  notifications.map((notif: any) => (
                    <div
                      key={notif.id}
                      onClick={() => handleNotifClick(notif)}
                      className={`px-3 py-3 border-b border-white/5 cursor-pointer hover:bg-white/5 transition-colors ${
                        !notif.is_read ? "bg-orange-500/5" : ""
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className={`mt-0.5 ${getNotifIconColor(notif.type)}`}>
                          <Ticket className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm ${!notif.is_read ? "font-semibold" : ""}`}>
                            {notif.title}
                          </p>
                          {notif.message && (
                            <p className="text-xs text-slate-400 truncate">{notif.message}</p>
                          )}
                          <p className="text-xs text-slate-500 mt-1">
                            {formatDistanceToNow(new Date(notif.created_at), { addSuffix: true })}
                          </p>
                        </div>
                        {!notif.is_read && (
                          <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0" />
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-2 text-slate-300 hover:text-white hover:bg-white/10">
                <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center">
                  <span className="text-sm font-semibold text-orange-400">
                    {profile.full_name?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <span className="hidden md:inline-block text-white">
                  {profile.full_name}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w56 bg-[#1a2942] border-white/10 text-white">
              <DropdownMenuLabel>
                <div className="flex flex-col">
                  <span>{profile.full_name}</span>
                  <span className="text-xs text-slate-400 font-normal">
                    {profile.email}
                  </span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem
                onClick={() => window.location.href = "/settings"}
                className="hover:bg-white/10 cursor-pointer"
              >
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => window.location.href = "/settings"}
                className="hover:bg-white/10 cursor-pointer"
              >
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem
                onClick={handleLogout}
                disabled={isLoggingOut}
                className="text-red-400 hover:bg-red-500/10 cursor-pointer"
              >
                {isLoggingOut ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <LogOut className="mr-2 h-4 w-4" />
                )}
                {isLoggingOut ? "Logging out..." : "Logout"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
