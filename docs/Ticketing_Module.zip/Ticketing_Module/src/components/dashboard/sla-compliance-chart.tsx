﻿"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Timer, MessageSquare, DollarSign, RefreshCw, CheckCircle } from "lucide-react";

interface SLAMetric {
  department?: string;
  department_code?: string;
  department_name?: string;
  total_tickets?: number;
  // SLA Targets
  sla_first_response_hours?: number;
  sla_first_quote_hours?: number;
  sla_stage_response_hours?: number;
  sla_resolution_hours?: number;
  // Compliance %
  first_response_compliance?: number | null;
  first_quote_compliance?: number | null;
  stage_response_compliance?: number | null;
  resolution_compliance?: number | null;
  // Avg hours
  first_response_avg_hours?: number | null;
  first_quote_avg_hours?: number | null;
  stage_response_avg_hours?: number | null;
  resolution_avg_hours?: number | null;
  // Counts
  first_response_count?: number;
  first_quote_count?: number;
  stage_response_count?: number;
  resolution_count?: number;
}

interface SLAComplianceChartProps {
  data: SLAMetric[];
}

export function SLAComplianceChart({ data }: SLAComplianceChartProps) {
  if (!data || data.length === 0) {
    return (
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Timer className="h-5 w-5" />
            SLA Compliance
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64 flex items-center justify-center text-white/40">
          No SLA data available
        </CardContent>
      </Card>
    );
  }

  const getComplianceColor = (value: number | null | undefined) => {
    if (value === null || value === undefined) return "bg-white/20";
    if (value >= 90) return "bg-green-500";
    if (value >= 70) return "bg-amber-500";
    return "bg-red-500";
  };

  const getComplianceBadge = (value: number | null | undefined) => {
    if (value === null || value === undefined) return { color: "bg-white/20 text-white/60", label: "N/A" };
    if (value >= 90) return { color: "bg-green-500/20 text-green-400", label: "Good" };
    if (value >= 70) return { color: "bg-amber-500/20 text-amber-400", label: "Warning" };
    return { color: "bg-red-500/20 text-red-400", label: "Critical" };
  };

  const formatHours = (hours: number | null | undefined) => {
    if (hours === null || hours === undefined) return "-";
    if (hours < 1) return `${Math.round(hours * 60)}m`;
    if (hours < 24) return `${hours.toFixed(1)}h`;
    return `${(hours / 24).toFixed(1)}d`;
  };

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Timer className="h-5 w-5" />
          SLA Compliance by Department
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {data.map((dept, index) => {
            const deptName = dept.department || dept.department_name || "Unknown";

            const metrics = [
              {
                key: "first_response",
                label: "First Response",
                icon: MessageSquare,
                iconColor: "text-blue-400",
                compliance: dept.first_response_compliance,
                avgHours: dept.first_response_avg_hours,
                targetHours: dept.sla_first_response_hours,
                count: dept.first_response_count,
              },
              {
                key: "first_quote",
                label: "First Quote",
                icon: DollarSign,
                iconColor: "text-purple-400",
                compliance: dept.first_quote_compliance,
                avgHours: dept.first_quote_avg_hours,
                targetHours: dept.sla_first_quote_hours,
                count: dept.first_quote_count,
              },
              {
                key: "stage_response",
                label: "Stage Response",
                icon: RefreshCw,
                iconColor: "text-yellow-400",
                compliance: dept.stage_response_compliance,
                avgHours: dept.stage_response_avg_hours,
                targetHours: dept.sla_stage_response_hours,
                count: dept.stage_response_count,
              },
              {
                key: "resolution",
                label: "Resolution",
                icon: CheckCircle,
                iconColor: "text-green-400",
                compliance: dept.resolution_compliance,
                avgHours: dept.resolution_avg_hours,
                targetHours: dept.sla_resolution_hours,
                count: dept.resolution_count,
              },
            ];

            return (
              <div key={`${deptName}-${index}`} className="space-y-3 pb-4 border-b border-white/10 last:border-0 last:pb-0">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{deptName}</span>
                  <span className="text-xs text-white/40">{dept.total_tickets} tickets</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {metrics.map((metric) => {
                    const badge = getComplianceBadge(metric.compliance);
                    const Icon = metric.icon;
                    const complianceVal = metric.compliance ?? 0;

                    return (
                      <div key={metric.key} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-white/60 flex items-center gap-1">
                            <Icon className={`h-3 w-3 ${metric.iconColor}`} />
                            {metric.label}
                          </span>
                          <Badge className={`text-[10px] px-1.5 py-0 ${badge.color}`}>
                            {badge.label}
                          </Badge>
                        </div>
                        <div className="relative h-1.5 bg-white/10 rounded-full overflow-hidden">
                          <div
                            className={`absolute left-0 top-0 h-full ${getComplianceColor(metric.compliance)} transition-all`}
                            style={{ width: `${complianceVal}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-white/40">
                          <span>
                            {metric.compliance !== null && metric.compliance !== undefined
                              ? `${metric.compliance}%`
                              : "N/A"}
                          </span>
                          <span>
                            {metric.avgHours !== null && metric.avgHours !== undefined
                              ? `avg: ${formatHours(metric.avgHours)}`
                              : ""}
                            {metric.targetHours ? ` / ${metric.targetHours}h` : ""}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
