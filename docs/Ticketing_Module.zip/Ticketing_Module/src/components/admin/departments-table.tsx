"use client";

import { useState } from "react";
import { useDepartments } from "@/hooks/useDashboard";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Edit, Loader2, Clock, MessageSquare, CheckCircle, DollarSign, Timer } from "lucide-react";
import { toast } from "sonner";
import type { Department } from "@/types";

interface DepartmentWithSLA extends Department {
  sla_first_response_hours?: number;
  sla_resolution_hours?: number;
  sla_first_quote_hours?: number;
  sla_stage_response_hours?: number;
}

export function DepartmentsTable() {
  const queryClient = useQueryClient();
  const { data: departments, isLoading, error } = useDepartments();
  const [editDept, setEditDept] = useState<DepartmentWithSLA | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    sla_first_response_hours: 4,
    sla_resolution_hours: 72,
    sla_first_quote_hours: 24,
    sla_stage_response_hours: 4,
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return apiRequest(`/api/departments/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["departments"] });
      toast.success("Department updated successfully");
      setEditDept(null);
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to update department");
    },
  });

  const openEdit = (dept: DepartmentWithSLA) => {
    setEditDept(dept);
    setFormData({
      name: dept.name,
      description: dept.description || "",
      sla_first_response_hours: dept.sla_first_response_hours || 4,
      sla_resolution_hours: dept.sla_resolution_hours || 72,
      sla_first_quote_hours: dept.sla_first_quote_hours || 24,
      sla_stage_response_hours: dept.sla_stage_response_hours || 4,
    });
  };

  const handleSave = () => {
    if (!editDept) return;
    updateMutation.mutate({
      id: editDept.id,
      data: formData,
    });
  };

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-400">Failed to load departments</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (!departments?.length) {
    return (
      <div className="text-center py-12">
        <p className="text-white/60">No departments found</p>
      </div>
    );
  }

  return (
    <>
      <div className="rounded-xl border border-white/10 bg-white/5 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-white/10">
              <TableHead className="text-white/60">Name</TableHead>
              <TableHead className="text-white/60">Code</TableHead>
              <TableHead className="text-white/60 text-center">
                <div className="flex items-center justify-center gap-1">
                  <MessageSquare className="h-3 w-3" />
                  <span>1st Response</span>
                </div>
              </TableHead>
              <TableHead className="text-white/60 text-center">
                <div className="flex items-center justify-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  <span>1st Quote</span>
                </div>
              </TableHead>
              <TableHead className="text-white/60 text-center">
                <div className="flex items-center justify-center gap-1">
                  <Timer className="h-3 w-3" />
                  <span>Stage Resp</span>
                </div>
              </TableHead>
              <TableHead className="text-white/60 text-center">
                <div className="flex items-center justify-center gap-1">
                  <CheckCircle className="h-3 w-3" />
                  <span>Resolution</span>
                </div>
              </TableHead>
              <TableHead className="text-white/60 w-[80px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {departments.map((dept: DepartmentWithSLA) => (
              <TableRow key={dept.id} className="border-white/10">
                <TableCell className="font-medium">{dept.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="border-white/20">{dept.code}</Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className="bg-blue-500/20 text-blue-400">
                    {dept.sla_first_response_hours || 4}h
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className="bg-purple-500/20 text-purple-400">
                    {dept.sla_first_quote_hours || 24}h
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className="bg-yellow-500/20 text-yellow-400">
                    {dept.sla_stage_response_hours || 4}h
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className="bg-green-500/20 text-green-400">
                    {dept.sla_resolution_hours || 72}h
                  </Badge>
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 hover:bg-white/10"
                    onClick={() => openEdit(dept)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editDept} onOpenChange={(open) => !open && setEditDept(null)}>
        <DialogContent className="bg-slate-900 border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Department: {editDept?.name}</DialogTitle>
            <DialogDescription>
              Update department info and SLA targets
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Department Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white/5 border-white/20"
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-white/5 border-white/20"
                rows={2}
              />
            </div>

            <div className="border-t border-white/10 pt-4">
              <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-400" />
                SLA Targets (hours)
              </h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs flex items-center gap-1">
                    <MessageSquare className="h-3 w-3 text-blue-400" />
                    First Response
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    value={formData.sla_first_response_hours}
                    onChange={(e) => setFormData({ ...formData, sla_first_response_hours: parseInt(e.target.value) || 4 })}
                    className="bg-white/5 border-white/20"
                  />
                  <p className="text-xs text-white/40">Target: first reply from dept</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs flex items-center gap-1">
                    <DollarSign className="h-3 w-3 text-purple-400" />
                    First Quote
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    value={formData.sla_first_quote_hours}
                    onChange={(e) => setFormData({ ...formData, sla_first_quote_hours: parseInt(e.target.value) || 24 })}
                    className="bg-white/5 border-white/20"
                  />
                  <p className="text-xs text-white/40">Target: quote submission (RFQ)</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs flex items-center gap-1">
                    <Timer className="h-3 w-3 text-yellow-400" />
                    Stage Response
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    value={formData.sla_stage_response_hours}
                    onChange={(e) => setFormData({ ...formData, sla_stage_response_hours: parseInt(e.target.value) || 4 })}
                    className="bg-white/5 border-white/20"
                  />
                  <p className="text-xs text-white/40">Target: each response stage</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs flex items-center gap-1">
                    <CheckCircle className="h-3 w-3 text-green-400" />
                    Resolution
                  </Label>
                  <Input
                    type="number"
                    min={1}
                    value={formData.sla_resolution_hours}
                    onChange={(e) => setFormData({ ...formData, sla_resolution_hours: parseInt(e.target.value) || 72 })}
                    className="bg-white/5 border-white/20"
                  />
                  <p className="text-xs text-white/40">Target: ticket closure</p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDept(null)}>
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="bg-orange-500 hover:bg-orange-600"
            >
              {updateMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
