"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ArrowLeft, Plus, Trash2, Send, Loader2, Ship, Plane, Truck, Package, MapPin, User, Calendar, FileText, Container, Home, Warehouse } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
// Remove the import line completely (or comment it out)

const serviceTypesList = [
  { value: "export_sea_lcl", label: "Export Seafreight LCL", category: "Export", icon: Ship },
  { value: "export_sea_fcl", label: "Export Seafreight FCL", category: "Export", icon: Container },
  { value: "export_air", label: "Export Airfreight", category: "Export", icon: Plane },
  { value: "import_sea_lcl", label: "Import Seafreight LCL", category: "Import", icon: Ship },
  { value: "import_sea_fcl", label: "Import Seafreight FCL", category: "Import", icon: Container },
  { value: "import_air", label: "Import Airfreight", category: "Import", icon: Plane },
  { value: "import_dtd_fcl", label: "Import DTD FCL", category: "Import DTD", icon: Home },
  { value: "import_dtd_lcl", label: "Import DTD LCL", category: "Import DTD", icon: Home },
  { value: "import_dtd_air", label: "Import DTD Airfreight", category: "Import DTD", icon: Plane },
  { value: "domestic_ftl", label: "Domestics FTL (Charter)", category: "Domestics", icon: Truck },
  { value: "domestic_ltl", label: "Domestics LTL", category: "Domestics", icon: Truck },
  { value: "domestic_sea_fcl", label: "Domestics Seafreight FCL", category: "Domestics", icon: Ship },
  { value: "domestic_sea_lcl", label: "Domestics Seafreight LCL", category: "Domestics", icon: Ship },
  { value: "domestic_air", label: "Domestics Airfreight", category: "Domestics", icon: Plane },
  { value: "customs_clearance", label: "Customs Clearance", category: "Services", icon: FileText },
  { value: "warehousing", label: "Warehousing & Fulfillment", category: "Services", icon: Warehouse },
];

const serviceCategories: Record<string, typeof serviceTypesList> = {};
serviceTypesList.forEach(service => {
  if (!serviceCategories[service.category]) serviceCategories[service.category] = [];
  serviceCategories[service.category]!.push(service);
});

const containerTypes = [
  { value: "20ft", label: "20ft Standard" },
  { value: "40ft", label: "40ft Standard" },
  { value: "40ft_hc", label: "40ft High Cube" },
  { value: "lcl", label: "LCL" },
];

const incoterms = ["EXW", "FOB", "CIF", "CFR", "DDP", "DAP", "FCA", "CPT", "CIP"];

const cargoItemSchema = z.object({
  description: z.string().min(1, "Required"),
  quantity: z.number().optional(),
  weight_kg: z.number().optional(),
  volume_cbm: z.number().optional(),
  hs_code: z.string().optional(),
});

const rateInquirySchema = z.object({
  customer_name: z.string().min(1, "Required"),
  customer_company: z.string().optional(),
  customer_email: z.string().email().optional().or(z.literal("")),
  customer_phone: z.string().optional(),
  customer_whatsapp: z.string().optional(),
  service_type: z.string().min(1, "Required"),
  incoterm: z.string().optional(),
  container_type: z.string().optional(),
  container_quantity: z.number().optional(),
  origin_city: z.string().min(1, "Required"),
  origin_country: z.string().optional(),
  origin_port: z.string().optional(),
  destination_city: z.string().min(1, "Required"),
  destination_country: z.string().optional(),
  destination_port: z.string().optional(),
  cargo_items: z.array(cargoItemSchema).min(1),
  cargo_ready_date: z.string().optional(),
  special_requirements: z.string().optional(),
  notes: z.string().optional(),
});

type FormData = z.infer<typeof rateInquirySchema>;

export default function RateInquiryForm() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(rateInquirySchema),
    defaultValues: {
      service_type: "",
      incoterm: "FOB",
      container_quantity: 1,
      origin_country: "Indonesia",
      cargo_items: [{ description: "", quantity: undefined, weight_kg: undefined, volume_cbm: undefined, hs_code: "" }],
    },
  });

  const { fields, append, remove } = useFieldArray({ control: form.control, name: "cargo_items" });
  const watchedServiceType = form.watch("service_type");
  const selectedService = serviceTypesList.find(s => s.value === watchedServiceType);

  const onSubmit = async (data: FormData) => {
  setIsSubmitting(true);
  try {
    const cargoLines = data.cargo_items.map((item, i) => {
      let line = (i + 1) + ". " + item.description;
      if (item.quantity) line += " (Qty: " + item.quantity + ")";
      if (item.weight_kg) line += ", " + item.weight_kg + "kg";
      if (item.volume_cbm) line += ", " + item.volume_cbm + "cbm";
      return line;
    });
    
    const description = [
      "**Customer**",
      "Name: " + data.customer_name,
      "Company: " + (data.customer_company || "-"),
      "Email: " + (data.customer_email || "-"),
      "Phone: " + (data.customer_phone || "-"),
      "",
      "**Shipment**",
      "Service: " + (selectedService?.label || data.service_type),
      "Incoterm: " + (data.incoterm || "-"),
      "Container: " + (data.container_type ? data.container_quantity + "x " + data.container_type : "-"),
      "",
      "**Route**",
      "Origin: " + data.origin_city + (data.origin_country ? ", " + data.origin_country : ""),
      "Destination: " + data.destination_city + (data.destination_country ? ", " + data.destination_country : ""),
      "",
      "**Cargo**",
      ...cargoLines,
      data.special_requirements ? "\nSpecial: " + data.special_requirements : "",
      data.notes ? "\nNotes: " + data.notes : "",
    ].filter(Boolean).join("\n");

    const response = await fetch("/api/tickets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        subject: "Rate Inquiry: " + (selectedService?.label || data.service_type) + " - " + data.origin_city + " to " + data.destination_city,
        description,
        type: "rate_inquiry",
        priority: "normal",
        customer_name: data.customer_name,
        customer_email: data.customer_email || undefined,
        shipment_type: data.service_type,
        origin: data.origin_city + (data.origin_country ? ", " + data.origin_country : ""),
        destination: data.destination_city + (data.destination_country ? ", " + data.destination_country : ""),
      }),
    });
    
    if (!response.ok) throw new Error("Failed to create ticket");
    
    toast.success("Rate inquiry submitted!");
    router.push("/tickets");
  } catch {
    toast.error("Failed to submit");
  } finally {
    setIsSubmitting(false);
  }
};

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">New Rate Inquiry</h1>
          <p className="text-muted-foreground">Request freight rates</p>
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />Customer
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>Company</Label>
              <Input {...form.register("customer_company")} placeholder="PT. Example" className="mt-1" />
            </div>
            <div>
              <Label>Contact <span className="text-red-500">*</span></Label>
              <Input {...form.register("customer_name")} placeholder="John Doe" className="mt-1" />
            </div>
            <div>
              <Label>Email</Label>
              <Input type="email" {...form.register("customer_email")} className="mt-1" />
            </div>
            <div>
              <Label>Phone</Label>
              <Input {...form.register("customer_phone")} className="mt-1" />
            </div>
            <div>
              <Label>WhatsApp</Label>
              <Input {...form.register("customer_whatsapp")} className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />Service Type <span className="text-red-500">*</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={watchedServiceType} onValueChange={(v) => form.setValue("service_type", v)}>
              <SelectTrigger>
                <SelectValue placeholder="Select service">
                  {selectedService && (
                    <div className="flex items-center gap-2">
                      <selectedService.icon className="h-4 w-4" />
                      {selectedService.label}
                    </div>
                  )}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                <ScrollArea className="h-[300px]">
                  {Object.entries(serviceCategories).map(([cat, services]) => (
                    <SelectGroup key={cat}>
                      <SelectLabel className="bg-muted/50 py-2">{cat}</SelectLabel>
                      {services.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          <div className="flex items-center gap-2">
                            <s.icon className="h-4 w-4 text-muted-foreground" />
                            {s.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  ))}
                </ScrollArea>
              </SelectContent>
            </Select>
            {selectedService && (
              <div className="mt-4 p-3 bg-primary/5 rounded-lg border border-primary/20 flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <selectedService.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{selectedService.label}</p>
                  <p className="text-sm text-muted-foreground">{selectedService.category}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Shipment Options</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-3 gap-4">
            <div>
              <Label>Incoterm</Label>
              <Select value={form.watch("incoterm")} onValueChange={(v) => form.setValue("incoterm", v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {incoterms.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Container</Label>
              <Select value={form.watch("container_type") || ""} onValueChange={(v) => form.setValue("container_type", v)}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {containerTypes.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Qty</Label>
              <Input type="number" min={1} {...form.register("container_quantity", { valueAsNumber: true })} className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-6">
          <Card className="border-green-500/50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-green-600">
                <MapPin className="h-5 w-5" />Origin
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div><Label>City <span className="text-red-500">*</span></Label><Input {...form.register("origin_city")} className="mt-1" /></div>
              <div><Label>Country</Label><Input {...form.register("origin_country")} className="mt-1" /></div>
              <div><Label>Port</Label><Input {...form.register("origin_port")} className="mt-1" /></div>
            </CardContent>
          </Card>
          <Card className="border-red-500/50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-red-600">
                <MapPin className="h-5 w-5" />Destination
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div><Label>City <span className="text-red-500">*</span></Label><Input {...form.register("destination_city")} className="mt-1" /></div>
              <div><Label>Country</Label><Input {...form.register("destination_country")} className="mt-1" /></div>
              <div><Label>Port</Label><Input {...form.register("destination_port")} className="mt-1" /></div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2"><Package className="h-5 w-5" />Cargo</span>
              <Button type="button" variant="outline" size="sm" onClick={() => append({ description: "", quantity: undefined, weight_kg: undefined, volume_cbm: undefined, hs_code: "" })}>
                <Plus className="h-4 w-4 mr-2" />Add
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {fields.map((field, i) => (
              <div key={field.id} className="p-4 border rounded-lg space-y-3">
                <div className="flex justify-between">
                  <Badge variant="secondary">Item {i + 1}</Badge>
                  {fields.length > 1 && (
                    <Button type="button" variant="ghost" size="sm" onClick={() => remove(i)} className="text-red-500">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <div>
                  <Label>Description <span className="text-red-500">*</span></Label>
                  <Textarea {...form.register(`cargo_items.${i}.description`)} rows={2} className="mt-1" />
                </div>
                <div className="grid grid-cols-4 gap-3">
                  <div><Label>Qty</Label><Input type="number" {...form.register(`cargo_items.${i}.quantity`, { valueAsNumber: true })} className="mt-1" /></div>
                  <div><Label>Weight (KG)</Label><Input type="number" step="0.01" {...form.register(`cargo_items.${i}.weight_kg`, { valueAsNumber: true })} className="mt-1" /></div>
                  <div><Label>Volume (CBM)</Label><Input type="number" step="0.01" {...form.register(`cargo_items.${i}.volume_cbm`, { valueAsNumber: true })} className="mt-1" /></div>
                  <div><Label>HS Code</Label><Input {...form.register(`cargo_items.${i}.hs_code`)} className="mt-1" /></div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Calendar className="h-5 w-5" />Additional</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Cargo Ready Date</Label><Input type="date" {...form.register("cargo_ready_date")} className="mt-1" /></div>
            <div><Label>Special Requirements</Label><Textarea {...form.register("special_requirements")} rows={2} className="mt-1" /></div>
            <div><Label>Notes</Label><Textarea {...form.register("notes")} rows={2} className="mt-1" /></div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button type="button" variant="outline" onClick={() => router.back()}>Cancel</Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            <Send className="h-4 w-4 mr-2" />Submit
          </Button>
        </div>
      </form>
    </div>
  );
}