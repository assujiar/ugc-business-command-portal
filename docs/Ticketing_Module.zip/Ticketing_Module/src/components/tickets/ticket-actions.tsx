"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Send, DollarSign, CheckCircle, Clock, MessageSquare, Loader2, ThumbsUp, ThumbsDown, RefreshCw, UserCheck, Paperclip, X, FileText, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { UPLOAD_LIMITS } from "@/lib/constants";

interface TicketActionsProps {
  ticket: any;
  onUpdate: () => void;
}

const statusLabels: Record<string, string> = {
  open: "Open", need_response: "Need Response", in_progress: "In Progress",
  waiting_customer: "Waiting Customer", need_adjustment: "Need Adjustment", closed: "Closed",
};

const statusColors: Record<string, string> = {
  open: "bg-blue-500/20 text-blue-400", need_response: "bg-orange-500/20 text-orange-400",
  in_progress: "bg-purple-500/20 text-purple-400", waiting_customer: "bg-yellow-500/20 text-yellow-400",
  need_adjustment: "bg-pink-500/20 text-pink-400", closed: "bg-gray-500/20 text-gray-400",
};

const lostReasons = [
  { value: "price_not_competitive", label: "Harga tidak kompetitif" },
  { value: "customer_cancel", label: "Customer membatalkan" },
  { value: "competitor_won", label: "Kompetitor menang" },
  { value: "service_not_match", label: "Layanan tidak sesuai kebutuhan" },
  { value: "timing_issue", label: "Waktu tidak sesuai" },
  { value: "other", label: "Lainnya" },
];

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

function getFileIcon(type: string) {
  if (type.startsWith("image/")) return <ImageIcon className="h-4 w-4 text-blue-400" />;
  return <FileText className="h-4 w-4 text-orange-400" />;
}

export function TicketActions({ ticket, onUpdate }: TicketActionsProps) {
  const [profile, setProfile] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [comment, setComment] = useState("");
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [quotedPrice, setQuotedPrice] = useState("");
  const [quoteTerms, setQuoteTerms] = useState("");
  const [quoteValidDays, setQuoteValidDays] = useState("7");
  const [showQuoteDialog, setShowQuoteDialog] = useState(false);
  const [showWonDialog, setShowWonDialog] = useState(false);
  const [showLostDialog, setShowLostDialog] = useState(false);
  const [showAdjustmentDialog, setShowAdjustmentDialog] = useState(false);
  const [showWaitingDialog, setShowWaitingDialog] = useState(false);
  const [projectDate, setProjectDate] = useState("");
  const [wonNotes, setWonNotes] = useState("");
  const [lostReason, setLostReason] = useState("");
  const [lostNotes, setLostNotes] = useState("");
  const [competitorPrice, setCompetitorPrice] = useState("");
  const [adjustmentNote, setAdjustmentNote] = useState("");
  const [waitingNote, setWaitingNote] = useState("");

  useEffect(() => {
    fetch("/api/auth/me")
      .then(res => res.json())
      .then(data => {
        if (data.success) setProfile(data.data);
      })
      .catch(err => console.error("Profile fetch error:", err));
  }, []);

  const profileDeptId = profile?.department_id;
  const roleName = profile?.roles?.name || "";
  const isSuperAdmin = roleName === "super_admin";
  const isCreator = ticket?.created_by === profile?.id;
  const isDepartmentStaff = profileDeptId && ticket?.department_id === profileDeptId;
  const canRespond = isDepartmentStaff || isSuperAdmin;
  const canClose = isCreator || isSuperAdmin;
  const isRFQ = ticket?.ticket_type === "RFQ";

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles: File[] = [];
    
    for (const file of files) {
      if (file.size > UPLOAD_LIMITS.MAX_SIZE_BYTES) {
        toast.error(`${file.name} exceeds ${UPLOAD_LIMITS.MAX_SIZE_MB}MB limit`);
        continue;
      }
      const allowedTypes: readonly string[] = UPLOAD_LIMITS.ALLOWED_TYPES;
      if (!allowedTypes.includes(file.type)) {
        toast.error(`${file.name} has unsupported file type`);
        continue;
      }
      validFiles.push(file);
    }
    
    setAttachedFiles(prev => [...prev, ...validFiles]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmitComment = async () => {
    if (!comment.trim() && attachedFiles.length === 0) {
      toast.error("Please enter a message or attach a file");
      return;
    }
    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("content", comment);
      formData.append("type", "comment");
      
      for (const file of attachedFiles) {
        formData.append("files", file);
      }

      const res = await fetch(`/api/tickets/${ticket.id}/comments`, {
        method: "POST",
        body: formData,
      });
      
      if (!res.ok) throw new Error((await res.json()).message);
      toast.success("Comment submitted!");
      setComment("");
      setAttachedFiles([]);
      onUpdate();
      (window as any).refreshComments?.();
    } catch (e: any) { toast.error(e.message); }
    finally { setIsSubmitting(false); }
  };

  const handleSubmitQuote = async () => {
    if (!quotedPrice) { toast.error("Please enter price"); return; }
    setIsSubmitting(true);
    try {
      const validUntil = new Date();
      validUntil.setDate(validUntil.getDate() + parseInt(quoteValidDays));
      const res = await fetch(`/api/tickets/${ticket.id}/quotes`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: parseFloat(quotedPrice), currency: "IDR", valid_until: validUntil.toISOString().split("T")[0], terms: quoteTerms || null }),
      });
      if (!res.ok) throw new Error((await res.json()).message);
      toast.success("Quote submitted!");
      setQuotedPrice(""); setQuoteTerms(""); setShowQuoteDialog(false);
      onUpdate();
      (window as any).refreshComments?.();
    } catch (e: any) { toast.error(e.message); }
    finally { setIsSubmitting(false); }
  };

  const handleRequestAdjustment = async () => {
    if (!adjustmentNote.trim()) { toast.error("Please enter adjustment details"); return; }
    setIsSubmitting(true);
    try {
      await fetch(`/api/tickets/${ticket.id}/comments`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: `🔄 REQUEST ADJUSTMENT\n\n${adjustmentNote}`,
          type: "need_adjustment"
        }),
      });
      await fetch(`/api/tickets/${ticket.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "need_adjustment" }),
      });
      toast.success("Adjustment request sent!");
      setShowAdjustmentDialog(false); setAdjustmentNote("");
      onUpdate();
      (window as any).refreshComments?.();
    } catch { toast.error("Failed"); }
    finally { setIsSubmitting(false); }
  };

  const handleWaitingCustomer = async () => {
    setIsSubmitting(true);
    try {
      await fetch(`/api/tickets/${ticket.id}/comments`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: `⏳ WAITING CUSTOMER\n\n${waitingNote || "Quote sudah disubmit ke customer, menunggu feedback."}`,
          type: "waiting_customer"
        }),
      });
      await fetch(`/api/tickets/${ticket.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "waiting_customer" }),
      });
      toast.success("Status updated!");
      setShowWaitingDialog(false); setWaitingNote("");
      onUpdate();
      (window as any).refreshComments?.();
    } catch { toast.error("Failed"); }
    finally { setIsSubmitting(false); }
  };

  const handleWon = async () => {
    if (!projectDate) { toast.error("Please select date"); return; }
    setIsSubmitting(true);
    try {
      await fetch(`/api/tickets/${ticket.id}/comments`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: `✅ TICKET WON\nEstimasi Project: ${projectDate}${wonNotes ? `\nKeterangan: ${wonNotes}` : ""}`, type: "status_change", metadata: { resolution: "won", project_date: projectDate } }),
      });
      await fetch(`/api/tickets/${ticket.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "closed", close_outcome: "won", closed_at: new Date().toISOString() }),
      });
      toast.success("Ticket Won!");
      setShowWonDialog(false); setProjectDate(""); setWonNotes("");
      onUpdate();
    } catch { toast.error("Failed"); }
    finally { setIsSubmitting(false); }
  };

  const handleLost = async () => {
    if (!lostReason) { toast.error("Select reason"); return; }
    setIsSubmitting(true);
    try {
      const label = lostReasons.find(r => r.value === lostReason)?.label || lostReason;
      let content = `❌ TICKET LOST\nAlasan: ${label}`;
      if (competitorPrice) content += `\nHarga kompetitor: Rp ${parseInt(competitorPrice).toLocaleString("id-ID")}`;
      if (lostNotes) content += `\nKeterangan: ${lostNotes}`;
      await fetch(`/api/tickets/${ticket.id}/comments`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, type: "status_change", metadata: { resolution: "lost", reason: lostReason } }),
      });
      await fetch(`/api/tickets/${ticket.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "closed", close_outcome: "lost", close_reason: lostReason, closed_at: new Date().toISOString() }),
      });
      toast.success("Ticket Lost");
      setShowLostDialog(false); setLostReason(""); setLostNotes(""); setCompetitorPrice("");
      onUpdate();
    } catch { toast.error("Failed"); }
    finally { setIsSubmitting(false); }
  };

  if (ticket?.status === "closed") {
    return (
      <Card className="bg-white/5 border-white/10">
        <CardHeader><CardTitle className="text-lg flex items-center gap-2"><CheckCircle className="h-5 w-5 text-green-400" />Ticket Closed</CardTitle></CardHeader>
        <CardContent>
          <Badge className={ticket.close_outcome === "won" ? "bg-green-500/20 text-green-400" : ticket.close_outcome === "lost" ? "bg-red-500/20 text-red-400" : "bg-blue-500/20 text-blue-400"}>
            {ticket.close_outcome === "won" ? "Won ✓" : ticket.close_outcome === "lost" ? "Lost ✗" : "Resolved"}
          </Badge>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2"><MessageSquare className="h-5 w-5" />Actions</CardTitle>
        <CardDescription>Respond or update ticket status</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Comment with Attachment */}
        <div className="space-y-2">
          <Label>Add Comment</Label>
          <Textarea 
            placeholder="Write your message..." 
            value={comment} 
            onChange={(e) => setComment(e.target.value)} 
            className="bg-white/5 border-white/10 min-h-[100px]" 
          />
          
          {/* File Attachment Section */}
          <div className="space-y-2">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={UPLOAD_LIMITS.ALLOWED_EXTENSIONS.join(",")}
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="border-white/20 hover:bg-white/10"
            >
              <Paperclip className="h-4 w-4 mr-2" />
              Attach Files
            </Button>
            <p className="text-xs text-white/40">
              Max {UPLOAD_LIMITS.MAX_SIZE_MB}MB per file. Allowed: PDF, DOC, XLS, JPG, PNG
            </p>
            
            {/* Attached Files Preview */}
            {attachedFiles.length > 0 && (
              <div className="space-y-2 p-3 rounded-lg bg-white/5 border border-white/10">
                {attachedFiles.map((file, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    {getFileIcon(file.type)}
                    <span className="flex-1 truncate">{file.name}</span>
                    <span className="text-white/40 text-xs">{formatFileSize(file.size)}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 hover:bg-red-500/20"
                      onClick={() => removeFile(index)}
                    >
                      <X className="h-3 w-3 text-red-400" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <Button 
            onClick={handleSubmitComment} 
            disabled={isSubmitting || (!comment.trim() && attachedFiles.length === 0)} 
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
            Send Comment {attachedFiles.length > 0 && `(${attachedFiles.length} file${attachedFiles.length > 1 ? 's' : ''})`}
          </Button>
        </div>

        {/* Submit Quote - Department */}
        {canRespond && isRFQ && (
          <Dialog open={showQuoteDialog} onOpenChange={setShowQuoteDialog}>
            <DialogTrigger asChild><Button className="w-full bg-green-600 hover:bg-green-700"><DollarSign className="h-4 w-4 mr-2" />Submit Quote</Button></DialogTrigger>
            <DialogContent className="bg-slate-900 border-white/10">
              <DialogHeader><DialogTitle>Submit Quote</DialogTitle></DialogHeader>
              <div className="space-y-4 py-4">
                <div><Label>Price (IDR) *</Label><Input type="number" value={quotedPrice} onChange={(e) => setQuotedPrice(e.target.value)} className="bg-white/5 border-white/10" /></div>
                <div><Label>Valid (Days)</Label>
                  <Select value={quoteValidDays} onValueChange={setQuoteValidDays}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-slate-900 border-white/10"><SelectItem value="7">7 days</SelectItem><SelectItem value="14">14 days</SelectItem><SelectItem value="30">30 days</SelectItem></SelectContent>
                  </Select>
                </div>
                <div><Label>Terms</Label><Textarea value={quoteTerms} onChange={(e) => setQuoteTerms(e.target.value)} className="bg-white/5 border-white/10" /></div>
              </div>
              <DialogFooter><Button variant="outline" onClick={() => setShowQuoteDialog(false)}>Cancel</Button><Button onClick={handleSubmitQuote} disabled={isSubmitting || !quotedPrice} className="bg-green-600">{isSubmitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Submit</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Creator Actions for RFQ */}
        {isCreator && isRFQ && ticket?.status !== "closed" && (
          <div className="space-y-2">
            <Dialog open={showAdjustmentDialog} onOpenChange={setShowAdjustmentDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full border-pink-500/30 text-pink-400 hover:bg-pink-500/10">
                  <RefreshCw className="h-4 w-4 mr-2" />Request Adjustment / Nego Harga
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-slate-900 border-white/10">
                <DialogHeader>
                  <DialogTitle>Request Adjustment</DialogTitle>
                  <DialogDescription>Minta revisi harga atau nego ke department</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label>Detail Permintaan *</Label>
                    <Textarea
                      placeholder="Contoh: Customer minta harga lebih rendah, budget max Rp 5.000.000..."
                      value={adjustmentNote}
                      onChange={(e) => setAdjustmentNote(e.target.value)}
                      className="bg-white/5 border-white/10 min-h-[100px]"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowAdjustmentDialog(false)}>Cancel</Button>
                  <Button onClick={handleRequestAdjustment} disabled={isSubmitting || !adjustmentNote.trim()} className="bg-pink-600 hover:bg-pink-700">
                    {isSubmitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Send Request
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={showWaitingDialog} onOpenChange={setShowWaitingDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
                  <UserCheck className="h-4 w-4 mr-2" />Quote Sent to Customer
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-slate-900 border-white/10">
                <DialogHeader>
                  <DialogTitle>Quote Submitted to Customer</DialogTitle>
                  <DialogDescription>Tandai bahwa quote sudah dikirim ke customer dan menunggu feedback</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label>Catatan (Opsional)</Label>
                    <Textarea
                      placeholder="Contoh: Quote sudah dikirim via email, customer akan konfirmasi dalam 3 hari..."
                      value={waitingNote}
                      onChange={(e) => setWaitingNote(e.target.value)}
                      className="bg-white/5 border-white/10 min-h-[80px]"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowWaitingDialog(false)}>Cancel</Button>
                  <Button onClick={handleWaitingCustomer} disabled={isSubmitting} className="bg-yellow-600 hover:bg-yellow-700">
                    {isSubmitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Confirm
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        )}

        {/* Won/Lost */}
        {canClose && isRFQ && (
          <div className="grid grid-cols-2 gap-2">
            <Dialog open={showWonDialog} onOpenChange={setShowWonDialog}>
              <DialogTrigger asChild><Button className="bg-green-600 hover:bg-green-700"><ThumbsUp className="h-4 w-4 mr-2" />Won</Button></DialogTrigger>
              <DialogContent className="bg-slate-900 border-white/10">
                <DialogHeader><DialogTitle>Mark as Won</DialogTitle></DialogHeader>
                <div className="space-y-4 py-4">
                  <div><Label>Project Date *</Label><Input type="date" value={projectDate} onChange={(e) => setProjectDate(e.target.value)} className="bg-white/5 border-white/10" /></div>
                  <div><Label>Notes</Label><Textarea value={wonNotes} onChange={(e) => setWonNotes(e.target.value)} className="bg-white/5 border-white/10" /></div>
                </div>
                <DialogFooter><Button variant="outline" onClick={() => setShowWonDialog(false)}>Cancel</Button><Button onClick={handleWon} disabled={isSubmitting || !projectDate} className="bg-green-600">{isSubmitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Confirm</Button></DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={showLostDialog} onOpenChange={setShowLostDialog}>
              <DialogTrigger asChild><Button variant="outline" className="border-red-500/30 text-red-400"><ThumbsDown className="h-4 w-4 mr-2" />Lost</Button></DialogTrigger>
              <DialogContent className="bg-slate-900 border-white/10">
                <DialogHeader><DialogTitle>Mark as Lost</DialogTitle></DialogHeader>
                <div className="space-y-4 py-4">
                  <div><Label>Reason *</Label>
                    <Select value={lostReason} onValueChange={setLostReason}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue placeholder="Select..." /></SelectTrigger>
                      <SelectContent className="bg-slate-900 border-white/10">{lostReasons.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  {lostReason === "price_not_competitive" && <div><Label>Competitor Price</Label><Input type="number" value={competitorPrice} onChange={(e) => setCompetitorPrice(e.target.value)} className="bg-white/5 border-white/10" /></div>}
                  <div><Label>Notes</Label><Textarea value={lostNotes} onChange={(e) => setLostNotes(e.target.value)} className="bg-white/5 border-white/10" /></div>
                </div>
                <DialogFooter><Button variant="outline" onClick={() => setShowLostDialog(false)}>Cancel</Button><Button onClick={handleLost} disabled={isSubmitting || !lostReason} variant="destructive">{isSubmitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Confirm</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        )}

        {/* Close non-RFQ */}
        {canClose && !isRFQ && (
          <Button onClick={async () => { setIsSubmitting(true); await fetch(`/api/tickets/${ticket.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "closed" }) }); toast.success("Closed!"); onUpdate(); setIsSubmitting(false); }} disabled={isSubmitting} variant="outline" className="w-full border-green-500/30 text-green-400">
            <CheckCircle className="h-4 w-4 mr-2" />Close
          </Button>
        )}

        <div className="pt-4 border-t border-white/10">
          <Badge className={statusColors[ticket?.status] || statusColors.open}>{statusLabels[ticket?.status] || ticket?.status}</Badge>
        </div>
      </CardContent>
    </Card>
  );
}
