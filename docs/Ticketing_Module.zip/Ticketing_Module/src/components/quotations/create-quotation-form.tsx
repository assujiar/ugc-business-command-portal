"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  ArrowLeft,
  ArrowRight,
  Save,
  Send,
  User,
  Package,
  Calculator,
  FileText,
  Building,
  Phone,
  Mail,
  MessageCircle,
  MapPin,
  Ship,
  Plane,
  Truck,
  Plus,
  Trash2,
  CheckCircle,
  Loader2,
  Download,
  Globe,
  DollarSign,
  Percent,
  Home,
  Warehouse,
  Container,
  Calendar,
  CreditCard,
  Eye,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectGroup,
  SelectLabel,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  useCreateQuotation,
  useDownloadPDF,
  useSendQuotation,
  formatCurrency,
  calculateSellingRate,
  calculateTotalFromDetails,
  CostDetail,
  QuotationFormData,
} from "@/hooks/useQuotations";

// Extended CostDetail with custom name support
interface CostDetailExtended extends CostDetail {
  isCustom?: boolean;
  customName?: string;
}

// ============ STANDARD LOGISTICS COST COMPONENTS ============
const costComponentCategories: Record<string, Array<{ value: string; label: string }>> = {
  "Freight Charges": [
    { value: "ocean_freight", label: "Ocean Freight" },
    { value: "air_freight", label: "Air Freight" },
    { value: "trucking", label: "Trucking / Land Transport" },
    { value: "feeder_vessel", label: "Feeder Vessel" },
    { value: "barge_charges", label: "Barge Charges" },
    { value: "rail_freight", label: "Rail Freight" },
  ],
  "Terminal & Port Charges": [
    { value: "thc_origin", label: "THC Origin (Terminal Handling)" },
    { value: "thc_destination", label: "THC Destination" },
    { value: "port_charges", label: "Port Charges" },
    { value: "wharfage", label: "Wharfage" },
    { value: "lolo", label: "Lift On/Lift Off (LOLO)" },
    { value: "do_fee", label: "DO Fee (Delivery Order)" },
    { value: "storage", label: "Storage" },
    { value: "demurrage", label: "Demurrage" },
    { value: "detention", label: "Detention" },
  ],
  "Documentation & Admin": [
    { value: "documentation_fee", label: "Documentation Fee" },
    { value: "bl_fee", label: "Bill of Lading Fee" },
    { value: "awb_fee", label: "Airway Bill Fee" },
    { value: "admin_fee", label: "Admin Fee" },
    { value: "handling_fee", label: "Handling Fee" },
    { value: "agency_fee", label: "Agency Fee" },
    { value: "telex_release", label: "Telex Release" },
    { value: "surrender_bl", label: "Surrender BL" },
  ],
  "Customs & Compliance": [
    { value: "customs_clearance", label: "Customs Clearance" },
    { value: "import_duty", label: "Import Duty / Bea Masuk" },
    { value: "vat_ppn", label: "VAT / PPN" },
    { value: "pph", label: "PPH (Income Tax)" },
    { value: "export_license", label: "Export License" },
    { value: "import_license", label: "Import License (PIB/PIBK)" },
    { value: "coo", label: "Certificate of Origin (COO)" },
    { value: "quarantine", label: "Quarantine Fee" },
    { value: "redress_notul", label: "Redress / Notul" },
    { value: "lartas", label: "LARTAS Processing" },
  ],
  "Surcharges": [
    { value: "baf", label: "BAF (Bunker Adjustment Factor)" },
    { value: "caf", label: "CAF (Currency Adjustment Factor)" },
    { value: "ebs", label: "EBS (Emergency Bunker Surcharge)" },
    { value: "lss", label: "LSS (Low Sulphur Surcharge)" },
    { value: "pss", label: "PSS (Peak Season Surcharge)" },
    { value: "gri", label: "GRI (General Rate Increase)" },
    { value: "isps", label: "ISPS Security Fee" },
    { value: "ams", label: "AMS Fee" },
    { value: "ens", label: "ENS Fee" },
  ],
  "Container & Equipment": [
    { value: "seal_fee", label: "Seal Fee" },
    { value: "vgm_fee", label: "VGM Fee" },
    { value: "stuffing", label: "Stuffing" },
    { value: "unstuffing", label: "Unstuffing / Stripping" },
    { value: "container_cleaning", label: "Container Cleaning" },
    { value: "reefer_ptm", label: "Reefer PTI/PTM" },
    { value: "genset", label: "Genset Charges" },
  ],
  "Warehousing & Handling": [
    { value: "warehouse_rent", label: "Warehouse Rent" },
    { value: "loading_unloading", label: "Loading / Unloading" },
    { value: "packing", label: "Packing" },
    { value: "repacking", label: "Repacking" },
    { value: "palletizing", label: "Palletizing" },
    { value: "wrapping", label: "Wrapping" },
    { value: "labeling", label: "Labeling" },
    { value: "sorting", label: "Sorting" },
  ],
  "Insurance & Other": [
    { value: "cargo_insurance", label: "Cargo Insurance" },
    { value: "fumigation", label: "Fumigation" },
    { value: "inspection_fee", label: "Inspection Fee" },
    { value: "surveyor_fee", label: "Surveyor Fee" },
    { value: "escort_fee", label: "Escort Fee" },
    { value: "overnight_charges", label: "Overnight Charges" },
    { value: "waiting_time", label: "Waiting Time" },
  ],
};

const allCostComponents = Object.values(costComponentCategories).flat();

// ============ FORM SCHEMA ============
const quotationSchema = z.object({
  customer_name: z.string().min(1, "Customer name is required"),
  customer_company: z.string().optional(),
  customer_email: z.string().email("Invalid email").optional().or(z.literal("")),
  customer_phone: z.string().optional(),
  customer_whatsapp: z.string().optional(),
  customer_address: z.string().optional(),
  cargo_description: z.string().min(1, "Cargo description is required"),
  cargo_category: z.string().optional(),
  quantity: z.number().optional(),
  unit_of_measure: z.string().optional(),
  weight_kg: z.number().optional(),
  volume_cbm: z.number().optional(),
  hs_code: z.string().optional(),
  shipment_type: z.string().min(1, "Service type is required"),
  incoterm: z.string().optional(),
  fleet_type: z.string().optional(),
  fleet_custom: z.string().optional(),
  container_type: z.string().optional(),
  container_quantity: z.number().optional(),
  origin_address: z.string().optional(),
  origin_city: z.string().min(1, "Origin city is required"),
  origin_country: z.string().optional(),
  origin_port: z.string().optional(),
  destination_address: z.string().optional(),
  destination_city: z.string().min(1, "Destination city is required"),
  destination_country: z.string().optional(),
  destination_port: z.string().optional(),
  cost_type: z.enum(["operations", "bundling", "detail"]),
  base_cost: z.number().optional(),
  margin_type: z.enum(["percentage", "fixed"]),
  margin_value: z.number().min(0),
  currency: z.string(),
  validity_days: z.number().min(1),
  payment_terms: z.string().optional(),
  included_services: z.string().optional(),
  excluded_services: z.string().optional(),
  additional_notes: z.string().optional(),
});

type FormData = z.infer<typeof quotationSchema>;

const steps = [
  { id: 1, title: "Customer", icon: User, description: "Customer information" },
  { id: 2, title: "Shipment", icon: Package, description: "Shipment details" },
  { id: 3, title: "Pricing", icon: Calculator, description: "Cost & margin" },
  { id: 4, title: "Terms", icon: FileText, description: "Terms & conditions" },
];

// Service Types with icons
const serviceTypesList = [
  { value: "export_sea_lcl", label: "Export Seafreight LCL", category: "Export", icon: Ship },
  { value: "export_sea_fcl", label: "Export Seafreight FCL", category: "Export", icon: Container },
  { value: "export_air", label: "Export Airfreight", category: "Export", icon: Plane },
  { value: "import_sea_lcl", label: "Import Seafreight LCL", category: "Import", icon: Ship },
  { value: "import_sea_fcl", label: "Import Seafreight FCL", category: "Import", icon: Container },
  { value: "import_air", label: "Import Airfreight", category: "Import", icon: Plane },
  { value: "import_dtd_fcl", label: "Import DTD FCL", category: "Import DTD", icon: Home },
  { value: "import_dtd_lcl", label: "Import DTD LCL", category: "Import DTD", icon: Home },
  { value: "import_dtd_air", label: "Import DTD Airfreight", category: "Import DTD", icon: Plane },
  { value: "domestic_ftl", label: "Domestics FTL (Charter)", category: "Domestics", icon: Truck },
  { value: "domestic_ltl", label: "Domestics LTL", category: "Domestics", icon: Truck },
  { value: "domestic_sea_fcl", label: "Domestics Seafreight FCL", category: "Domestics", icon: Ship },
  { value: "domestic_sea_lcl", label: "Domestics Seafreight LCL", category: "Domestics", icon: Ship },
  { value: "domestic_air", label: "Domestics Airfreight", category: "Domestics", icon: Plane },
  { value: "customs_clearance", label: "Customs Clearance", category: "Services", icon: FileText },
  { value: "warehousing", label: "Warehousing & Fulfillment", category: "Services", icon: Warehouse },
];

// Group services by category
const serviceCategories: Record<string, typeof serviceTypesList> = {};
serviceTypesList.forEach(service => {
  if (!serviceCategories[service.category]) {
    serviceCategories[service.category] = [];
  }
  serviceCategories[service.category]!.push(service);
});

// ============ FLEET OPTIONS FOR DOMESTICS ============
const fleetOptions = [
  { value: "blind_van", label: "Blind Van" },
  { value: "cde_bak", label: "CDE Bak" },
  { value: "cde_box", label: "CDE Box" },
  { value: "cde_reefer", label: "CDE Reefer" },
  { value: "cdd_bak", label: "CDD Bak" },
  { value: "cdd_box", label: "CDD Box" },
  { value: "cdd_long", label: "CDD Long" },
  { value: "cdd_reefer", label: "CDD Reefer" },
  { value: "fuso_bak", label: "Fuso Bak" },
  { value: "fuso_box", label: "Fuso Box" },
  { value: "tronton_wingbox", label: "Tronton Wingbox" },
  { value: "tronton_pickup", label: "Tronton Pickup" },
  { value: "trailer_20ft", label: "Trailer 20 Feet" },
  { value: "trailer_40ft", label: "Trailer 40 Feet" },
  { value: "trailer_flatbed", label: "Trailer Flatbed" },
  { value: "airfreight", label: "Airfreight" },
  { value: "seafreight", label: "Seafreight" },
  { value: "other", label: "Lainnya" },
];

// Helper to check if service is domestic
const isDomesticService = (serviceValue: string): boolean => {
  return serviceValue.startsWith("domestic_");
};

// Helper to check if service needs incoterm (export/import)
const needsIncoterm = (serviceValue: string): boolean => {
  return serviceValue.startsWith("export_") || serviceValue.startsWith("import_");
};

const containerTypes = [
  { value: "20ft", label: "20ft Standard" },
  { value: "40ft", label: "40ft Standard" },
  { value: "40ft_hc", label: "40ft High Cube" },
  { value: "45ft_hc", label: "45ft High Cube" },
  { value: "20ft_rf", label: "20ft Reefer" },
  { value: "40ft_rf", label: "40ft Reefer" },
  { value: "lcl", label: "LCL (Less Container Load)" },
];

const defaultCostDetails: CostDetailExtended[] = [
  { name: "ocean_freight", amount: 0, unit: "Per Shipment", isCustom: false },
];

// ============ COST DETAIL ROW COMPONENT ============
function CostDetailRow({
  item,
  index,
  currency,
  onUpdate,
  onRemove,
  canRemove,
}: {
  item: CostDetailExtended;
  index: number;
  currency: string;
  onUpdate: (index: number, updates: Partial<CostDetailExtended>) => void;
  onRemove: (index: number) => void;
  canRemove: boolean;
}) {
  const isOther = item.isCustom === true;
  
  const handleSelectChange = (value: string) => {
    if (value === "__other__") {
      onUpdate(index, { isCustom: true, name: "", customName: "" });
    } else {
      onUpdate(index, { isCustom: false, name: value, customName: undefined });
    }
  };
  
  return (
    <div className="grid grid-cols-12 gap-2 items-end p-3 bg-muted/50 rounded-lg">
      <div className={cn(isOther ? "col-span-3" : "col-span-5")}>
        <Label className="text-xs">Cost Component</Label>
        <Select
          value={isOther ? "__other__" : (item.name || "")}
          onValueChange={handleSelectChange}
        >
          <SelectTrigger className="mt-1">
            <SelectValue placeholder="Select component" />
          </SelectTrigger>
          <SelectContent className="max-h-80">
            {Object.entries(costComponentCategories).map(([category, items]) => (
              <SelectGroup key={category}>
                <SelectLabel className="text-xs font-semibold text-muted-foreground">{category}</SelectLabel>
                {items.map((comp) => (
                  <SelectItem key={comp.value} value={comp.value}>{comp.label}</SelectItem>
                ))}
              </SelectGroup>
            ))}
            <SelectGroup>
              <SelectLabel className="text-xs font-semibold text-muted-foreground">Custom</SelectLabel>
              <SelectItem value="__other__">?? Other (Manual Input)</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      
      {isOther && (
        <div className="col-span-1 md:col-span-2">
          <Label className="text-xs">Custom Name</Label>
          <Input
            value={item.customName || ""}
            onChange={(e) => onUpdate(index, { customName: e.target.value })}
            placeholder="Enter name..."
            className="mt-1"
          />
        </div>
      )}

      <div className="col-span-3">
        <Label className="text-xs">Amount ({currency})</Label>
        <Input
          type="number"
          value={item.amount || ""}
          onChange={(e) => onUpdate(index, { amount: parseFloat(e.target.value) || 0 })}
          placeholder="0"
          className="mt-1 font-mono"
        />
      </div>

      <div className={cn(isOther ? "col-span-3" : "col-span-3")}>
        <Label className="text-xs">Unit</Label>
        <Select
          value={item.unit || "Per Shipment"}
          onValueChange={(v) => onUpdate(index, { unit: v })}
        >
          <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Per Shipment">Per Shipment</SelectItem>
            <SelectItem value="Per Container">Per Container</SelectItem>
            <SelectItem value="Per KG">Per KG</SelectItem>
            <SelectItem value="Per CBM">Per CBM</SelectItem>
            <SelectItem value="Per Truck">Per Truck</SelectItem>
            <SelectItem value="Per Day">Per Day</SelectItem>
            <SelectItem value="Per BL">Per BL</SelectItem>
            <SelectItem value="Per AWB">Per AWB</SelectItem>
            <SelectItem value="Lumpsum">Lumpsum</SelectItem>
            <SelectItem value="Percentage">Percentage</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="col-span-1">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={() => onRemove(index)}
          disabled={!canRemove}
          className="text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

// ============ MAIN COMPONENT ============
export default function CreateQuotationPage() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [costDetails, setCostDetails] = useState<CostDetailExtended[]>(defaultCostDetails);
  const [additionalCosts, setAdditionalCosts] = useState<CostDetailExtended[]>([]);
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [createdNumber, setCreatedNumber] = useState<string | null>(null);
  const [pendingAction, setPendingAction] = useState<"email" | "whatsapp" | "download" | null>(null);
  const [selectedServiceType, setSelectedServiceType] = useState<string>("");

  const form = useForm<FormData>({
    resolver: zodResolver(quotationSchema),
    defaultValues: {
      shipment_type: "",
      incoterm: "",
      fleet_type: "",
      container_type: "",
      container_quantity: 1,
      origin_country: "Indonesia",
      cost_type: "bundling",
      base_cost: 0,
      margin_type: "percentage",
      margin_value: 15,
      currency: "IDR",
      validity_days: 14,
      payment_terms: "30 days from invoice date",
    },
  });

  const watchedValues = form.watch();
  const createMutation = useCreateQuotation();
  const downloadMutation = useDownloadPDF();
  const sendMutation = useSendQuotation();

  // Handle service type selection
  const handleServiceTypeSelect = (value: string) => {
    setSelectedServiceType(value);
    form.setValue("shipment_type", value);
  };

  const getCostLabel = (item: CostDetailExtended): string => {
    if (item.isCustom && item.customName) return item.customName;
    const found = allCostComponents.find(c => c.value === item.name);
    return found?.label || item.name || "Unknown";
  };

  const prepareCostDetailsForApi = (items: CostDetailExtended[]): CostDetail[] => {
    return items.filter(item => item.amount && item.amount > 0).map(item => ({
      name: item.isCustom ? (item.customName || "Other") : getCostLabel(item),
      amount: item.amount || 0,
      unit: item.unit || "Per Shipment",
      description: item.description,
    }));
  };

  const getTotalCost = (): number => {
    let baseCost = 0;
    if (watchedValues.cost_type === "bundling" || watchedValues.cost_type === "operations") {
      baseCost = watchedValues.base_cost || 0;
    } else {
      baseCost = calculateTotalFromDetails(costDetails as CostDetail[]);
    }
    const additionalTotal = additionalCosts.reduce((sum, item) => sum + (item.amount || 0), 0);
    return baseCost + additionalTotal;
  };

  const getSellingRate = (): number => {
    return calculateSellingRate(getTotalCost(), watchedValues.margin_type, watchedValues.margin_value || 0);
  };

  const getMarginAmount = (): number => {
    return getSellingRate() - getTotalCost();
  };

  // Cost detail management
  const addCostDetail = () => setCostDetails([...costDetails, { name: "", amount: 0, unit: "Per Shipment", isCustom: false }]);
  const removeCostDetail = (index: number) => { if (costDetails.length > 1) setCostDetails(costDetails.filter((_, i) => i !== index)); };
  const updateCostDetail = (index: number, updates: Partial<CostDetailExtended>) => {
    setCostDetails(prev => prev.map((item, i) => i === index ? { ...item, ...updates } : item));
  };

  // Additional costs management
  const addAdditionalCost = () => setAdditionalCosts([...additionalCosts, { name: "", amount: 0, unit: "Per Shipment", isCustom: false }]);
  const removeAdditionalCost = (index: number) => setAdditionalCosts(additionalCosts.filter((_, i) => i !== index));
  const updateAdditionalCost = (index: number, updates: Partial<CostDetailExtended>) => {
    setAdditionalCosts(prev => prev.map((item, i) => i === index ? { ...item, ...updates } : item));
  };

  const getServiceLabel = (value: string): string => serviceTypesList.find(s => s.value === value)?.label || value;
  const getContainerLabel = (value: string): string => containerTypes.find(c => c.value === value)?.label || value;

  const getValidUntilDate = (): string => {
    const date = new Date();
    date.setDate(date.getDate() + (watchedValues.validity_days || 14));
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  };

  // Handle submit
  const handleSubmit = async (status: "draft" | "sent" = "draft") => {
    const isValid = await form.trigger();
    if (!isValid) {
      const errorFields = Object.keys(form.formState.errors); toast.error(errorFields.length > 0 ? `Please fill: ${errorFields.join(", ")}` : "Please fill in all required fields"); console.log("Validation errors:", form.formState.errors);
      return;
    }

    const values = form.getValues();

    try {
      const detailCosts = prepareCostDetailsForApi(costDetails);
      const additionalCostsForApi = prepareCostDetailsForApi(additionalCosts);
      
      const allCostDetails = watchedValues.cost_type === "detail" 
        ? [...detailCosts, ...additionalCostsForApi]
        : additionalCostsForApi;

      const payload: QuotationFormData = {
        ...values,
        base_cost: getTotalCost(),
        cost_details: allCostDetails.length > 0 ? allCostDetails : undefined,
        status,
      };

      const result = await createMutation.mutateAsync(payload);
      setCreatedId(result.data.id);
      setCreatedNumber(result.data.quotation_number);

      if (status === "draft") {
        toast.success("Quotation saved as draft");
        router.push("/quotations");
      } else {
        toast.success("Quotation created successfully"); router.push("/quotations");
      }
    } catch (error: unknown) {
      const err = error as Error;
      toast.error(err.message || "Failed to create quotation");
    }
  };

  // Show preview before action
  const handleShowPreview = (action: "email" | "whatsapp" | "download") => {
    setPendingAction(action);
    setShowPreviewDialog(true);
    setShowSendDialog(false);
  };

  // Execute action after preview
  const handleConfirmAction = async () => {
    if (!pendingAction || !createdId) return;
    setShowPreviewDialog(false);
    if (pendingAction === "download") {
      await handleDownload();
    } else {
      await handleSend(pendingAction);
    }
  };

  const handleSend = async (method: "email" | "whatsapp") => {
    if (!createdId) return;
    try {
      const result = await sendMutation.mutateAsync({ id: createdId, method });
      if (method === "email") {
        toast.success(`Quotation sent to ${result.recipient}`);
      } else {
        toast.success("Opening WhatsApp...");
      }
      router.push("/quotations");
    } catch (error: unknown) {
      const err = error as Error;
      toast.error(err.message || `Failed to send via ${method}`);
    }
  };

  const handleDownload = async () => {
    if (!createdId || !createdNumber) return;
    try {
      await downloadMutation.mutateAsync({ id: createdId, quotationNumber: createdNumber });
      toast.success("PDF downloaded");
    } catch (error) {
      console.error("Download error:", error);
      toast.error("Failed to download PDF");
    }
  };

  const canGoNext = (): boolean => {
    switch (currentStep) {
      case 1: return !!watchedValues.customer_name;
      case 2: return !!watchedValues.cargo_description && !!watchedValues.origin_city && !!watchedValues.destination_city && !!selectedServiceType;
      case 3: return true; // Allow proceeding even with 0 cost
      default: return true;
    }
  };

  const goNext = async () => {
    // Trigger validation for current step fields
    let fieldsToValidate: (keyof FormData)[] = [];
    switch (currentStep) {
      case 1: fieldsToValidate = ["customer_name"]; break;
      case 2: fieldsToValidate = ["cargo_description", "shipment_type", "origin_city", "destination_city"]; break;
      case 3: fieldsToValidate = []; break;
    }
    const isValid = await form.trigger(fieldsToValidate);
    if (!isValid || !canGoNext()) {
      const errorFields = Object.keys(form.formState.errors); toast.error(errorFields.length > 0 ? `Please fill: ${errorFields.join(", ")}` : "Please fill in all required fields"); console.log("Validation errors:", form.formState.errors);
      return;
    }
    setCurrentStep((s) => Math.min(4, s + 1));
  };
  const goPrev = () => setCurrentStep((s) => Math.max(1, s - 1));

  // ============ SUMMARY PREVIEW COMPONENT ============
  const SummaryPreview = () => (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-4 rounded-lg">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-bold">UGC LOGISTICS</h3>
            <p className="text-blue-200 text-xs">Excellence in Global Freight Solutions</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-blue-200">Quotation No.</p>
            <p className="font-mono font-bold">{createdNumber || "QUO-XXXXXXXX"}</p>
          </div>
        </div>
      </div>

      <ScrollArea className="h-[400px] pr-4">
        <div className="border rounded-lg p-4 mb-4">
          <h4 className="font-semibold text-sm flex items-center gap-2 mb-3">
            <User className="h-4 w-4 text-primary" />Customer Information
          </h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-muted-foreground">Company:</span><p className="font-medium">{watchedValues.customer_company || "-"}</p></div>
            <div><span className="text-muted-foreground">Contact:</span><p className="font-medium">{watchedValues.customer_name}</p></div>
            <div><span className="text-muted-foreground">Email:</span><p className="font-medium">{watchedValues.customer_email || "-"}</p></div>
            <div><span className="text-muted-foreground">Phone:</span><p className="font-medium">{watchedValues.customer_whatsapp || watchedValues.customer_phone || "-"}</p></div>
          </div>
        </div>

        <div className="border rounded-lg p-4 mb-4">
          <h4 className="font-semibold text-sm flex items-center gap-2 mb-3">
            <Package className="h-4 w-4 text-primary" />Shipment Details
          </h4>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">{getServiceLabel(selectedServiceType)}</Badge>
              <Badge variant="secondary" className="text-xs">{watchedValues.incoterm}</Badge>
            </div>
            <div className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
              <div className="flex-1 text-center">
                <p className="text-xs text-green-600 font-medium">Origin</p>
                <p className="font-semibold text-sm">{watchedValues.origin_city}</p>
              </div>
              <div className="text-2xl text-muted-foreground">?</div>
              <div className="flex-1 text-center">
                <p className="text-xs text-red-600 font-medium">Destination</p>
                <p className="font-semibold text-sm">{watchedValues.destination_city}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border rounded-lg p-4 mb-4">
          <h4 className="font-semibold text-sm flex items-center gap-2 mb-3">
            <Calculator className="h-4 w-4 text-primary" />Rate Breakdown
          </h4>
          
          {watchedValues.cost_type === "detail" && costDetails.filter(c => c.amount && c.amount > 0).map((item, idx) => {
            const sellingAmount = watchedValues.margin_type === "percentage" 
              ? (item.amount || 0) * (1 + (watchedValues.margin_value || 0) / 100)
              : (item.amount || 0) + ((watchedValues.margin_value || 0) * ((item.amount || 0) / getTotalCost()));
            return (
              <div key={idx} className="flex justify-between items-center py-1 text-sm border-b last:border-0">
                <span className="text-muted-foreground">{getCostLabel(item)}</span>
                <span className="font-mono">{formatCurrency(Math.round(sellingAmount), watchedValues.currency)}</span>
              </div>
            );
          })}

          {watchedValues.cost_type !== "detail" && (
            <div className="flex justify-between items-center py-2 text-sm">
              <span>Total Rate</span>
              <span className="font-mono font-bold">{formatCurrency(getSellingRate(), watchedValues.currency)}</span>
            </div>
          )}

          <Separator className="my-3" />
          <div className="flex justify-between items-center pt-2">
            <span className="font-bold">Total Selling Rate</span>
            <span className="font-mono font-bold text-lg text-primary">{formatCurrency(getSellingRate(), watchedValues.currency)}</span>
          </div>
        </div>

        <div className="border rounded-lg p-4">
          <h4 className="font-semibold text-sm flex items-center gap-2 mb-3">
            <FileText className="h-4 w-4 text-primary" />Terms
          </h4>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div><span className="text-muted-foreground text-xs">Valid Until</span><p className="font-medium">{getValidUntilDate()}</p></div>
            </div>
            <div className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-muted-foreground" />
              <div><span className="text-muted-foreground text-xs">Payment</span><p className="font-medium">{watchedValues.payment_terms || "30 days"}</p></div>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push("/quotations")}><ArrowLeft className="h-5 w-5" /></Button>
        <div>
          <h1 className="text-2xl font-bold">Create Quick Quotation</h1>
          <p className="text-muted-foreground">Fill in the details to generate a quotation</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-between px-4">
        {steps.map((step, index) => (
          <div key={step.id} className="flex items-center">
            <button type="button" onClick={() => setCurrentStep(step.id)}
              className={cn("flex items-center gap-2 px-4 py-2 rounded-lg transition-all",
                currentStep === step.id ? "bg-primary text-primary-foreground" : currentStep > step.id ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300" : "bg-muted text-muted-foreground"
              )}>
              <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", currentStep === step.id ? "bg-primary-foreground/20" : currentStep > step.id ? "bg-green-200 dark:bg-green-800" : "bg-muted-foreground/20")}>
                {currentStep > step.id ? <CheckCircle className="h-5 w-5" /> : <step.icon className="h-4 w-4" />}
              </div>
              <span className="font-medium hidden md:inline">{step.title}</span>
            </button>
            {index < steps.length - 1 && <div className={cn("w-8 lg:w-16 h-0.5 mx-2", currentStep > step.id ? "bg-green-500" : "bg-muted")} />}
          </div>
        ))}
      </div>

      {/* Step 1: Customer Information */}
      {currentStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><User className="h-5 w-5" />Customer Information</CardTitle>
            <CardDescription>Enter the customer details for this quotation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-1 md:col-span-2">
                <Label htmlFor="customer_company">Company Name</Label>
                <div className="relative mt-1"><Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="customer_company" {...form.register("customer_company")} placeholder="PT. Example Company" className="pl-10" /></div>
              </div>
              <div className="col-span-1">
                <Label htmlFor="customer_name">Contact Person <span className="text-red-500">*</span></Label>
                <div className="relative mt-1"><User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="customer_name" {...form.register("customer_name")} placeholder="John Doe" className="pl-10" /></div>
                {form.formState.errors.customer_name && <p className="text-sm text-red-500 mt-1">{form.formState.errors.customer_name.message}</p>}
              </div>
              <div className="col-span-1">
                <Label htmlFor="customer_email">Email Address</Label>
                <div className="relative mt-1"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="customer_email" type="email" {...form.register("customer_email")} placeholder="john@example.com" className="pl-10" /></div>
              </div>
              <div className="col-span-1">
                <Label htmlFor="customer_phone">Phone Number</Label>
                <div className="relative mt-1"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="customer_phone" {...form.register("customer_phone")} placeholder="+62 21 1234567" className="pl-10" /></div>
              </div>
              <div className="col-span-1">
                <Label htmlFor="customer_whatsapp">WhatsApp Number</Label>
                <div className="relative mt-1"><MessageCircle className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="customer_whatsapp" {...form.register("customer_whatsapp")} placeholder="+62 812 34567890" className="pl-10" /></div>
              </div>
              <div className="col-span-1 md:col-span-2">
                <Label htmlFor="customer_address">Address</Label>
                <Textarea id="customer_address" {...form.register("customer_address")} placeholder="Full address..." rows={2} className="mt-1" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Shipment Details */}
      {currentStep === 2 && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Package className="h-5 w-5" />Service Type <span className="text-red-500">*</span></CardTitle>
              <CardDescription>Select the type of service for this quotation</CardDescription>
              {form.formState.errors.shipment_type && <p className="text-sm text-red-500 mt-1">{form.formState.errors.shipment_type.message}</p>}
              {!selectedServiceType && form.formState.isSubmitted && <p className="text-sm text-red-500 mt-1">Please select a service type</p>}
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(serviceCategories).map(([category, services]) => (
                  <div key={category}>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-3">{category}</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {services.map((service) => {
                        const isSelected = selectedServiceType === service.value;
                        const IconComponent = service.icon;
                        return (
                          <button key={service.value} type="button" onClick={() => handleServiceTypeSelect(service.value)}
                            className={cn("flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all",
                              isSelected ? "border-[#ff4600] bg-[#ff4600] text-white shadow-lg scale-105" : "border-muted bg-background hover:border-[#ff4600]/50 hover:bg-muted/50"
                            )}>
                            <IconComponent className={cn("h-6 w-6 mb-2", isSelected ? "text-white" : "text-muted-foreground")} />
                            <span className={cn("text-xs font-medium text-center", isSelected ? "text-white" : "")}>{service.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
              {!selectedServiceType && form.formState.errors.shipment_type && (
                <p className="text-sm text-red-500 mt-2">Please select a service type</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Shipment Options</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                {/* Incoterm - only for Export/Import */}
                {needsIncoterm(selectedServiceType) && (
                  <div>
                    <Label htmlFor="incoterm">Incoterm</Label>
                    <Select value={watchedValues.incoterm} onValueChange={(v) => form.setValue("incoterm", v)}>
                      <SelectTrigger id="incoterm" className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EXW">EXW - Ex Works</SelectItem>
                        <SelectItem value="FOB">FOB - Free on Board</SelectItem>
                        <SelectItem value="CIF">CIF - Cost, Insurance & Freight</SelectItem>
                        <SelectItem value="CFR">CFR - Cost and Freight</SelectItem>
                        <SelectItem value="DDP">DDP - Delivered Duty Paid</SelectItem>
                        <SelectItem value="DAP">DAP - Delivered at Place</SelectItem>
                        <SelectItem value="FCA">FCA - Free Carrier</SelectItem>
                        <SelectItem value="CPT">CPT - Carriage Paid To</SelectItem>
                        <SelectItem value="CIP">CIP - Carriage Insurance Paid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Fleet Type - only for Domestics */}
                {isDomesticService(selectedServiceType) && (
                  <div>
                    <Label htmlFor="fleet_type">Fleet / Mode</Label>
                    <Select value={watchedValues.fleet_type} onValueChange={(v) => form.setValue("fleet_type", v)}>
                      <SelectTrigger id="fleet_type" className="mt-1"><SelectValue placeholder="Select fleet" /></SelectTrigger>
                      <SelectContent>
                        <ScrollArea className="h-[280px]">
                          <SelectGroup>
                            <SelectLabel className="text-xs font-semibold text-muted-foreground">Trucks</SelectLabel>
                            {fleetOptions.slice(0, 12).map((f) => (<SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>))}
                          </SelectGroup>
                          <SelectGroup>
                            <SelectLabel className="text-xs font-semibold text-muted-foreground">Trailers</SelectLabel>
                            {fleetOptions.slice(12, 15).map((f) => (<SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>))}
                          </SelectGroup>
                          <SelectGroup>
                            <SelectLabel className="text-xs font-semibold text-muted-foreground">Other</SelectLabel>
                            {fleetOptions.slice(15).map((f) => (<SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>))}
                          </SelectGroup>
                        </ScrollArea>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Custom Fleet Input - when "Lainnya" selected */}
                {isDomesticService(selectedServiceType) && watchedValues.fleet_type === "other" && (
                  <div>
                    <Label htmlFor="fleet_custom">Specify Fleet</Label>
                    <Input 
                      id="fleet_custom" 
                      {...form.register("fleet_custom")} 
                      placeholder="Enter fleet type..." 
                      className="mt-1" 
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="container_type">Container/Load Type</Label>
                  <Select value={watchedValues.container_type} onValueChange={(v) => form.setValue("container_type", v)}>
                    <SelectTrigger id="container_type" className="mt-1"><SelectValue placeholder="Select type" /></SelectTrigger>
                    <SelectContent>{containerTypes.map((ct) => (<SelectItem key={ct.value} value={ct.value}>{ct.label}</SelectItem>))}</SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="container_quantity">Quantity</Label>
                  <Input id="container_quantity" type="number" min={1} {...form.register("container_quantity", { valueAsNumber: true })} className="mt-1" />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-6">
            <Card className="border-green-500/50">
              <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-green-600"><MapPin className="h-5 w-5" />Origin</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div><Label htmlFor="origin_city">City <span className="text-red-500">*</span></Label><Input id="origin_city" {...form.register("origin_city")} placeholder="Jakarta" className="mt-1" /></div>
                <div><Label htmlFor="origin_country">Country</Label><Input id="origin_country" {...form.register("origin_country")} placeholder="Indonesia" className="mt-1" /></div>
                <div><Label htmlFor="origin_port">Port / Airport</Label><Input id="origin_port" {...form.register("origin_port")} placeholder="Tanjung Priok" className="mt-1" /></div>
              </CardContent>
            </Card>
            <Card className="border-red-500/50">
              <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-red-600"><MapPin className="h-5 w-5" />Destination</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div><Label htmlFor="destination_city">City <span className="text-red-500">*</span></Label><Input id="destination_city" {...form.register("destination_city")} placeholder="Singapore" className="mt-1" /></div>
                <div><Label htmlFor="destination_country">Country</Label><Input id="destination_country" {...form.register("destination_country")} placeholder="Singapore" className="mt-1" /></div>
                <div><Label htmlFor="destination_port">Port / Airport</Label><Input id="destination_port" {...form.register("destination_port")} placeholder="Port of Singapore" className="mt-1" /></div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><Package className="h-5 w-5" />Cargo Details</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div><Label htmlFor="cargo_description">Cargo Description <span className="text-red-500">*</span></Label><Textarea id="cargo_description" {...form.register("cargo_description")} placeholder="Describe the cargo..." rows={2} className="mt-1" /></div>
              <div className="grid grid-cols-4 gap-4">
                <div><Label htmlFor="quantity">Quantity</Label><Input id="quantity" type="number" {...form.register("quantity", { valueAsNumber: true })} className="mt-1" /></div>
                <div><Label htmlFor="weight_kg">Weight (KG)</Label><Input id="weight_kg" type="number" step="0.01" {...form.register("weight_kg", { valueAsNumber: true })} className="mt-1" /></div>
                <div><Label htmlFor="volume_cbm">Volume (CBM)</Label><Input id="volume_cbm" type="number" step="0.01" {...form.register("volume_cbm", { valueAsNumber: true })} className="mt-1" /></div>
                <div><Label htmlFor="hs_code">HS Code</Label><Input id="hs_code" {...form.register("hs_code")} placeholder="8471.30" className="mt-1" /></div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 3: Cost & Pricing */}
      {currentStep === 3 && (
        <div className="space-y-6">
          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><Calculator className="h-5 w-5" />Cost Source</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { value: "operations", label: "Operations Cost", desc: "Use rate from operations", icon: Globe },
                  { value: "bundling", label: "Bundling Cost", desc: "Single total cost", icon: Package },
                  { value: "detail", label: "Detail Cost", desc: "Itemized breakdown", icon: FileText },
                ].map((option) => {
                  const isSelected = watchedValues.cost_type === option.value;
                  return (
                    <button key={option.value} type="button" onClick={() => form.setValue("cost_type", option.value as "operations" | "bundling" | "detail")}
                      className={cn("flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all",
                        isSelected ? "border-[#ff4600] bg-[#ff4600] text-white shadow-lg scale-105" : "border-muted bg-background hover:border-[#ff4600]/50 hover:bg-muted/50"
                      )}>
                      <option.icon className={cn("h-6 w-6 mb-2", isSelected ? "text-white" : "text-muted-foreground")} />
                      <span className={cn("font-medium", isSelected ? "text-white" : "")}>{option.label}</span>
                      <span className={cn("text-xs mt-1", isSelected ? "text-white/80" : "text-muted-foreground")}>{option.desc}</span>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {(watchedValues.cost_type === "bundling" || watchedValues.cost_type === "operations") && (
            <Card>
              <CardHeader><CardTitle>{watchedValues.cost_type === "operations" ? "Operations Cost" : "Bundling Cost"}</CardTitle></CardHeader>
              <CardContent>
                <div className="flex gap-4 items-end">
                  <div className="w-32">
                    <Label htmlFor="currency">Currency</Label>
                    <Select value={watchedValues.currency} onValueChange={(v) => form.setValue("currency", v)}>
                      <SelectTrigger id="currency" className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="IDR">IDR</SelectItem><SelectItem value="USD">USD</SelectItem><SelectItem value="SGD">SGD</SelectItem></SelectContent>
                    </Select>
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="base_cost">Total Cost <span className="text-red-500">*</span></Label>
                    <div className="relative mt-1"><DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="base_cost" type="number" step="0.01" {...form.register("base_cost", { valueAsNumber: true })} placeholder="0" className="pl-10 text-lg font-mono" /></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {watchedValues.cost_type === "detail" && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between"><span>Cost Breakdown</span><Button type="button" variant="outline" size="sm" onClick={addCostDetail}><Plus className="h-4 w-4 mr-2" />Add Item</Button></CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {costDetails.map((item, index) => (
                    <CostDetailRow key={index} item={item} index={index} currency={watchedValues.currency} onUpdate={updateCostDetail} onRemove={removeCostDetail} canRemove={costDetails.length > 1} />
                  ))}
                </div>
                <div className="mt-4 p-3 bg-muted rounded-lg flex justify-between items-center">
                  <span className="font-medium">Subtotal</span>
                  <span className="text-lg font-mono font-bold">{formatCurrency(calculateTotalFromDetails(costDetails as CostDetail[]), watchedValues.currency)}</span>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between"><span>Additional Cost Components</span><Button type="button" variant="outline" size="sm" onClick={addAdditionalCost}><Plus className="h-4 w-4 mr-2" />Add Component</Button></CardTitle>
            </CardHeader>
            <CardContent>
              {additionalCosts.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground"><p>No additional costs added</p></div>
              ) : (
                <div className="space-y-3">
                  {additionalCosts.map((item, index) => (<CostDetailRow key={index} item={item} index={index} currency={watchedValues.currency} onUpdate={updateAdditionalCost} onRemove={removeAdditionalCost} canRemove={true} />))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Margin & Selling Rate</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Margin Type</Label>
                    <div className="flex gap-4 mt-2">
                      {[{ value: "percentage", label: "Percentage", icon: Percent },{ value: "fixed", label: "Fixed", icon: DollarSign }].map((opt) => (
                        <button key={opt.value} type="button" onClick={() => form.setValue("margin_type", opt.value as "percentage" | "fixed")}
                          className={cn("flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all", watchedValues.margin_type === opt.value ? "border-[#ff4600] bg-[#ff4600] text-white" : "border-muted hover:border-[#ff4600]/50")}>
                          <opt.icon className="h-4 w-4" /><span>{opt.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div><Label htmlFor="margin_value">Margin Value</Label><Input id="margin_value" type="number" step="0.01" {...form.register("margin_value", { valueAsNumber: true })} className="mt-1" /></div>
                </div>
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl p-6 space-y-3">
                  <div className="flex justify-between"><span className="text-muted-foreground">Total Cost</span><span className="font-mono">{formatCurrency(getTotalCost(), watchedValues.currency)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Margin</span><span className="font-mono text-green-600">+{formatCurrency(getMarginAmount(), watchedValues.currency)}</span></div>
                  <Separator />
                  <div className="flex justify-between"><span className="font-bold text-lg">Selling Rate</span><span className="font-mono font-bold text-xl text-primary">{formatCurrency(getSellingRate(), watchedValues.currency)}</span></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 4: Terms */}
      {currentStep === 4 && (
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" />Terms & Conditions</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><Label htmlFor="validity_days">Validity (Days)</Label><Input id="validity_days" type="number" min={1} {...form.register("validity_days", { valueAsNumber: true })} className="mt-1" /></div>
              <div><Label htmlFor="payment_terms">Payment Terms</Label><Input id="payment_terms" {...form.register("payment_terms")} placeholder="30 days from invoice" className="mt-1" /></div>
            </div>
            <div><Label htmlFor="included_services">Included Services</Label><Textarea id="included_services" {...form.register("included_services")} rows={3} className="mt-1" /></div>
            <div><Label htmlFor="excluded_services">Excluded Services</Label><Textarea id="excluded_services" {...form.register("excluded_services")} rows={3} className="mt-1" /></div>
            <div><Label htmlFor="additional_notes">Notes</Label><Textarea id="additional_notes" {...form.register("additional_notes")} rows={3} className="mt-1" /></div>
          </CardContent>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between pt-6 border-t">
        <Button type="button" variant="outline" onClick={goPrev} disabled={currentStep === 1}><ArrowLeft className="h-4 w-4 mr-2" />Previous</Button>
        <div className="flex gap-3">
          {currentStep < 4 ? (
            <Button type="button" onClick={goNext} disabled={!canGoNext()}>Next<ArrowRight className="h-4 w-4 ml-2" /></Button>
          ) : (
            <>
              <Button type="button" variant="outline" onClick={() => handleSubmit("draft")} disabled={createMutation.isPending}>{createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}<Save className="h-4 w-4 mr-2" />Save Draft</Button>
              <Button type="button" onClick={() => handleSubmit("sent")} disabled={createMutation.isPending}>{createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}<Send className="h-4 w-4 mr-2" />Create & Send</Button>
            </>
          )}
        </div>
      </div>

      {/* Send Dialog */}
      <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Send Quotation</DialogTitle><DialogDescription>Quotation {createdNumber} created. How to proceed?</DialogDescription></DialogHeader>
          <div className="grid grid-cols-1 gap-3 py-4">
            <Button variant="outline" className="h-16 justify-start gap-4 px-4" onClick={() => handleShowPreview("email")} disabled={!watchedValues.customer_email}><Mail className="h-6 w-6 text-blue-600" /><div className="text-left"><p className="font-medium">Send via Email</p><p className="text-xs text-muted-foreground">With PDF attachment</p></div></Button>
            <Button variant="outline" className="h-16 justify-start gap-4 px-4" onClick={() => handleShowPreview("whatsapp")}><MessageCircle className="h-6 w-6 text-green-600" /><div className="text-left"><p className="font-medium">Send via WhatsApp</p><p className="text-xs text-muted-foreground">With rate breakdown</p></div></Button>
            <Button variant="outline" className="h-16 justify-start gap-4 px-4" onClick={() => handleShowPreview("download")}><Download className="h-6 w-6 text-orange-600" /><div className="text-left"><p className="font-medium">Download PDF</p><p className="text-xs text-muted-foreground">Save as PDF file</p></div></Button>
          </div>
          <div className="flex justify-end"><Button variant="ghost" onClick={() => { setShowSendDialog(false); router.push("/quotations"); }}>Skip & Close</Button></div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh]">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Eye className="h-5 w-5" />Preview Quotation</DialogTitle></DialogHeader>
          <SummaryPreview />
          <div className="flex justify-between pt-4 border-t">
            <Button variant="outline" onClick={() => { setShowPreviewDialog(false); toast.success("Quotation created successfully"); router.push("/quotations"); }}><ArrowLeft className="h-4 w-4 mr-2" />Back</Button>
            <Button onClick={handleConfirmAction} disabled={sendMutation.isPending || downloadMutation.isPending}>
              {(sendMutation.isPending || downloadMutation.isPending) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {pendingAction === "email" && <><Mail className="h-4 w-4 mr-2" />Send Email</>}
              {pendingAction === "whatsapp" && <><MessageCircle className="h-4 w-4 mr-2" />Send WhatsApp</>}
              {pendingAction === "download" && <><Download className="h-4 w-4 mr-2" />Download PDF</>}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
