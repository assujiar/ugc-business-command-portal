import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface Notification {
  id: string;
  user_id: string;
  ticket_id: string | null;
  type: string;
  title: string;
  message: string | null;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
  tickets?: {
    id: string;
    ticket_code: string;
    status: string;
  } | null;
}

interface NotificationsResponse {
  success: boolean;
  data: Notification[];
  unreadCount: number;
}

export function useNotifications(unreadOnly: boolean = false) {
  return useQuery<NotificationsResponse>({
    queryKey: ["notifications", { unreadOnly }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (unreadOnly) params.set("unread", "true");
      
      const res = await fetch(`/api/notifications?${params}`);
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json();
    },
    refetchInterval: 30000, // Refetch every 30 seconds
    staleTime: 10000,
  });
}

export function useMarkNotificationsRead() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ notification_ids, mark_all }: { notification_ids?: string[]; mark_all?: boolean }) => {
      const res = await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notification_ids, mark_all }),
      });
      if (!res.ok) throw new Error("Failed to mark notifications as read");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
}
