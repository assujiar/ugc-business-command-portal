import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

// ============ TYPES ============
export interface CostDetail {
  name: string;
  amount: number;
  unit?: string;
  description?: string;
  selling_amount?: number; // Amount after margin
}

export interface Quotation {
  id: string;
  quotation_number: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  customer_name: string;
  customer_company?: string;
  customer_email?: string;
  customer_phone?: string;
  customer_whatsapp?: string;
  customer_address?: string;
  cargo_description: string;
  cargo_category?: string;
  quantity?: number;
  unit_of_measure?: string;
  weight_kg?: number;
  volume_cbm?: number;
  hs_code?: string;
  shipment_type: string;
  incoterm?: string;
  fleet_type?: string;
  fleet_custom?: string;
  container_type?: string;
  container_quantity?: number;
  origin_address?: string;
  origin_city: string;
  origin_country?: string;
  origin_port?: string;
  destination_address?: string;
  destination_city: string;
  destination_country?: string;
  destination_port?: string;
  cost_type: "operations" | "bundling" | "detail";
  base_cost?: number;
  cost_details?: CostDetail[];
  margin_type: "percentage" | "fixed";
  margin_value: number;
  selling_rate: number;
  currency: string;
  validity_days?: number;
  valid_until?: string;
  payment_terms?: string;
  included_services?: string;
  excluded_services?: string;
  terms_conditions?: string;
  additional_notes?: string;
  status: "draft" | "sent" | "accepted" | "rejected" | "expired";
  sent_via?: "email" | "whatsapp";
  sent_at?: string;
  pdf_url?: string;
  ticket_id?: string;
  creator?: {
    id: string;
    full_name: string;
    email: string;
    department_id: string | null;
  } | null;
}

export interface QuotationListResponse {
  data: Quotation[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface QuotationFormData {
  customer_name: string;
  customer_company?: string;
  customer_email?: string;
  customer_phone?: string;
  customer_whatsapp?: string;
  customer_address?: string;
  cargo_description: string;
  cargo_category?: string;
  quantity?: number;
  unit_of_measure?: string;
  weight_kg?: number;
  volume_cbm?: number;
  hs_code?: string;
  shipment_type: string; // Changed from union to string
  incoterm?: string;
  fleet_type?: string;
  fleet_custom?: string;
  container_type?: string;
  container_quantity?: number;
  origin_address?: string;
  origin_city: string;
  origin_country?: string;
  origin_port?: string;
  destination_address?: string;
  destination_city: string;
  destination_country?: string;
  destination_port?: string;
  cost_type: "operations" | "bundling" | "detail";
  base_cost?: number;
  cost_details?: CostDetail[];
  margin_type: "percentage" | "fixed";
  margin_value: number;
  currency?: string;
  validity_days?: number;
  payment_terms?: string;
  included_services?: string;
  excluded_services?: string;
  terms_conditions?: string;
  additional_notes?: string;
  status?: "draft" | "sent";
}

// ============ API FUNCTIONS ============
async function fetchQuotations(params: {
  page?: number;
  limit?: number;
  status?: string;
  search?: string;
}): Promise<QuotationListResponse> {
  const searchParams = new URLSearchParams();
  if (params.page) searchParams.set("page", params.page.toString());
  if (params.limit) searchParams.set("limit", params.limit.toString());
  if (params.status && params.status !== "all") searchParams.set("status", params.status);
  if (params.search) searchParams.set("search", params.search);

  const response = await fetch(`/api/quotations?${searchParams}`);
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to fetch quotations");
  }
  return response.json();
}

async function fetchQuotation(id: string): Promise<{ data: Quotation }> {
  const response = await fetch(`/api/quotations/${id}`);
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to fetch quotation");
  }
  return response.json();
}

async function createQuotation(data: QuotationFormData): Promise<{ data: Quotation }> {
  const response = await fetch("/api/quotations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to create quotation");
  }
  return response.json();
}

async function updateQuotation(id: string, data: Partial<QuotationFormData>): Promise<{ data: Quotation }> {
  const response = await fetch(`/api/quotations/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to update quotation");
  }
  return response.json();
}

async function deleteQuotation(id: string): Promise<{ success: boolean }> {
  const response = await fetch(`/api/quotations/${id}`, { method: "DELETE" });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to delete quotation");
  }
  return response.json();
}

async function downloadPDF(id: string, quotationNumber: string): Promise<void> {
  const response = await fetch(`/api/quotations/${id}/pdf`, { method: "POST" });
  if (!response.ok) throw new Error("Failed to generate PDF");
  
  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${quotationNumber}.pdf`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

async function sendQuotation(
  id: string,
  method: "email" | "whatsapp"
): Promise<{ success: boolean; method: string; recipient: string; whatsappUrl?: string }> {
  const response = await fetch(`/api/quotations/${id}/send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ method }),
  });
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to send quotation");
  }
  return response.json();
}

// ============ HOOKS ============
export function useQuotations(params: { page?: number; limit?: number; status?: string; search?: string } = {}) {
  return useQuery({ queryKey: ["quotations", params], queryFn: () => fetchQuotations(params) });
}

export function useQuotation(id: string) {
  return useQuery({ queryKey: ["quotation", id], queryFn: () => fetchQuotation(id), enabled: !!id });
}

export function useCreateQuotation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createQuotation,
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["quotations"] }); },
  });
}

export function useUpdateQuotation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<QuotationFormData> }) => updateQuotation(id, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["quotations"] });
      queryClient.invalidateQueries({ queryKey: ["quotation", variables.id] });
    },
  });
}

export function useDeleteQuotation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deleteQuotation,
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["quotations"] }); },
  });
}

export function useDownloadPDF() {
  return useMutation({
    mutationFn: ({ id, quotationNumber }: { id: string; quotationNumber: string }) => downloadPDF(id, quotationNumber),
  });
}

export function useSendQuotation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, method }: { id: string; method: "email" | "whatsapp" }) => sendQuotation(id, method),
    onSuccess: (result, variables) => {
      queryClient.invalidateQueries({ queryKey: ["quotations"] });
      queryClient.invalidateQueries({ queryKey: ["quotation", variables.id] });
      if (result.whatsappUrl) window.open(result.whatsappUrl, "_blank");
    },
  });
}

// ============ HELPER FUNCTIONS ============
export function formatCurrency(amount: number, currency: string = "IDR"): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("id-ID", { year: "numeric", month: "short", day: "numeric" });
}

export function getStatusColor(status: Quotation["status"]): string {
  const colors: Record<Quotation["status"], string> = {
    draft: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    sent: "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300",
    accepted: "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300",
    rejected: "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300",
    expired: "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300",
  };
  return colors[status];
}

export function getShipmentLabel(type: string): string {
  const labels: Record<string, string> = {
    sea: "Ocean Freight", air: "Air Freight", land: "Inland Transportation",
    export_sea_lcl: "Export Seafreight LCL", export_sea_fcl: "Export Seafreight FCL",
    export_air: "Export Airfreight", import_sea_lcl: "Import Seafreight LCL",
    import_sea_fcl: "Import Seafreight FCL", import_air: "Import Airfreight",
    import_dtd_fcl: "Import DTD FCL", import_dtd_lcl: "Import DTD LCL",
    import_dtd_air: "Import DTD Airfreight", domestic_ftl: "Domestics FTL (Charter)",
    domestic_ltl: "Domestics LTL", domestic_sea_fcl: "Domestics Seafreight FCL",
    domestic_sea_lcl: "Domestics Seafreight LCL", domestic_air: "Domestics Airfreight",
    customs_clearance: "Customs Clearance", warehousing: "Warehousing & Fulfillment",
  };
  return labels[type] || "Freight";
}

export function calculateSellingRate(baseCost: number, marginType: "percentage" | "fixed", marginValue: number): number {
  if (marginType === "percentage") return baseCost * (1 + marginValue / 100);
  return baseCost + marginValue;
}

export function calculateTotalFromDetails(costDetails: CostDetail[]): number {
  return costDetails.reduce((sum, item) => sum + (item.amount || 0), 0);
}

// Calculate selling rate per component
export function calculateSellingDetails(
  costDetails: CostDetail[],
  marginType: "percentage" | "fixed",
  marginValue: number
): CostDetail[] {
  const totalCost = costDetails.reduce((sum, item) => sum + (item.amount || 0), 0);
  
  return costDetails.map(item => {
    let sellingAmount = item.amount || 0;
    
    if (marginType === "percentage") {
      sellingAmount = (item.amount || 0) * (1 + marginValue / 100);
    } else {
      // Fixed margin distributed proportionally
      const proportion = totalCost > 0 ? (item.amount || 0) / totalCost : 0;
      sellingAmount = (item.amount || 0) + (marginValue * proportion);
    }
    
    return {
      ...item,
      selling_amount: Math.round(sellingAmount),
    };
  });
}
