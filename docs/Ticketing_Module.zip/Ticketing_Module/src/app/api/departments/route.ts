﻿import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from("departments")
      .select(`
        id, code, name, description,
        sla_first_response_hours,
        sla_resolution_hours,
        sla_first_quote_hours,
        sla_stage_response_hours
      `)
      .order("name");

    if (error) {
      console.error("Departments fetch error:", error);
      return NextResponse.json({ success: false, message: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error("GET /api/departments error:", error);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}
