﻿import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth, isSuperAdmin } from "@/lib/auth";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = createAdminClient();

    const { data, error } = await supabase
      .from("departments")
      .select(`
        id, code, name, description,
        sla_first_response_hours,
        sla_resolution_hours,
        sla_first_quote_hours,
        sla_stage_response_hours
      `)
      .eq("id", id)
      .single();

    if (error) {
      return NextResponse.json({ success: false, message: error.message }, { status: 404 });
    }

    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error("GET /api/departments/[id] error:", error);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { profile } = authResult;

    if (!isSuperAdmin(profile)) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const supabase = createAdminClient();

    const updateData: Record<string, any> = {};
    
    if (body.name !== undefined) updateData.name = body.name;
    if (body.description !== undefined) updateData.description = body.description;
    if (body.sla_first_response_hours !== undefined) {
      updateData.sla_first_response_hours = parseInt(body.sla_first_response_hours, 10);
    }
    if (body.sla_resolution_hours !== undefined) {
      updateData.sla_resolution_hours = parseInt(body.sla_resolution_hours, 10);
    }
    if (body.sla_first_quote_hours !== undefined) {
      updateData.sla_first_quote_hours = parseInt(body.sla_first_quote_hours, 10);
    }
    if (body.sla_stage_response_hours !== undefined) {
      updateData.sla_stage_response_hours = parseInt(body.sla_stage_response_hours, 10);
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json({ success: false, message: "No fields to update" }, { status: 400 });
    }

    const { data, error } = await supabase
      .from("departments")
      .update(updateData)
      .eq("id", id)
      .select()
      .single();

    if (error) {
      console.error("Department update error:", error);
      return NextResponse.json({ success: false, message: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error("PATCH /api/departments/[id] error:", error);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}
