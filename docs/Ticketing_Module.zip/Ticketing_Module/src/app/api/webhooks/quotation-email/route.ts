import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import nodemailer from "nodemailer";
import { jsPDF } from "jspdf";

export const runtime = "nodejs";

const serviceLabels: Record<string, string> = {
  export_sea_lcl: "Export Seafreight LCL",
  export_sea_fcl: "Export Seafreight FCL",
  export_air: "Export Airfreight",
  import_sea_lcl: "Import Seafreight LCL",
  import_sea_fcl: "Import Seafreight FCL",
  import_air: "Import Airfreight",
  domestic_ftl: "Domestics FTL (Charter)",
  domestic_ltl: "Domestics LTL",
  domestic_sea_fcl: "Domestics Seafreight FCL",
  domestic_sea_lcl: "Domestics Seafreight LCL",
  domestic_air: "Domestics Airfreight",
  customs_clearance: "Customs Clearance",
  warehousing: "Warehousing & Fulfillment",
};

function formatCurrency(amount: number, currency: string = "IDR"): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
  }).format(amount);
}

function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// Generate PDF Buffer
function generatePDF(quotation: any, creatorName: string): Buffer {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  
  const primaryOrange: [number, number, number] = [255, 70, 0];
  const textDark: [number, number, number] = [33, 33, 33];
  const textLight: [number, number, number] = [100, 100, 100];
  
  const margin = 15;
  const pageWidth = 210;
  const contentWidth = pageWidth - margin * 2;
  let y = 15;

  // Header
  doc.setFillColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
  doc.rect(0, 0, pageWidth, 35, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  doc.text("UGC LOGISTICS", margin, 18);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.text("Excellence in Global Freight Solutions", margin, 26);

  // Quotation number
  doc.setFontSize(10);
  doc.text("QUOTATION", pageWidth - margin - 40, 15);
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.text(quotation.quotation_number || "", pageWidth - margin - 40, 23);

  y = 45;

  // Customer info
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text("BILL TO:", margin, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  if (quotation.customer_company) {
    doc.text(quotation.customer_company, margin, y);
    y += 5;
  }
  if (quotation.customer_name) {
    doc.text(quotation.customer_name, margin, y);
    y += 5;
  }
  if (quotation.customer_email) {
    doc.text(quotation.customer_email, margin, y);
    y += 5;
  }

  // Shipment details
  y = 45;
  const col2 = 120;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("SHIPMENT DETAILS:", col2, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  
  const serviceLabel = serviceLabels[quotation.shipment_type] || quotation.shipment_type || "Freight Services";
  doc.text(`Service: ${serviceLabel}`, col2, y);
  y += 5;
  if (quotation.incoterm) {
    doc.text(`Incoterm: ${quotation.incoterm}`, col2, y);
    y += 5;
  }
  doc.text(`Origin: ${quotation.origin_city || ""}, ${quotation.origin_country || ""}`, col2, y);
  y += 5;
  doc.text(`Destination: ${quotation.destination_city || ""}, ${quotation.destination_country || ""}`, col2, y);

  // Rate section
  y = 90;
  doc.setFillColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
  doc.rect(margin, y, contentWidth, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text("RATE BREAKDOWN", margin + 4, y + 5.5);

  y += 12;
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.setFont("helvetica", "normal");
  doc.text("Total Freight Rate", margin + 4, y);
  doc.text("Per Shipment", margin + 80, y);
  doc.setFont("helvetica", "bold");
  doc.text(formatCurrency(quotation.selling_rate || 0, quotation.currency || "IDR"), margin + 140, y);

  // Total box
  y += 15;
  doc.setFillColor(255, 237, 213);
  doc.rect(margin, y, contentWidth, 18, "F");
  doc.setDrawColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
  doc.rect(margin, y, contentWidth, 18, "S");
  doc.setTextColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
  doc.setFontSize(10);
  doc.text("TOTAL RATE", margin + 4, y + 7);
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.setFontSize(14);
  doc.text(formatCurrency(quotation.selling_rate || 0, quotation.currency || "IDR"), margin + 4, y + 14);

  // Terms
  y += 28;
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text("TERMS & CONDITIONS:", margin, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setTextColor(textLight[0], textLight[1], textLight[2]);
  
  const validUntil = quotation.valid_until ? formatDate(quotation.valid_until) : formatDate(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000));
  doc.text(`Valid Until: ${validUntil}`, margin, y);
  y += 5;
  if (quotation.payment_terms) {
    doc.text(`Payment Terms: ${quotation.payment_terms}`, margin, y);
  }

  // Included Services
  if (quotation.included_services) {
    y += 10;
    doc.setFillColor(220, 252, 231);
    doc.rect(margin, y, contentWidth, 12, "F");
    doc.setFontSize(7);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(22, 101, 52);
    doc.text("INCLUDED:", margin + 2, y + 4);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(21, 128, 61);
    doc.text(String(quotation.included_services).substring(0, 150), margin + 2, y + 9, { maxWidth: contentWidth - 4 });
    y += 12;
  }

  // Excluded Services
  if (quotation.excluded_services) {
    y += 2;
    doc.setFillColor(254, 226, 226);
    doc.rect(margin, y, contentWidth, 12, "F");
    doc.setFontSize(7);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(153, 27, 27);
    doc.text("EXCLUDED:", margin + 2, y + 4);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(185, 28, 28);
    doc.text(String(quotation.excluded_services).substring(0, 150), margin + 2, y + 9, { maxWidth: contentWidth - 4 });
    y += 12;
  }

  // Additional Notes
  if (quotation.additional_notes) {
    y += 2;
    doc.setFillColor(254, 249, 195);
    doc.rect(margin, y, contentWidth, 12, "F");
    doc.setFontSize(7);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(133, 77, 14);
    doc.text("NOTES:", margin + 2, y + 4);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(113, 63, 18);
    doc.text(String(quotation.additional_notes).substring(0, 150), margin + 2, y + 9, { maxWidth: contentWidth - 4 });
    y += 12;
  }

  // Footer
  y = 270;
  doc.setDrawColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  doc.setFontSize(8);
  doc.setTextColor(textLight[0], textLight[1], textLight[2]);
  doc.text(`Prepared by: ${creatorName}`, margin, y);
  doc.text("UGC Logistics - Excellence in Global Freight Solutions", pageWidth / 2, y + 5, { align: "center" });

  return Buffer.from(doc.output("arraybuffer"));
}

export async function POST(request: NextRequest) {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  let quotationId: string | null = null;

  try {
    // 1. Validate webhook secret
    const secret = request.headers.get("x-webhook-secret");
    if (secret !== process.env.SUPABASE_WEBHOOK_SECRET) {
      console.error("Invalid webhook secret");
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // 2. Parse payload
    const payload = await request.json();
    console.log("Webhook received for table:", payload.table, "type:", payload.type);

    // 3. Validate - only UPDATE on quotations with send_email_requested = true
    if (
      payload.type !== "UPDATE" ||
      payload.schema !== "public" ||
      payload.table !== "quotations" ||
      !payload.record?.send_email_requested
    ) {
      return NextResponse.json({ message: "Ignored" }, { status: 200 });
    }

    const quotation = payload.record;
    quotationId = quotation.id;

    // 4. Check customer email
    if (!quotation.customer_email) {
      console.error("No customer email for quotation:", quotationId);
      return NextResponse.json({ error: "No customer email" }, { status: 400 });
    }

    // 5. Idempotency - claim this email
    const { data: claimed, error: claimError } = await supabase.rpc("claim_quotation_email", {
      p_quotation_id: quotationId,
    });

    if (claimError) {
      console.error("Claim error:", claimError);
      return NextResponse.json({ error: "Claim failed" }, { status: 500 });
    }

    if (!claimed) {
      console.log("Already processed:", quotationId);
      return NextResponse.json({ message: "Already sent" }, { status: 200 });
    }

    // 6. Get creator info
    const { data: creator } = await supabase
      .from("users")
      .select("full_name, email, department_id")
      .eq("id", quotation.created_by)
      .single();

    const creatorName = creator?.full_name || "UGC Logistics Team";
    const creatorEmail = creator?.email || "";

    // 7. Get department manager email
    let managerEmail: string | null = null;
    if (creator?.department_id) {
      const { data: managers } = await supabase
        .from("users")
        .select("email, roles!inner(name)")
        .eq("department_id", creator.department_id)
        .in("roles.name", ["sales_manager", "marketing_manager"])
        .eq("is_active", true)
        .limit(1);

      managerEmail = managers?.[0]?.email || null;
    }

    // 8. Build CC list
    const ccList: string[] = [];
    if (creatorEmail) ccList.push(creatorEmail);
    if (managerEmail && managerEmail !== creatorEmail) ccList.push(managerEmail);

    const serviceLabel = serviceLabels[quotation.shipment_type] || quotation.shipment_type || "Freight Services";
    const sellingRate = quotation.selling_rate || 0;

    // 9. Generate PDF
    const pdfBuffer = generatePDF(quotation, creatorName);

    // 10. Build email HTML
    const emailHtml = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;">
  <div style="background:linear-gradient(135deg,#ff4600,#ff6b35);padding:20px;border-radius:8px 8px 0 0;">
    <h1 style="color:white;margin:0;">UGC LOGISTICS</h1>
    <p style="color:rgba(255,255,255,0.9);margin:5px 0 0;">Excellence in Global Freight Solutions</p>
  </div>
  
  <div style="border:1px solid #ddd;border-top:none;padding:20px;border-radius:0 0 8px 8px;">
    <p>Dear ${quotation.customer_name || "Valued Customer"},</p>
    <p>Thank you for your inquiry. Please find attached our quotation for your shipment requirements.</p>
    
    <table style="width:100%;border-collapse:collapse;margin:20px 0;background:#f9f9f9;">
      <tr><td style="padding:10px;font-weight:bold;">Quotation No:</td><td>${quotation.quotation_number}</td></tr>
      <tr><td style="padding:10px;font-weight:bold;">Service:</td><td>${serviceLabel}</td></tr>
      ${quotation.incoterm ? `<tr><td style="padding:10px;font-weight:bold;">Incoterm:</td><td>${quotation.incoterm}</td></tr>` : ""}
      <tr><td style="padding:10px;font-weight:bold;">Route:</td><td>${quotation.origin_city || ""} → ${quotation.destination_city || ""}</td></tr>
    </table>

    <div style="background:#fff3e0;padding:15px;border-radius:4px;border-left:4px solid #ff4600;">
      <p style="margin:0;font-size:18px;"><strong>Total Rate: ${formatCurrency(sellingRate, quotation.currency || "IDR")}</strong></p>
    </div>

    ${quotation.payment_terms ? `<p style="margin-top:15px;"><strong>Payment Terms:</strong> ${quotation.payment_terms}</p>` : ""}

    <div style="background:#f0f7ff;padding:15px;border-radius:4px;margin:20px 0;border-left:4px solid #2196f3;">
      <p style="margin:0;"><strong>Questions?</strong></p>
      <p style="margin:5px 0 0;">Please reply to this email or contact ${creatorName} at ${creatorEmail}</p>
    </div>

    <p>Best regards,<br><strong>${creatorName}</strong><br>UGC Logistics</p>
  </div>
</body>
</html>`;

    // 11. Send email via SMTP with PDF attachment
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || "465"),
      secure: process.env.SMTP_PORT === "465" || process.env.SMTP_SECURE === "true",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });

    const mailResult = await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: quotation.customer_email,
      cc: ccList.length > 0 ? ccList.join(",") : undefined,
      replyTo: creatorEmail || undefined,
      subject: `Quotation ${quotation.quotation_number} - UGC Logistics`,
      html: emailHtml,
      attachments: [
        {
          filename: `${quotation.quotation_number}.pdf`,
          content: pdfBuffer,
          contentType: "application/pdf",
        },
      ],
    });

    console.log("Email sent:", mailResult.messageId, "to:", quotation.customer_email);

    // 12. Update outbox with success
    await supabase
      .from("quotation_email_outbox")
      .update({
        sent_at: new Date().toISOString(),
        message_id: mailResult.messageId,
      })
      .eq("quotation_id", quotationId);

    // 13. Reset flag and update quotation status
    await supabase
      .from("quotations")
      .update({
        send_email_requested: false,
        status: quotation.status === "draft" ? "sent" : quotation.status,
        sent_via: "email",
        sent_at: new Date().toISOString(),
      })
      .eq("id", quotationId);

    return NextResponse.json({
      success: true,
      messageId: mailResult.messageId,
      recipient: quotation.customer_email,
    });
  } catch (error) {
    console.error("Webhook error:", error);

    // Log error to outbox
    if (quotationId) {
      await supabase
        .from("quotation_email_outbox")
        .update({ last_error: error instanceof Error ? error.message : "Unknown error" })
        .eq("quotation_id", quotationId);
        
      // Reset flag so user can retry
      await supabase
        .from("quotations")
        .update({ send_email_requested: false })
        .eq("id", quotationId);
    }

    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
