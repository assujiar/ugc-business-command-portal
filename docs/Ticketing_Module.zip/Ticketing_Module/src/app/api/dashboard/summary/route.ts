﻿import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth, isSuperAdmin, isManager } from "@/lib/auth";

// Lost reason labels
const LOST_REASON_LABELS: Record<string, string> = {
  price_too_high: "Price Too High",
  competitor_won: "Competitor Won",
  customer_cancelled: "Customer Cancelled",
  no_response: "No Response from Customer",
  service_unavailable: "Service Unavailable",
  other: "Other",
};

export async function GET() {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { profile } = authResult;

    const supabase = createAdminClient();

    let ticketQuery = supabase
      .from("tickets")
      .select(`
        id, status, priority, ticket_type, department_id,
        created_at, created_by, assigned_to, subject, ticket_code,
        close_outcome, close_reason, metadata,
        departments (id, code, name)
      `)
      .order("created_at", { ascending: false });

    if (!isSuperAdmin(profile)) {
      if (isManager(profile) && profile.department_id) {
        ticketQuery = ticketQuery.or(`department_id.eq.${profile.department_id},created_by.eq.${profile.id}`);
      } else {
        ticketQuery = ticketQuery.or(`created_by.eq.${profile.id},assigned_to.eq.${profile.id}`);
      }
    }

    const { data: tickets, error } = await ticketQuery;

    if (error) {
      console.error("Dashboard query error:", error);
      return NextResponse.json({ message: error.message, success: false }, { status: 500 });
    }

    const ticketList: any[] = tickets || [];

    // Calculate counts
    const statusCounts = {
      open: ticketList.filter((t) => t.status === "open").length,
      need_response: ticketList.filter((t) => t.status === "need_response").length,
      in_progress: ticketList.filter((t) => t.status === "in_progress").length,
      waiting_customer: ticketList.filter((t) => t.status === "waiting_customer").length,
      need_adjustment: ticketList.filter((t) => t.status === "need_adjustment").length,
      pending: ticketList.filter((t) => t.status === "pending").length,
      resolved: ticketList.filter((t) => t.status === "resolved").length,
      closed: ticketList.filter((t) => t.status === "closed").length,
    };

    const typeCounts = {
      rfq: ticketList.filter((t) => t.ticket_type === "RFQ").length,
      gen: ticketList.filter((t) => t.ticket_type === "GEN").length,
    };

    // RFQ outcome counts
    const closedTickets = ticketList.filter((t) => t.status === "closed");
    const wonTickets = closedTickets.filter((t) =>
      t.close_outcome === "won" || t.metadata?.resolution === "won"
    ).length;
    const lostTickets = closedTickets.filter((t) =>
      t.close_outcome === "lost" || t.metadata?.resolution === "lost"
    ).length;

    // Calculate lost reasons
    const lostReasonCounts: Record<string, number> = {};
    closedTickets
      .filter((t) => t.close_outcome === "lost" || t.metadata?.resolution === "lost")
      .forEach((t) => {
        const reason = t.close_reason || t.metadata?.close_reason || "other";
        lostReasonCounts[reason] = (lostReasonCounts[reason] || 0) + 1;
      });

    const lostReasons = Object.entries(lostReasonCounts)
      .map(([reason, count]) => ({
        reason,
        label: LOST_REASON_LABELS[reason] || reason.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()),
        count,
      }))
      .sort((a, b) => b.count - a.count);

    // Tickets by status for chart
    const ticketsByStatus = [
      { status: "Open", count: statusCounts.open },
      { status: "Need Response", count: statusCounts.need_response },
      { status: "In Progress", count: statusCounts.in_progress },
      { status: "Waiting Customer", count: statusCounts.waiting_customer },
      { status: "Pending", count: statusCounts.pending },
      { status: "Closed", count: statusCounts.closed },
    ].filter((s) => s.count > 0);

    // Tickets by department
    const deptCounts: Record<string, number> = {};
    ticketList.forEach((ticket) => {
      const deptName = ticket.departments?.name || "Unknown";
      deptCounts[deptName] = (deptCounts[deptName] || 0) + 1;
    });
    const ticketsByDepartment = Object.entries(deptCounts).map(([name, count]) => ({
      department: name,
      count,
    }));

    // Recent tickets
    const recentTickets = ticketList.slice(0, 5).map((t) => ({
      id: t.id,
      ticket_code: t.ticket_code,
      subject: t.subject,
      status: t.status,
      priority: t.priority,
      created_at: t.created_at,
      department: t.departments?.name || "Unknown",
    }));

    return NextResponse.json({
      success: true,
      data: {
        total_tickets: ticketList.length,
        open_tickets: statusCounts.open,
        need_response_tickets: statusCounts.need_response,
        in_progress_tickets: statusCounts.in_progress,
        waiting_customer_tickets: statusCounts.waiting_customer,
        pending_tickets: statusCounts.pending,
        closed_tickets: statusCounts.closed,
        rfq_tickets: typeCounts.rfq,
        gen_tickets: typeCounts.gen,
        won_tickets: wonTickets,
        lost_tickets: lostTickets,
        lost_reasons: lostReasons,
        tickets_by_status: ticketsByStatus,
        tickets_by_department: ticketsByDepartment,
        recent_tickets: recentTickets,
      },
    });
  } catch (error) {
    console.error("GET /api/dashboard/summary error:", error);
    return NextResponse.json({ message: "Internal server error", success: false }, { status: 500 });
  }
}
