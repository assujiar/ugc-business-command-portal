import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth, isSuperAdmin, isManager } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { profile } = authResult;

    const supabase = createAdminClient();
    const { searchParams } = new URL(request.url);
    const daysRaw = searchParams.get("days");
    const days = Number.isFinite(Number(daysRaw)) ? Math.max(1, parseInt(daysRaw as string, 10)) : 30;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Get departments with SLA settings
    const { data: departmentsData } = await supabase
      .from("departments")
      .select("id, code, name, sla_first_response_hours, sla_resolution_hours, sla_first_quote_hours, sla_stage_response_hours");

    const departmentSLA: Record<string, any> = {};
    (departmentsData || []).forEach((d: any) => {
      departmentSLA[d.id] = {
        name: d.name,
        code: d.code,
        sla_first_response: d.sla_first_response_hours || 4,
        sla_resolution: d.sla_resolution_hours || 72,
        sla_first_quote: d.sla_first_quote_hours || 24,
        sla_stage_response: d.sla_stage_response_hours || 4,
      };
    });

    // Use ticket_response_summary view which already calculates business hours
    let query = (supabase as any)
      .from("ticket_response_summary")
      .select("*")
      .gte("created_at", startDate.toISOString());

    // Role-based filtering
    if (!isSuperAdmin(profile)) {
      if (isManager(profile) && profile.department_id) {
        query = query.eq("department_id", profile.department_id);
      } else {
        query = query.or(`creator_id.eq.${profile.id}`);
      }
    }

    const { data: tickets, error: ticketsError } = await query;

    if (ticketsError) {
      console.error("Error fetching tickets:", ticketsError);
      return NextResponse.json({ success: false, message: ticketsError.message }, { status: 500 });
    }

    const ticketList = tickets || [];

    // Calculate metrics per department using business hours from view
    const deptMetrics: Record<string, {
      department_id: string;
      department_name: string;
      department_code: string;
      sla_targets: any;
      total_tickets: number;
      closed_tickets: number;
      first_response_times: number[];
      first_response_met: number;
      first_quote_times: number[];
      first_quote_met: number;
      rfq_tickets: number;
      resolution_times: number[];
      resolution_met: number;
    }> = {};

    // Initialize all departments
    Object.entries(departmentSLA).forEach(([deptId, sla]) => {
      deptMetrics[deptId] = {
        department_id: deptId,
        department_name: sla.name,
        department_code: sla.code,
        sla_targets: sla,
        total_tickets: 0,
        closed_tickets: 0,
        first_response_times: [],
        first_response_met: 0,
        first_quote_times: [],
        first_quote_met: 0,
        rfq_tickets: 0,
        resolution_times: [],
        resolution_met: 0,
      };
    });

    // Process each ticket using pre-calculated business hours
    ticketList.forEach((ticket: any) => {
      const deptId = ticket.department_id;
      if (!deptId || !deptMetrics[deptId]) return;

      const dm = deptMetrics[deptId];
      if (!dm) return;

      const sla = dm.sla_targets;

      dm.total_tickets++;

      // 1. First Response (already in business hours from view)
      if (ticket.first_response_hours !== null && ticket.first_response_hours !== undefined) {
        const responseTime = parseFloat(ticket.first_response_hours);
        if (!isNaN(responseTime)) {
          dm.first_response_times.push(responseTime);
          if (responseTime <= sla.sla_first_response) {
            dm.first_response_met++;
          }
        }
      }

      // 2. First Quote (RFQ tickets only, already in business hours)
      if (ticket.ticket_type === "RFQ") {
        dm.rfq_tickets++;
        if (ticket.first_quote_hours !== null && ticket.first_quote_hours !== undefined) {
          const quoteTime = parseFloat(ticket.first_quote_hours);
          if (!isNaN(quoteTime)) {
            dm.first_quote_times.push(quoteTime);
            if (quoteTime <= sla.sla_first_quote) {
              dm.first_quote_met++;
            }
          }
        }
      }

      // 3. Resolution (closed tickets only, already in business hours)
      if (ticket.status === "closed" && ticket.close_outcome) {
        dm.closed_tickets++;
        if (ticket.resolution_hours !== null && ticket.resolution_hours !== undefined) {
          const resolutionTime = parseFloat(ticket.resolution_hours);
          if (!isNaN(resolutionTime)) {
            dm.resolution_times.push(resolutionTime);
            if (resolutionTime <= sla.sla_resolution) {
              dm.resolution_met++;
            }
          }
        }
      }
    });

    // Calculate final metrics
    const metricsArray = Object.values(deptMetrics)
      .filter(m => m.total_tickets > 0)
      .map((m) => {
        const avgFirstResponse = m.first_response_times.length > 0
          ? m.first_response_times.reduce((a, b) => a + b, 0) / m.first_response_times.length
          : null;
        const avgFirstQuote = m.first_quote_times.length > 0
          ? m.first_quote_times.reduce((a, b) => a + b, 0) / m.first_quote_times.length
          : null;
        const avgResolution = m.resolution_times.length > 0
          ? m.resolution_times.reduce((a, b) => a + b, 0) / m.resolution_times.length
          : null;

        return {
          department: m.department_name,
          department_code: m.department_code,
          total_tickets: m.total_tickets,
          closed_tickets: m.closed_tickets,
          rfq_tickets: m.rfq_tickets,
          sla_first_response_hours: m.sla_targets.sla_first_response,
          sla_first_quote_hours: m.sla_targets.sla_first_quote,
          sla_resolution_hours: m.sla_targets.sla_resolution,
          first_response_compliance: m.first_response_times.length > 0
            ? Math.round((m.first_response_met / m.first_response_times.length) * 100)
            : null,
          first_response_avg_hours: avgFirstResponse !== null ? Math.round(avgFirstResponse * 100) / 100 : null,
          first_response_count: m.first_response_times.length,
          first_quote_compliance: m.first_quote_times.length > 0
            ? Math.round((m.first_quote_met / m.first_quote_times.length) * 100)
            : null,
          first_quote_avg_hours: avgFirstQuote !== null ? Math.round(avgFirstQuote * 100) / 100 : null,
          first_quote_count: m.first_quote_times.length,
          resolution_compliance: m.resolution_times.length > 0
            ? Math.round((m.resolution_met / m.resolution_times.length) * 100)
            : null,
          resolution_avg_hours: avgResolution !== null ? Math.round(avgResolution * 100) / 100 : null,
          resolution_count: m.resolution_times.length,
        };
      });

    // Calculate trend data
    const trendMap: Record<string, { date: string; created: number; closed: number }> = {};
    for (let i = 0; i < Math.min(days, 30); i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split("T")[0];
      if (dateStr) {
        trendMap[dateStr] = { date: dateStr, created: 0, closed: 0 };
      }
    }

    ticketList.forEach((ticket: any) => {
      const createdDate = ticket.created_at?.split("T")[0];
      const closedDate = ticket.closed_at?.split("T")[0];
      if (createdDate && trendMap[createdDate]) trendMap[createdDate].created++;
      if (closedDate && trendMap[closedDate]) trendMap[closedDate].closed++;
    });

    const trend = Object.values(trendMap).sort((a, b) =>
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    // Overall metrics
    const allFirstResponse = metricsArray.filter(m => m.first_response_compliance !== null);
    const allResolution = metricsArray.filter(m => m.resolution_compliance !== null);

    const overall = {
      total_tickets: ticketList.length,
      first_response_compliance: allFirstResponse.length > 0
        ? Math.round(allFirstResponse.reduce((s, m) => s + (m.first_response_compliance || 0), 0) / allFirstResponse.length)
        : 0,
      resolution_compliance: allResolution.length > 0
        ? Math.round(allResolution.reduce((s, m) => s + (m.resolution_compliance || 0), 0) / allResolution.length)
        : 0,
    };

    return NextResponse.json({
      success: true,
      data: {
        metrics: metricsArray,
        trend,
        overall,
      }
    });
  } catch (error) {
    console.error("GET /api/dashboard/sla-metrics error:", error);
    return NextResponse.json({ message: "Internal server error", success: false }, { status: 500 });
  }
}