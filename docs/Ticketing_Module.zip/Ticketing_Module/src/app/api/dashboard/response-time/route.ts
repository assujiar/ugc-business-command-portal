﻿import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth, isSuperAdmin, isManager } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { profile } = authResult;

    const supabase = createAdminClient();

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Get all tickets first to determine creators
    let ticketQuery = supabase
      .from("tickets")
      .select("id, created_by, department_id")
      .gte("created_at", thirtyDaysAgo.toISOString());

    if (!isSuperAdmin(profile)) {
      if (isManager(profile) && profile.department_id) {
        ticketQuery = ticketQuery.eq("department_id", profile.department_id);
      } else {
        ticketQuery = ticketQuery.or(`created_by.eq.${profile.id},assigned_to.eq.${profile.id}`);
      }
    }

    const { data: tickets } = await ticketQuery;
    const ticketList = tickets || [];
    const ticketIds = ticketList.map(t => t.id);
    const ticketCreators: Record<string, string> = {};
    ticketList.forEach(t => {
      ticketCreators[t.id] = t.created_by;
    });

    if (ticketIds.length === 0) {
      return NextResponse.json({
        success: true,
        data: {
          userMetrics: [],
          roleMetrics: [],
          overall: { totalUsers: 0, totalResponses: 0, avgResponseTimeHours: 0 },
        },
      });
    }

    // Get comments for these tickets
    const { data: comments } = await supabase
      .from("ticket_comments")
      .select(`
        id,
        user_id,
        created_at,
        ticket_id,
        user:users!ticket_comments_user_id_fkey (
          id,
          full_name,
          role_id,
          department_id,
          roles (name, display_name),
          departments (name, code)
        )
      `)
      .in("ticket_id", ticketIds)
      .eq("is_internal", false)
      .order("ticket_id", { ascending: true })
      .order("created_at", { ascending: true });

    let userMetrics: any[] = [];

    if (comments && comments.length > 0) {
      // Group comments by ticket
      const ticketComments: Record<string, any[]> = {};
      comments.forEach((comment: any) => {
        const ticketId = comment.ticket_id;
        if (!ticketId) return;
        if (!ticketComments[ticketId]) ticketComments[ticketId] = [];
        ticketComments[ticketId]!.push(comment);
      });

      // Calculate response times per user
      const userStats: Record<string, {
        userId: string;
        userName: string;
        role: string;
        department: string;
        departmentId: string;
        responseTimes: number[];
        responseCount: number;
      }> = {};

      Object.entries(ticketComments).forEach(([ticketId, commentList]) => {
        const creator = ticketCreators[ticketId];
        
        for (let i = 0; i < commentList.length; i++) {
          const currentComment = commentList[i];
          if (!currentComment) continue;

          const userId = currentComment.user_id;
          const user = currentComment.user;
          if (!userId) continue;

          // Skip if user is the ticket creator (they're not "responding")
          if (userId === creator) continue;

          // Calculate time from previous event
          let responseTime: number;
          if (i === 0) {
            // First response - time from ticket creation
            const ticket = ticketList.find(t => t.id === ticketId);
            if (!ticket) continue;
            // We don't have ticket created_at here, skip first response timing for now
            continue;
          } else {
            const prevComment = commentList[i - 1];
            if (!prevComment || currentComment.user_id === prevComment.user_id) continue;
            responseTime = (new Date(currentComment.created_at).getTime() -
                            new Date(prevComment.created_at).getTime()) / (1000 * 60 * 60);
          }

          if (!userStats[userId]) {
            userStats[userId] = {
              userId,
              userName: user?.full_name || "Unknown User",
              role: user?.roles?.display_name || user?.roles?.name || "User",
              department: user?.departments?.name || "Unknown",
              departmentId: user?.department_id || "",
              responseTimes: [],
              responseCount: 0,
            };
          }

          const userData = userStats[userId];
          if (userData && responseTime > 0 && responseTime < 720) {
            userData.responseTimes.push(responseTime);
            userData.responseCount++;
          }
        }
      });

      // Calculate averages
      userMetrics = Object.values(userStats).map((u) => {
        const avgTime = u.responseTimes.length > 0
          ? u.responseTimes.reduce((a, b) => a + b, 0) / u.responseTimes.length
          : 0;

        const sorted = [...u.responseTimes].sort((a, b) => a - b);
        const medianTime = sorted.length > 0 ? (sorted[Math.floor(sorted.length / 2)] ?? 0) : 0;

        return {
          userId: u.userId,
          userName: u.userName,
          role: u.role,
          department: u.department,
          departmentId: u.departmentId,
          totalResponses: u.responseCount,
          avgResponseTimeHours: Math.round(avgTime * 10) / 10,
          medianResponseTimeHours: Math.round(medianTime * 10) / 10,
        };
      }).filter(u => u.totalResponses > 0);
    }

    // Calculate roleMetrics from userMetrics
    const roleMap: Record<string, {
      role: string;
      userCount: number;
      totalResponses: number;
      totalTimeSum: number;
    }> = {};

    userMetrics.forEach((u) => {
      const roleName = u.role || "User";
      if (!roleMap[roleName]) {
        roleMap[roleName] = { role: roleName, userCount: 0, totalResponses: 0, totalTimeSum: 0 };
      }
      const roleData = roleMap[roleName];
      if (roleData) {
        roleData.userCount++;
        roleData.totalResponses += u.totalResponses;
        roleData.totalTimeSum += u.avgResponseTimeHours * u.totalResponses;
      }
    });

    const roleMetrics = Object.values(roleMap).map((r) => ({
      role: r.role,
      userCount: r.userCount,
      totalResponses: r.totalResponses,
      avgResponseTimeHours: r.totalResponses > 0
        ? Math.round((r.totalTimeSum / r.totalResponses) * 10) / 10
        : 0,
    }));

    // Sort
    userMetrics.sort((a, b) => b.totalResponses - a.totalResponses);
    roleMetrics.sort((a, b) => b.totalResponses - a.totalResponses);

    // Overall metrics
    const allResponseTimes = userMetrics.flatMap(u =>
      Array(u.totalResponses).fill(u.avgResponseTimeHours)
    );
    const overallAvg = allResponseTimes.length > 0
      ? allResponseTimes.reduce((a, b) => a + b, 0) / allResponseTimes.length
      : 0;

    const overall = {
      totalUsers: userMetrics.length,
      totalResponses: userMetrics.reduce((sum, u) => sum + u.totalResponses, 0),
      avgResponseTimeHours: Math.round(overallAvg * 10) / 10,
    };

    return NextResponse.json({
      success: true,
      data: {
        userMetrics: userMetrics.slice(0, 10),
        roleMetrics,
        overall,
      },
    });
  } catch (error) {
    console.error("GET /api/dashboard/response-time error:", error);
    return NextResponse.json({ message: "Internal server error", success: false }, { status: 500 });
  }
}
