import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth, isSuperAdmin } from "@/lib/auth";
import type { CreateUserRequest } from "@/types/api";

export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { profile } = authResult;
    if (!isSuperAdmin(profile)) {
      return NextResponse.json({ message: "Access denied", success: false }, { status: 403 });
    }
    const supabase = createAdminClient();
    const { searchParams } = new URL(request.url);
    let query = supabase
      .from("users")
      .select("*, roles (id, name, display_name), departments (id, code, name)")
      .order("created_at", { ascending: false });
    const department = searchParams.get("department");
    const role = searchParams.get("role");
    const active = searchParams.get("active");
    if (department && department !== "all") query = query.eq("department_id", department);
    if (role && role !== "all") query = query.eq("role_id", role);
    if (active !== null && active !== "all") query = query.eq("is_active", active === "true");
    const { data, error } = await query;
    if (error) {
      return NextResponse.json({ message: error.message, success: false }, { status: 500 });
    }
    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error("GET /api/admin/users error:", error);
    return NextResponse.json({ message: "Internal server error", success: false }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { profile } = authResult;
    if (!isSuperAdmin(profile)) {
      return NextResponse.json({ message: "Access denied", success: false }, { status: 403 });
    }
    const body: CreateUserRequest = await request.json();
    if (!body.email || !body.password || !body.full_name || !body.role_id) {
      return NextResponse.json({ message: "Missing required fields", success: false }, { status: 400 });
    }
    const adminClient = createAdminClient();
    
    // 1. Create auth user (this triggers handle_new_user which auto-creates public.users)
    const { data: authData, error: authError } = await adminClient.auth.admin.createUser({
      email: body.email,
      password: body.password,
      email_confirm: true,
      user_metadata: { full_name: body.full_name }
    });
    if (authError) {
      return NextResponse.json({ message: authError.message, success: false }, { status: 400 });
    }
    
    // 2. Wait a bit for trigger to complete
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // 3. UPDATE the auto-created user with correct role and department
    const { data: updatedUser, error: updateError } = await adminClient
      .from("users")
      .update({
        full_name: body.full_name,
        role_id: body.role_id,
        department_id: body.department_id || null,
        is_active: true,
      })
      .eq("id", authData.user.id)
      .select("*, roles (id, name, display_name), departments (id, code, name)")
      .single();
    
    if (updateError) {
      // Cleanup auth user if update fails
      await adminClient.auth.admin.deleteUser(authData.user.id);
      return NextResponse.json({ message: updateError.message, success: false }, { status: 500 });
    }
    
    return NextResponse.json({ success: true, data: updatedUser }, { status: 201 });
  } catch (error) {
    console.error("POST /api/admin/users error:", error);
    return NextResponse.json({ message: "Internal server error", success: false }, { status: 500 });
  }
}
