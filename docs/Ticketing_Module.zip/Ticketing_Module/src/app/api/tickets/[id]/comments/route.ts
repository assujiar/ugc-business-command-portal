import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth } from "@/lib/auth";
import { notifyTicketResponse } from "@/lib/email/notifications";
import { UPLOAD_LIMITS } from "@/lib/constants";

// Bucket name yang benar
const STORAGE_BUCKET = "attachments";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = createAdminClient();
    
    // Get comments
    const { data: comments, error } = await supabase
      .from("ticket_comments")
      .select(`
        *,
        user:users!ticket_comments_user_id_fkey (
          id,
          full_name,
          email
        )
      `)
      .eq("ticket_id", id)
      .order("created_at", { ascending: true });
      
    if (error) {
      console.error("Comments fetch error:", error);
      return NextResponse.json({ success: false, message: error.message }, { status: 500 });
    }

    // Get all attachments for this ticket that have comment_id
    const { data: attachments, error: attError } = await supabase
      .from("ticket_attachments")
      .select("*")
      .eq("ticket_id", id)
      .not("comment_id", "is", null);
    
    if (attError) {
      console.error("Attachments fetch error:", attError);
    }

    // Group attachments by comment_id
    const attachmentsByComment: Record<string, any[]> = {};
    if (attachments) {
      for (const att of attachments as any[]) {
        const commentId = att.comment_id;
        if (commentId) {
          if (!attachmentsByComment[commentId]) {
            attachmentsByComment[commentId] = [];
          }
          attachmentsByComment[commentId].push(att);
        }
      }
    }

    // Merge attachments into comments
    const commentsWithAttachments = comments?.map(comment => ({
      ...comment,
      attachments: attachmentsByComment[comment.id] || []
    })) || [];

    return NextResponse.json({ success: true, data: commentsWithAttachments });
  } catch (error) {
    console.error("GET /api/tickets/[id]/comments error:", error);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authResult = await requireAuth();
    if ("error" in authResult) {
      return authResult.error;
    }
    const { user, profile } = authResult;
    const { id } = await params;

    const supabase = createAdminClient();

    // Check content type - bisa JSON atau FormData
    const contentType = request.headers.get("content-type") || "";

    let content: string | null = null;
    let isInternal = false;
    let type = "comment";
    let metadata: any = null;
    let files: File[] = [];

    if (contentType.includes("multipart/form-data")) {
      // Handle FormData (dengan attachment)
      const formData = await request.formData();
      content = formData.get("content") as string | null;
      isInternal = formData.get("is_internal") === "true";
      type = (formData.get("type") as string) || "comment";
      const metadataStr = formData.get("metadata") as string | null;
      if (metadataStr) {
        try { metadata = JSON.parse(metadataStr); } catch {}
      }

      // Get all files
      const fileEntries = formData.getAll("files");
      for (const entry of fileEntries) {
        if (entry instanceof File && entry.size > 0) {
          files.push(entry);
        }
      }
    } else {
      // Handle JSON
      const body = await request.json();
      content = body.content || null;
      isInternal = body.is_internal || false;
      type = body.type || "comment";
      metadata = body.metadata || null;
    }

    // Validate - harus ada content atau files
    if (!content?.trim() && files.length === 0) {
      return NextResponse.json({ success: false, message: "Please enter a message or attach a file" }, { status: 400 });
    }

    const { data: ticket } = await supabase
      .from("tickets")
      .select("created_by, department_id, status, ticket_type, ticket_code")
      .eq("id", id)
      .single();

    const isCreator = ticket?.created_by === user.id;
    const isDeptResponding = profile.department_id === ticket?.department_id;
    const isRFQ = ticket?.ticket_type === "RFQ";

    // Insert comment
    const { data: comment, error: commentError } = await supabase
      .from("ticket_comments")
      .insert({
        ticket_id: id,
        user_id: user.id,
        content: content || null,
        is_internal: isInternal,
        type: type,
        metadata: metadata,
      } as any)
      .select(`
        *,
        user:users!ticket_comments_user_id_fkey (
          id,
          full_name,
          email
        )
      `)
      .single();

    if (commentError) {
      console.error("Comment insert error:", commentError);
      return NextResponse.json({ success: false, message: commentError.message }, { status: 500 });
    }

    // Upload attachments if any
    const uploadedAttachments = [];
    for (const file of files) {
      // Validate file size
      if (file.size > UPLOAD_LIMITS.MAX_SIZE_BYTES) {
        console.log(`Skipping ${file.name}: exceeds size limit`);
        continue;
      }

      // Validate file type
      const allowedTypes: readonly string[] = UPLOAD_LIMITS.ALLOWED_TYPES;
      if (!allowedTypes.includes(file.type)) {
        console.log(`Skipping ${file.name}: invalid type ${file.type}`);
        continue;
      }

      // Path: comments/[ticket_code]/[comment_id]/[timestamp]-[filename]
      const filePath = `comments/${ticket?.ticket_code || id}/${comment.id}/${Date.now()}-${file.name}`;

      const { error: uploadError } = await supabase.storage
        .from(STORAGE_BUCKET)
        .upload(filePath, file);

      if (uploadError) {
        console.error("Upload error:", uploadError);
        continue;
      }

      const { data: urlData } = supabase.storage
        .from(STORAGE_BUCKET)
        .getPublicUrl(filePath);

      // Insert attachment record with comment_id
      const { data: attachment, error: attachError } = await supabase
        .from("ticket_attachments")
        .insert({
          ticket_id: id,
          comment_id: comment.id,
          file_name: file.name,
          file_url: urlData.publicUrl,
          file_type: file.type,
          file_size: file.size,
          uploaded_by: user.id,
        } as any)
        .select()
        .single();

      if (attachError) {
        console.error("Attachment insert error:", attachError);
      } else if (attachment) {
        uploadedAttachments.push(attachment);
      }
    }

    // Determine new status based on type or who responded
    let newStatus = ticket?.status || "open";
    if (type === "status_change") {
      // Don't change status - handled by ticket PATCH
    } else if (type === "waiting_customer") {
      newStatus = "waiting_customer";
    } else if (type === "need_adjustment") {
      newStatus = "need_adjustment";
    } else if (isDeptResponding && !isCreator) {
      newStatus = "need_response";
    } else if (isCreator) {
      newStatus = isRFQ ? "open" : "in_progress";
    }

    // Update ticket status if not a status_change
    if (type !== "status_change") {
      await supabase
        .from("tickets")
        .update({ status: newStatus, updated_at: new Date().toISOString() } as any)
        .eq("id", id);
    }

    // Send email notification for regular comments (non-blocking)
    if (type === "comment" || !type) {
      notifyTicketResponse(id, user.id, content || "(attachment)").catch(err => {
        console.error("Failed to send comment notification:", err);
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        ...comment,
        attachments: uploadedAttachments
      }
    }, { status: 201 });
  } catch (error) {
    console.error("POST /api/tickets/[id]/comments error:", error);
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 });
  }
}
