﻿import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAuth, isSuperAdmin, isManager } from "@/lib/auth";
import type { AssignTicketRequest } from "@/types/api";
import type { Json } from "@/types/database";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const authResult = await requireAuth();
    if ("error" in authResult) return authResult.error;
    const { user, profile } = authResult;

    const body: AssignTicketRequest = await request.json();
    const supabase = createAdminClient();

    if (!isSuperAdmin(profile) && !isManager(profile)) {
      return NextResponse.json({ message: "Not authorized to assign tickets", success: false }, { status: 403 });
    }

    const { data: ticket, error: ticketError } = await supabase
      .from("tickets")
      .select("*")
      .eq("id", id)
      .single();

    if (ticketError || !ticket) {
      return NextResponse.json({ message: "Ticket not found", success: false }, { status: 404 });
    }

    if (!isSuperAdmin(profile) && ticket.department_id !== profile.department_id) {
      return NextResponse.json({ message: "Cannot assign tickets from other departments", success: false }, { status: 403 });
    }

    const { data: assignee, error: assigneeError } = await supabase
      .from("users")
      .select("id, full_name, is_active")
      .eq("id", body.assigned_to)
      .single();

    if (assigneeError || !assignee) {
      return NextResponse.json({ message: "Assignee not found", success: false }, { status: 400 });
    }

    if (!assignee.is_active) {
      return NextResponse.json({ message: "Cannot assign to inactive user", success: false }, { status: 400 });
    }

    const notes = body.notes ?? "";

    const { error: assignError } = await supabase.rpc("assign_ticket", {
      p_ticket_id: id,
      p_assigned_to: body.assigned_to,
      p_assigned_by: user.id,
      p_notes: notes,
    });

    if (assignError) {
      return NextResponse.json({ message: assignError.message, success: false }, { status: 500 });
    }

    const { data: updatedTicket } = await supabase
      .from("tickets")
      .select(
        `*, departments (id, code, name),
        creator:users!tickets_created_by_fkey (id, full_name, email),
        assignee:users!tickets_assigned_to_fkey (id, full_name, email)`
      )
      .eq("id", id)
      .single();

    const oldData = JSON.parse(JSON.stringify({ assigned_to: ticket.assigned_to ?? null })) as Json;
    const newData = JSON.parse(JSON.stringify({ assigned_to: body.assigned_to, assigned_by: user.id, notes: notes || null })) as Json;

    await supabase.rpc("log_audit", {
      p_table_name: "tickets",
      p_record_id: id,
      p_action: "update",
      p_old_data: oldData,
      p_new_data: newData,
      p_user_id: user.id,
      p_ip_address: request.headers.get("x-forwarded-for") ?? "",
    });

    return NextResponse.json({
      success: true,
      data: updatedTicket,
      message: `Ticket assigned to ${assignee.full_name ?? "user"}`,
    });
  } catch (error) {
    console.error("POST /api/tickets/[id]/assign error:", error);
    return NextResponse.json({ message: "Internal server error", success: false }, { status: 500 });
  }
}
