import { createServerClient } from "@/lib/supabase/server";
import { NextRequest, NextResponse } from "next/server";
import { QuotationRow, QuotationUpdate } from "@/types/quotation";

// GET - Fetch single quotation
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = await createServerClient();
    
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data, error } = await supabase
      .from("quotations")
      .select("*")
      .eq("id", id)
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
      }
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ data: data as QuotationRow });
  } catch (error) {
    console.error("Error in GET /api/quotations/[id]:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// PATCH - Update quotation
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = await createServerClient();
    
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();

    // Recalculate selling rate if cost changed
    if (body.cost_type || body.base_cost !== undefined || body.cost_details || body.margin_type || body.margin_value !== undefined) {
      const { data: current } = await supabase
        .from("quotations")
        .select("*")
        .eq("id", id)
        .single();

      const currentData = current as QuotationRow | null;

      if (currentData) {
        let totalCost = 0;
        const costType = body.cost_type ?? currentData.cost_type;

        if (costType === "bundling" || costType === "operations") {
          totalCost = parseFloat(String(body.base_cost ?? currentData.base_cost)) || 0;
        } else if (costType === "detail") {
          const costDetails = body.cost_details ?? currentData.cost_details ?? [];
          const detailsArray = Array.isArray(costDetails) ? costDetails : [];
          totalCost = detailsArray.reduce((sum: number, item: { amount?: number }) => sum + (parseFloat(String(item.amount)) || 0), 0);
        }

        const marginType = body.margin_type ?? currentData.margin_type;
        const marginValue = parseFloat(String(body.margin_value ?? currentData.margin_value)) || 0;

        let sellingRate = totalCost;
        if (marginType === "percentage") {
          sellingRate = totalCost * (1 + marginValue / 100);
        } else {
          sellingRate = totalCost + marginValue;
        }

        body.base_cost = totalCost;
        body.selling_rate = sellingRate;
      }
    }

    // Update valid_until if validity_days changed
    if (body.validity_days) {
      const validUntil = new Date();
      validUntil.setDate(validUntil.getDate() + parseInt(body.validity_days));
      body.valid_until = validUntil.toISOString().split("T")[0];
    }

    const updateData: QuotationUpdate = {
      ...body,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from("quotations")
      .update(updateData as never)
      .eq("id", id)
      .select()
      .single();

    if (error) {
      console.error("Error updating quotation:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ data: data as QuotationRow });
  } catch (error) {
    console.error("Error in PATCH /api/quotations/[id]:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// DELETE - Delete quotation
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = await createServerClient();
    
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if quotation exists and is draft
    const { data: quotation } = await supabase
      .from("quotations")
      .select("status")
      .eq("id", id)
      .single();

    const quotationData = quotation as QuotationRow | null;

    if (!quotationData) {
      return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
    }

    if (quotationData.status === "accepted") {
      return NextResponse.json({ error: "Accepted quotations cannot be deleted" }, { status: 400 });
    }

    const { error } = await supabase
      .from("quotations")
      .delete()
      .eq("id", id);

    if (error) {
      console.error("Error deleting quotation:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error in DELETE /api/quotations/[id]:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
