import { createServerClient } from "@/lib/supabase/server";
import { NextRequest, NextResponse } from "next/server";
import { QuotationRow, CostDetailItem } from "@/types/quotation";
import { jsPDF } from "jspdf";
import QRCode from "qrcode";
import fs from "fs";
import path from "path";

function formatCurrency(amount: number, currency: string = "IDR"): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

const serviceLabels: Record<string, string> = {
  DOM_FTL: "Domestics FTL (Charter)",
  DOM_LTL: "Domestics LTL",
  DOM_LCL: "Domestics LCL",
  DOM_FCL: "Domestics FCL",
  DOM_AF: "Domestics AF",
  WAREHOUSING: "Warehousing",
  FULFILLMENT: "Fulfillment",
  EXP_LCL: "Export LCL",
  EXP_FCL: "Export FCL",
  EXP_AF: "Export AF",
  IMP_LCL: "Import LCL",
  IMP_FCL: "Import FCL",
  IMP_AF: "Import AF",
  CUSTOMS: "Customs Clearance",
  IMP_DTD: "Import DTD",
  PROJECT: "Project Cargo",
  HEAVY: "Heavy Duty Cargo",
  sea: "Ocean Freight",
  air: "Air Freight",
  land: "Land Transport",
};

function calculateSellingPerComponent(
  costDetails: CostDetailItem[],
  marginType: string | null,
  marginValue: number | null
): Array<CostDetailItem & { selling_amount: number }> {
  const totalCost = costDetails.reduce((sum, item) => sum + (item.amount || 0), 0);
  const mType = marginType || "percentage";
  const mValue = marginValue || 0;
  return costDetails.map(item => {
    let sellingAmount = item.amount || 0;
    if (mType === "percentage") {
      sellingAmount = (item.amount || 0) * (1 + mValue / 100);
    } else {
      const proportion = totalCost > 0 ? (item.amount || 0) / totalCost : 0;
      sellingAmount = (item.amount || 0) + (mValue * proportion);
    }
    return { ...item, selling_amount: Math.round(sellingAmount) };
  });
}

function getLogoBase64(): string | null {
  try {
    const logoPath = path.join(process.cwd(), "public", "whitelogougc.png");
    const logoBuffer = fs.readFileSync(logoPath);
    return "data:image/png;base64," + logoBuffer.toString("base64");
  } catch (e) {
    console.error("Failed to load logo:", e);
    return null;
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = await createServerClient();

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data, error } = await supabase
      .from("quotations")
      .select("*, creator:users!quotations_created_by_fkey(full_name, email)")
      .eq("id", id)
      .single();

    if (error || !data) {
      return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
    }

    const q = data as QuotationRow & { creator?: { full_name: string; email: string } };
    const creatorName = (q as any).creator?.full_name || "Sales Team";
    
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 12;
    const contentWidth = pageWidth - margin * 2;

    const primaryOrange: [number, number, number] = [255, 70, 0];
    const textDark: [number, number, number] = [31, 41, 55];
    const textLight: [number, number, number] = [107, 114, 128];
    
    const serviceLabel = serviceLabels[q.shipment_type || "sea"] || q.shipment_type || "Freight Services";
    const costDetails: CostDetailItem[] = q.cost_details && Array.isArray(q.cost_details) ? q.cost_details as CostDetailItem[] : [];
    const hasDetailCosts = q.cost_type === "detail" && costDetails.length > 0;
    const sellingDetails = hasDetailCosts ? calculateSellingPerComponent(costDetails, q.margin_type, q.margin_value) : [];
    const sellingRate = q.selling_rate || 0;

    // Generate QR Code
    const validationUrl = `https://ugc-ticketing-web.vercel.app/quotations/verify/${q.id}`;
    let qrDataUrl = "";
    try {
      qrDataUrl = await QRCode.toDataURL(validationUrl, { width: 150, margin: 1 });
    } catch (e) {
      console.error("QR generation error:", e);
    }

    // Get Logo
    const logoBase64 = getLogoBase64();

    let y = 0;

    // ===== HEADER - Orange Background =====
    doc.setFillColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.rect(0, 0, pageWidth, 28, "F");

    // Logo Image (aspect ratio 975:447 = 2.18:1)
    if (logoBase64) {
      doc.addImage(logoBase64, "PNG", margin, 4, 44, 20);
    } else {
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("UGC LOGISTICS", margin, 16);
    }

    // Quotation Label - Right Side
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text("QUOTATION", pageWidth - margin, 10, { align: "right" });
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(q.quotation_number, pageWidth - margin, 18, { align: "right" });

    // ===== Date Bar =====
    y = 34;
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Issue Date:", margin, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(formatDate(q.created_at), margin + 18, y);

    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Valid Until:", pageWidth - margin - 42, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.text(formatDate(q.valid_until || ""), pageWidth - margin - 22, y);

    // ===== QUOTATION TO =====
    y = 42;
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.text("QUOTATION TO", margin, y);

    y += 5;
    doc.setFontSize(11);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(q.customer_company || q.customer_name, margin, y);

    y += 4;
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    if (q.customer_company && q.customer_name) {
      doc.text("Attn: " + q.customer_name, margin, y);
      y += 3.5;
    }
    if (q.customer_email) {
      doc.text("Email: " + q.customer_email, margin, y);
      y += 3.5;
    }

    y += 3;
    doc.setFontSize(7);
    doc.text("Dear Valued Customer,", margin, y);
    y += 3.5;
    doc.text("Thank you for your inquiry. We are pleased to submit our quotation for your shipment requirements.", margin, y);

    // ===== SHIPMENT DETAILS =====
    y += 8;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.setFontSize(9);
    doc.text("SHIPMENT DETAILS", margin, y);
    doc.setDrawColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.setLineWidth(0.5);
    doc.line(margin, y + 1.5, margin + 32, y + 1.5);

    y += 5;
    doc.setFillColor(248, 248, 248);
    doc.rect(margin, y, contentWidth, 22, "F");

    const col1 = margin + 4;
    const col2 = margin + 30;
    const col3 = margin + 95;
    const col4 = margin + 120;

    y += 6;
    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Service Type", col1, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(serviceLabel, col2, y);

    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Incoterm", col3, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(q.incoterm || "EXW", col4, y);

    y += 7;
    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Origin", col1, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text((q.origin_city || "") + ", " + (q.origin_country || ""), col2, y);

    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Destination", col3, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text((q.destination_city || "") + ", " + (q.destination_country || ""), col4, y);

    y += 7;
    doc.setFont("helvetica", "normal");
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Cargo", col1, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(String(q.cargo_description || "").substring(0, 60), col2, y);

    // ===== RATE BREAKDOWN =====
    y += 10;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.setFontSize(9);
    doc.text("RATE BREAKDOWN", margin, y);
    doc.setDrawColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.line(margin, y + 1.5, margin + 30, y + 1.5);

    y += 5;
    // Table Header
    doc.setFillColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.rect(margin, y, contentWidth, 6, "F");
    doc.setFontSize(7);
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.text("DESCRIPTION", margin + 4, y + 4);
    doc.text("UNIT", margin + 90, y + 4);
    doc.text("RATE", margin + 140, y + 4);
    y += 6;

    if (hasDetailCosts && sellingDetails.length > 0) {
      sellingDetails.forEach((item, idx) => {
        if (idx % 2 === 0) {
          doc.setFillColor(255, 255, 255);
        } else {
          doc.setFillColor(252, 252, 252);
        }
        doc.rect(margin, y, contentWidth, 6, "F");
        doc.setTextColor(textDark[0], textDark[1], textDark[2]);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(7);
        doc.text(item.name || "-", margin + 4, y + 4);
        doc.text(item.unit || "Per Shipment", margin + 90, y + 4);
        doc.setFont("helvetica", "bold");
        if (item.selling_amount > 0) {
          doc.text(formatCurrency(item.selling_amount, q.currency || "IDR"), margin + 140, y + 4);
        }
        y += 6;
      });
    } else {
      doc.setFillColor(252, 252, 252);
      doc.rect(margin, y, contentWidth, 6, "F");
      doc.setTextColor(textDark[0], textDark[1], textDark[2]);
      doc.setFont("helvetica", "normal");
      doc.text("Total Freight Rate", margin + 4, y + 4); doc.text("Per Shipment", margin + 90, y + 4); doc.setFont("helvetica", "bold"); doc.text(formatCurrency(sellingRate, q.currency || "IDR"), margin + 140, y + 4);
      y += 6;
    }

    // ===== TOTAL RATE BOX =====
    y += 3;
    doc.setFillColor(255, 237, 213);
    doc.rect(margin, y, contentWidth, 16, "F");
    doc.setDrawColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.setLineWidth(0.4);
    doc.rect(margin, y, contentWidth, 16, "S");

    doc.setFontSize(8);
    doc.setTextColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.setFont("helvetica", "bold");
    doc.text("TOTAL RATE", margin + 4, y + 5);

    doc.setFontSize(14);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(formatCurrency(sellingRate, q.currency || "IDR"), margin + 4, y + 12);

    // ===== TERMS & CONDITIONS =====
    y += 22;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.setFontSize(9);
    doc.text("TERMS & CONDITIONS", margin, y);
    doc.setDrawColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.line(margin, y + 1.5, margin + 36, y + 1.5);

    y += 6;
    doc.setFontSize(7);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text("Payment Terms:", margin, y);
    doc.setFont("helvetica", "normal");
    doc.text(q.payment_terms || "30 days from invoice date", margin + 26, y);

    y += 4;
    doc.setFont("helvetica", "bold");
    doc.text("Validity:", margin, y);
    doc.setFont("helvetica", "normal");
    doc.text((q.validity_days || 14) + " days from quotation date", margin + 15, y);

    // Included
    if (q.included_services) {
      y += 6;
      doc.setFillColor(220, 252, 231);
      doc.rect(margin, y, contentWidth, 10, "F");
      doc.setFontSize(6);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(22, 101, 52);
      doc.text("INCLUDED", margin + 2, y + 3);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(6);
      doc.text(String(q.included_services).substring(0, 140), margin + 2, y + 7, { maxWidth: contentWidth - 4 });
      y += 10;
    }

    // Excluded
    if (q.excluded_services) {
      y += 2;
      doc.setFillColor(254, 226, 226);
      doc.rect(margin, y, contentWidth, 10, "F");
      doc.setFontSize(6);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(153, 27, 27);
      doc.text("EXCLUDED", margin + 2, y + 3);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(185, 28, 28);
      doc.text(String(q.excluded_services).substring(0, 140), margin + 2, y + 7, { maxWidth: contentWidth - 4 });
      y += 10;
    }

    // ===== CLOSING =====
    y += 6;
    doc.setFontSize(7);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.setFont("helvetica", "normal");
    doc.text("We trust this quotation meets your requirements.", margin, y);

    y += 6;
    doc.text("Yours sincerely,", margin, y);
    y += 4;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text(creatorName, margin, y);
    y += 3;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(textLight[0], textLight[1], textLight[2]);
    doc.text("Sales & Commercial Department", margin, y);

    // QR Code - Bottom Right
    if (qrDataUrl) {
      doc.addImage(qrDataUrl, "PNG", pageWidth - margin - 22, y - 12, 22, 22);
    }

    // ===== FOOTER - Orange Background =====
    doc.setFillColor(primaryOrange[0], primaryOrange[1], primaryOrange[2]);
    doc.rect(0, pageHeight - 10, pageWidth, 10, "F");
    doc.setFontSize(7);
    doc.setTextColor(255, 255, 255);
    doc.text("PT Utama Globalindo Cargo | We Care What We Deliver", pageWidth / 2, pageHeight - 4, { align: "center" });

    const pdfOutput = doc.output("arraybuffer");
    return new Response(pdfOutput, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${q.quotation_number}.pdf"`,
      },
    });
  } catch (error) {
    console.error("Error generating PDF:", error);
    return NextResponse.json({
      error: "Failed to generate PDF",
      details: error instanceof Error ? error.message : "Unknown error"
    }, { status: 500 });
  }
}
