import { createServerClient } from "@/lib/supabase/server";
import { NextRequest, NextResponse } from "next/server";
import { QuotationRow } from "@/types/quotation";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = await createServerClient();

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await request.json();
    const { method } = body;
    
    if (!method || !["email", "whatsapp"].includes(method)) {
      return NextResponse.json({ error: "Invalid method" }, { status: 400 });
    }

    const { data, error } = await supabase.from("quotations").select("*").eq("id", id).single();
    if (error || !data) return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
    
    const quotation = data as QuotationRow;

    if (method === "email") {
      if (!quotation.customer_email) {
        return NextResponse.json({ error: "Customer email not found" }, { status: 400 });
      }

      // Set flag - webhook will handle the actual sending
      const { error: updateError } = await supabase
        .from("quotations")
        .update({ send_email_requested: true } as never)
        .eq("id", id);

      if (updateError) {
        return NextResponse.json({ error: "Failed to queue email" }, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        method: "email",
        recipient: quotation.customer_email,
        message: "Email queued",
      });
    } else {
      const phone = quotation.customer_whatsapp || quotation.customer_phone;
      if (!phone) return NextResponse.json({ error: "Customer phone not found" }, { status: 400 });

      const message = generateWhatsAppMessage(quotation);
      const cleanPhone = phone.replace(/[^0-9]/g, "");

      await supabase
        .from("quotations")
        .update({
          status: quotation.status === "draft" ? "sent" : quotation.status,
          sent_via: "whatsapp",
          sent_at: new Date().toISOString(),
        } as never)
        .eq("id", id);

      return NextResponse.json({
        success: true,
        method: "whatsapp",
        recipient: phone,
        whatsappUrl: `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`,
      });
    }
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

function generateWhatsAppMessage(q: QuotationRow): string {
  const labels: Record<string, string> = {
    export_sea_lcl: "Export Seafreight LCL", export_sea_fcl: "Export Seafreight FCL",
    import_sea_lcl: "Import Seafreight LCL", import_sea_fcl: "Import Seafreight FCL",
    domestic_ftl: "Domestics FTL", domestic_ltl: "Domestics LTL",
  };
  const fmt = (n: number, c: string = "IDR") => new Intl.NumberFormat("id-ID", { style: "currency", currency: c, minimumFractionDigits: 0 }).format(n);
  const svc = labels[q.shipment_type || ""] || q.shipment_type || "Freight";
  let m = `*UGC LOGISTICS - QUOTATION*\n\n📋 *${q.quotation_number}*\n\n*Service:* ${svc}\n`;
  if (q.incoterm) m += `*Incoterm:* ${q.incoterm}\n`;
  m += `*Route:* ${q.origin_city || ""} → ${q.destination_city || ""}\n\n`;
  m += `💰 *TOTAL: ${fmt(q.selling_rate || 0, q.currency || "IDR")}*\n\n`;
  if (q.payment_terms) m += `*Payment:* ${q.payment_terms}\n\n`;
  m += `Thank you for choosing UGC Logistics! 🚚✈️🚢`;
  return m;
}
