import { createServerClient } from "@/lib/supabase/server";
import { NextRequest, NextResponse } from "next/server";
import { QuotationRow, QuotationInsert } from "@/types/quotation";

// Helper to get user profile with role info
async function getUserProfile(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("users")
    .select(`
      id,
      email,
      full_name,
      role_id,
      department_id,
      is_active,
      roles (id, name, display_name)
    `)
    .eq("id", userId)
    .single();

  if (error) return null;
  return data;
}

function isSuperAdmin(profile: any): boolean {
  return profile?.roles?.name === "super_admin";
}

function isManager(profile: any): boolean {
  const roleName = profile?.roles?.name || "";
  return roleName.includes("manager");
}

// GET - Fetch quotations list with role-based filtering
export async function GET(request: NextRequest) {
  try {
    const supabase = await createServerClient();

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user profile with role
    const profile = await getUserProfile(supabase, user.id);
    if (!profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const search = searchParams.get("search");
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "10");
    const offset = (page - 1) * limit;

    let query = supabase
      .from("quotations")
      .select("*, creator:users!quotations_created_by_fkey(id, full_name, email, department_id)", { count: "exact" })
      .order("created_at", { ascending: false });

    // Role-based filtering
    if (isSuperAdmin(profile)) {
      // Super Admin: can see ALL quotations
      // No filter needed
    } else if (isManager(profile)) {
      // Manager: can see quotations from their department
      // Need to join with users to filter by creator's department
      if (profile.department_id) {
        // Get all users in the same department
        const { data: deptUsers } = await supabase
          .from("users")
          .select("id")
          .eq("department_id", profile.department_id);
        
        if (deptUsers && deptUsers.length > 0) {
          const userIds = deptUsers.map((u: any) => u.id);
          query = query.in("created_by", userIds);
        } else {
          // No users in department, only show own quotations
          query = query.eq("created_by", user.id);
        }
      } else {
        // No department assigned, only show own quotations
        query = query.eq("created_by", user.id);
      }
    } else {
      // Staff/Salesperson: can only see their OWN quotations
      query = query.eq("created_by", user.id);
    }

    // Apply status filter
    if (status && status !== "all") {
      query = query.eq("status", status);
    }

    // Apply search filter
    if (search) {
      query = query.or(
        `quotation_number.ilike.%${search}%,customer_name.ilike.%${search}%,customer_company.ilike.%${search}%`
      );
    }

    // Apply pagination
    query = query.range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error("Error fetching quotations:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({
      data: data as QuotationRow[],
      pagination: {
        page,
        limit,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / limit),
      },
      meta: {
        role: profile.roles?.name,
        canViewAll: isSuperAdmin(profile),
        canViewDepartment: isManager(profile),
      }
    });
  } catch (error) {
    console.error("Error in GET /api/quotations:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// POST - Create new quotation
export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient();

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();

    // Validate required fields
    const requiredFields = ["customer_name", "cargo_description", "origin_city", "destination_city", "cost_type"];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ error: `Field '${field}' is required` }, { status: 400 });
      }
    }

    // Calculate total cost
    let totalCost = 0;
    if (body.cost_type === "bundling" || body.cost_type === "operations") {
      totalCost = parseFloat(body.base_cost) || 0;
    } else if (body.cost_type === "detail") {
      const costDetails = body.cost_details || [];
      totalCost = costDetails.reduce((sum: number, item: { amount?: number }) => sum + (parseFloat(String(item.amount)) || 0), 0);
    }

    // Calculate selling rate
    let sellingRate = totalCost;
    const marginValue = parseFloat(body.margin_value) || 0;
    if (body.margin_type === "percentage") {
      sellingRate = totalCost * (1 + marginValue / 100);
    } else if (body.margin_type === "fixed") {
      sellingRate = totalCost + marginValue;
    }

    // Calculate valid_until
    const validityDays = parseInt(body.validity_days) || 14;
    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + validityDays);

    const quotationData: QuotationInsert = {
      created_by: user.id,
      customer_name: body.customer_name,
      customer_company: body.customer_company || null,
      customer_email: body.customer_email || null,
      customer_phone: body.customer_phone || null,
      customer_whatsapp: body.customer_whatsapp || body.customer_phone || null,
      customer_address: body.customer_address || null,
      cargo_description: body.cargo_description,
      cargo_category: body.cargo_category || "Genco",
      quantity: body.quantity || null,
      unit_of_measure: body.unit_of_measure || null,
      weight_kg: body.weight_kg || null,
      volume_cbm: body.volume_cbm || null,
      hs_code: body.hs_code || null,
      shipment_type: body.shipment_type || "sea",
      incoterm: body.incoterm || "FOB",
      container_type: body.container_type || null,
      container_quantity: body.container_quantity || 1,
      origin_address: body.origin_address || null,
      origin_city: body.origin_city,
      origin_country: body.origin_country || "Indonesia",
      origin_port: body.origin_port || null,
      destination_address: body.destination_address || null,
      destination_city: body.destination_city,
      destination_country: body.destination_country || null,
      destination_port: body.destination_port || null,
      cost_type: body.cost_type,
      base_cost: totalCost,
      cost_details: body.cost_type === "detail" ? body.cost_details : null,
      margin_type: body.margin_type || "percentage",
      margin_value: marginValue,
      selling_rate: sellingRate,
      currency: body.currency || "IDR",
      validity_days: validityDays,
      valid_until: validUntil.toISOString().split("T")[0],
      payment_terms: body.payment_terms || "30 days from invoice date",
      included_services: body.included_services || null,
      excluded_services: body.excluded_services || null,
      terms_conditions: body.terms_conditions || null,
      additional_notes: body.additional_notes || null,
      status: body.status || "draft",
    };

    const { data, error } = await supabase
      .from("quotations")
      .insert(quotationData as never)
      .select()
      .single();

    if (error) {
      console.error("Error creating quotation:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ data: data as QuotationRow }, { status: 201 });
  } catch (error) {
    console.error("Error in POST /api/quotations:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}