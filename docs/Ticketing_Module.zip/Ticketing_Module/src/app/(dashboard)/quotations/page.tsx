﻿import QuotationsPage from "@/components/quotations/quotations-page";

export default function Page() {
  return <QuotationsPage />;
}
