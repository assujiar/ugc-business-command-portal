"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  ArrowLeft,
  Save,
  Loader2,
  User,
  Package,
  Calculator,
  FileText,
  Building,
  Phone,
  Mail,
  MessageCircle,
  MapPin,
  Ship,
  Plane,
  Truck,
  Plus,
  Trash2,
  Globe,
  DollarSign,
  Percent,
  Home,
  Warehouse,
  Container,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectGroup,
  SelectLabel,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  useQuotation,
  useUpdateQuotation,
  formatCurrency,
  calculateSellingRate,
  calculateTotalFromDetails,
  CostDetail,
} from "@/hooks/useQuotations";

// Fleet options
const fleetOptions = [
  { value: "blind_van", label: "Blind Van" },
  { value: "cde_bak", label: "CDE Bak" },
  { value: "cde_box", label: "CDE Box" },
  { value: "cde_reefer", label: "CDE Reefer" },
  { value: "cdd_bak", label: "CDD Bak" },
  { value: "cdd_box", label: "CDD Box" },
  { value: "cdd_long", label: "CDD Long" },
  { value: "cdd_reefer", label: "CDD Reefer" },
  { value: "fuso_bak", label: "Fuso Bak" },
  { value: "fuso_box", label: "Fuso Box" },
  { value: "tronton_wingbox", label: "Tronton Wingbox" },
  { value: "tronton_pickup", label: "Tronton Pickup" },
  { value: "trailer_20ft", label: "Trailer 20 Feet" },
  { value: "trailer_40ft", label: "Trailer 40 Feet" },
  { value: "trailer_flatbed", label: "Trailer Flatbed" },
  { value: "airfreight", label: "Airfreight" },
  { value: "seafreight", label: "Seafreight" },
  { value: "other", label: "Lainnya" },
];

const isDomesticService = (serviceValue: string | undefined): boolean => serviceValue?.startsWith("domestic_") ?? false;
const needsIncoterm = (serviceValue: string | undefined): boolean => (serviceValue?.startsWith("export_") || serviceValue?.startsWith("import_")) ?? false;

const containerTypes = [
  { value: "20ft", label: "20ft Standard" },
  { value: "40ft", label: "40ft Standard" },
  { value: "40ft_hc", label: "40ft High Cube" },
  { value: "45ft_hc", label: "45ft High Cube" },
  { value: "20ft_rf", label: "20ft Reefer" },
  { value: "40ft_rf", label: "40ft Reefer" },
  { value: "lcl", label: "LCL (Less Container Load)" },
];

const serviceTypesList = [
  { value: "export_sea_lcl", label: "Export Seafreight LCL", icon: Ship },
  { value: "export_sea_fcl", label: "Export Seafreight FCL", icon: Container },
  { value: "export_air", label: "Export Airfreight", icon: Plane },
  { value: "import_sea_lcl", label: "Import Seafreight LCL", icon: Ship },
  { value: "import_sea_fcl", label: "Import Seafreight FCL", icon: Container },
  { value: "import_air", label: "Import Airfreight", icon: Plane },
  { value: "import_dtd_fcl", label: "Import DTD FCL", icon: Home },
  { value: "import_dtd_lcl", label: "Import DTD LCL", icon: Home },
  { value: "import_dtd_air", label: "Import DTD Airfreight", icon: Plane },
  { value: "domestic_ftl", label: "Domestics FTL", icon: Truck },
  { value: "domestic_ltl", label: "Domestics LTL", icon: Truck },
  { value: "domestic_sea_fcl", label: "Domestics Seafreight FCL", icon: Ship },
  { value: "domestic_sea_lcl", label: "Domestics Seafreight LCL", icon: Ship },
  { value: "domestic_air", label: "Domestics Airfreight", icon: Plane },
  { value: "customs_clearance", label: "Customs Clearance", icon: FileText },
  { value: "warehousing", label: "Warehousing & Fulfillment", icon: Warehouse },
];

const quotationSchema = z.object({
  customer_name: z.string().min(1, "Customer name is required"),
  customer_company: z.string().optional(),
  customer_email: z.string().email("Invalid email").optional().or(z.literal("")),
  customer_phone: z.string().optional(),
  customer_whatsapp: z.string().optional(),
  customer_address: z.string().optional(),
  cargo_description: z.string().min(1, "Cargo description is required"),
  quantity: z.number().optional(),
  weight_kg: z.number().optional(),
  volume_cbm: z.number().optional(),
  hs_code: z.string().optional(),
  shipment_type: z.string().min(1, "Service type is required"),
  incoterm: z.string().optional(),
  fleet_type: z.string().optional(),
  fleet_custom: z.string().optional(),
  container_type: z.string().optional(),
  container_quantity: z.number().optional(),
  origin_city: z.string().min(1, "Origin city is required"),
  origin_country: z.string().optional(),
  origin_port: z.string().optional(),
  destination_city: z.string().min(1, "Destination city is required"),
  destination_country: z.string().optional(),
  destination_port: z.string().optional(),
  cost_type: z.enum(["operations", "bundling", "detail"]),
  base_cost: z.number().optional(),
  margin_type: z.enum(["percentage", "fixed"]),
  margin_value: z.number().min(0),
  currency: z.string(),
  validity_days: z.number().min(1),
  payment_terms: z.string().optional(),
  included_services: z.string().optional(),
  excluded_services: z.string().optional(),
  additional_notes: z.string().optional(),
});

type FormData = z.infer<typeof quotationSchema>;

export default function EditQuotationPage() {
  const params = useParams();
  const router = useRouter();
  const quotationId = params.id as string;
  
  const { data, isLoading, error } = useQuotation(quotationId);
  const updateMutation = useUpdateQuotation();
  const [costDetails, setCostDetails] = useState<CostDetail[]>([]);

  const form = useForm<FormData>({
    resolver: zodResolver(quotationSchema),
    defaultValues: {
      cost_type: "bundling",
      margin_type: "percentage",
      margin_value: 15,
      currency: "IDR",
      validity_days: 14,
    },
  });

  const watchedValues = form.watch();
  const quotation = data?.data;

  // Populate form when data loads
  useEffect(() => {
    if (quotation) {
      form.reset({
        customer_name: quotation.customer_name || "",
        customer_company: quotation.customer_company || "",
        customer_email: quotation.customer_email || "",
        customer_phone: quotation.customer_phone || "",
        customer_whatsapp: quotation.customer_whatsapp || "",
        customer_address: quotation.customer_address || "",
        cargo_description: quotation.cargo_description || "",
        quantity: quotation.quantity || undefined,
        weight_kg: quotation.weight_kg || undefined,
        volume_cbm: quotation.volume_cbm || undefined,
        hs_code: quotation.hs_code || "",
        shipment_type: quotation.shipment_type || "",
        incoterm: quotation.incoterm || "FOB",
        fleet_type: quotation.fleet_type || "",
        container_type: quotation.container_type || "",
        container_quantity: quotation.container_quantity || 1,
        origin_city: quotation.origin_city || "",
        origin_country: quotation.origin_country || "",
        origin_port: quotation.origin_port || "",
        destination_city: quotation.destination_city || "",
        destination_country: quotation.destination_country || "",
        destination_port: quotation.destination_port || "",
        cost_type: (quotation.cost_type as "operations" | "bundling" | "detail") || "bundling",
        base_cost: quotation.base_cost || 0,
        margin_type: (quotation.margin_type as "percentage" | "fixed") || "percentage",
        margin_value: quotation.margin_value || 15,
        currency: quotation.currency || "IDR",
        validity_days: quotation.validity_days || 14,
        payment_terms: quotation.payment_terms || "",
        included_services: quotation.included_services || "",
        excluded_services: quotation.excluded_services || "",
        additional_notes: quotation.additional_notes || "",
      });
      
      if (quotation.cost_details && Array.isArray(quotation.cost_details)) {
        setCostDetails(quotation.cost_details as CostDetail[]);
      }
    }
  }, [quotation, form]);

  const getTotalCost = (): number => {
    if (watchedValues.cost_type === "bundling" || watchedValues.cost_type === "operations") {
      return watchedValues.base_cost || 0;
    }
    return calculateTotalFromDetails(costDetails);
  };

  const getSellingRate = (): number => {
    return calculateSellingRate(getTotalCost(), watchedValues.margin_type, watchedValues.margin_value || 0);
  };

  const handleSubmit = async () => {
    const isValid = await form.trigger();
    if (!isValid) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      const values = form.getValues();
      // Remove fields that don't exist in database
      const { fleet_type, fleet_custom, ...updateData } = values;
      await updateMutation.mutateAsync({
        id: quotationId,
        data: {
          ...updateData,
          base_cost: getTotalCost(),
          cost_details: watchedValues.cost_type === "detail" ? costDetails : undefined,
        },
      });
      toast.success("Quotation updated successfully");
      router.push(`/quotations/${quotationId}`);
    } catch (error: any) {
      toast.error(error.message || "Failed to update quotation");
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !quotation) {
    return (
      <Card>
        <CardContent className="py-16 text-center">
          <h2 className="text-xl font-semibold mb-2">Quotation Not Found</h2>
          <Button onClick={() => router.push("/quotations")}>
            <ArrowLeft className="h-4 w-4 mr-2" />Back to Quotations
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push(`/quotations/${quotationId}`)}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Edit Quotation</h1>
            <p className="text-muted-foreground font-mono">{quotation.quotation_number}</p>
          </div>
        </div>
        <Button onClick={handleSubmit} disabled={updateMutation.isPending}>
          {updateMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
          <Save className="h-4 w-4 mr-2" />Save Changes
        </Button>
      </div>

      {/* Customer Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><User className="h-5 w-5" />Customer Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>Company Name</Label>
              <Input {...form.register("customer_company")} className="mt-1" />
            </div>
            <div>
              <Label>Contact Person *</Label>
              <Input {...form.register("customer_name")} className="mt-1" />
            </div>
            <div>
              <Label>Email</Label>
              <Input {...form.register("customer_email")} type="email" className="mt-1" />
            </div>
            <div>
              <Label>Phone</Label>
              <Input {...form.register("customer_phone")} className="mt-1" />
            </div>
            <div>
              <Label>WhatsApp</Label>
              <Input {...form.register("customer_whatsapp")} className="mt-1" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Shipment */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Package className="h-5 w-5" />Shipment Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Service Type *</Label>
            <Select value={watchedValues.shipment_type} onValueChange={(v) => form.setValue("shipment_type", v)}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {serviceTypesList.map((s) => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {needsIncoterm(watchedValues.shipment_type) && (
              <div>
                <Label>Incoterm</Label>
                <Select value={watchedValues.incoterm} onValueChange={(v) => form.setValue("incoterm", v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EXW">EXW</SelectItem>
                    <SelectItem value="FOB">FOB</SelectItem>
                    <SelectItem value="CIF">CIF</SelectItem>
                    <SelectItem value="CFR">CFR</SelectItem>
                    <SelectItem value="DDP">DDP</SelectItem>
                    <SelectItem value="DAP">DAP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {isDomesticService(watchedValues.shipment_type) && (
              <div>
                <Label>Fleet / Mode</Label>
                <Select value={watchedValues.fleet_type} onValueChange={(v) => form.setValue("fleet_type", v)}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select fleet" /></SelectTrigger>
                  <SelectContent>
                    <ScrollArea className="h-[200px]">
                      {fleetOptions.map((f) => (
                        <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                      ))}
                    </ScrollArea>
                  </SelectContent>
                </Select>
              </div>
            )}

            {isDomesticService(watchedValues.shipment_type) && watchedValues.fleet_type === "other" && (
              <div>
                <Label>Specify Fleet</Label>
                <Input {...form.register("fleet_custom")} placeholder="Enter fleet type..." className="mt-1" />
              </div>
            )}

            <div>
              <Label>Container Type</Label>
              <Select value={watchedValues.container_type} onValueChange={(v) => form.setValue("container_type", v)}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {containerTypes.map((c) => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Quantity</Label>
              <Input type="number" min={1} {...form.register("container_quantity", { valueAsNumber: true })} className="mt-1" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-3 p-4 rounded-lg border border-green-500/50">
              <h4 className="font-medium text-green-600 flex items-center gap-2"><MapPin className="h-4 w-4" />Origin</h4>
              <div>
                <Label>City *</Label>
                <Input {...form.register("origin_city")} className="mt-1" />
              </div>
              <div>
                <Label>Country</Label>
                <Input {...form.register("origin_country")} className="mt-1" />
              </div>
              <div>
                <Label>Port</Label>
                <Input {...form.register("origin_port")} className="mt-1" />
              </div>
            </div>

            <div className="space-y-3 p-4 rounded-lg border border-red-500/50">
              <h4 className="font-medium text-red-600 flex items-center gap-2"><MapPin className="h-4 w-4" />Destination</h4>
              <div>
                <Label>City *</Label>
                <Input {...form.register("destination_city")} className="mt-1" />
              </div>
              <div>
                <Label>Country</Label>
                <Input {...form.register("destination_country")} className="mt-1" />
              </div>
              <div>
                <Label>Port</Label>
                <Input {...form.register("destination_port")} className="mt-1" />
              </div>
            </div>
          </div>

          <div>
            <Label>Cargo Description *</Label>
            <Textarea {...form.register("cargo_description")} rows={2} className="mt-1" />
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div>
              <Label>Quantity</Label>
              <Input type="number" {...form.register("quantity", { valueAsNumber: true })} className="mt-1" />
            </div>
            <div>
              <Label>Weight (KG)</Label>
              <Input type="number" step="0.01" {...form.register("weight_kg", { valueAsNumber: true })} className="mt-1" />
            </div>
            <div>
              <Label>Volume (CBM)</Label>
              <Input type="number" step="0.01" {...form.register("volume_cbm", { valueAsNumber: true })} className="mt-1" />
            </div>
            <div>
              <Label>HS Code</Label>
              <Input {...form.register("hs_code")} className="mt-1" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pricing */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Calculator className="h-5 w-5" />Pricing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            {(["operations", "bundling", "detail"] as const).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => form.setValue("cost_type", type)}
                className={cn(
                  "p-4 rounded-lg border-2 text-center capitalize transition-all",
                  watchedValues.cost_type === type
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-muted hover:border-primary/50"
                )}
              >
                {type}
              </button>
            ))}
          </div>

          {(watchedValues.cost_type === "bundling" || watchedValues.cost_type === "operations") && (
            <div className="flex gap-4">
              <div className="w-32">
                <Label>Currency</Label>
                <Select value={watchedValues.currency} onValueChange={(v) => form.setValue("currency", v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="IDR">IDR</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="SGD">SGD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label>Total Cost *</Label>
                <Input type="number" step="0.01" {...form.register("base_cost", { valueAsNumber: true })} className="mt-1 font-mono text-lg" />
              </div>
            </div>
          )}

          {watchedValues.cost_type === "detail" && (
            <div className="space-y-3">
              {costDetails.map((item, index) => (
                <div key={index} className="grid grid-cols-12 gap-2 items-end p-3 bg-muted/50 rounded-lg">
                  <div className="col-span-5">
                    <Label className="text-xs">Name</Label>
                    <Input
                      value={item.name}
                      onChange={(e) => {
                        const updated = [...costDetails];
                        updated[index] = { ...item, name: e.target.value };
                        setCostDetails(updated);
                      }}
                      className="mt-1"
                    />
                  </div>
                  <div className="col-span-3">
                    <Label className="text-xs">Amount</Label>
                    <Input
                      type="number"
                      value={item.amount || ""}
                      onChange={(e) => {
                        const updated = [...costDetails];
                        updated[index] = { ...item, amount: parseFloat(e.target.value) || 0 };
                        setCostDetails(updated);
                      }}
                      className="mt-1 font-mono"
                    />
                  </div>
                  <div className="col-span-3">
                    <Label className="text-xs">Unit</Label>
                    <Input
                      value={item.unit || ""}
                      onChange={(e) => {
                        const updated = [...costDetails];
                        updated[index] = { ...item, unit: e.target.value };
                        setCostDetails(updated);
                      }}
                      className="mt-1"
                    />
                  </div>
                  <div className="col-span-1">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => setCostDetails(costDetails.filter((_, i) => i !== index))}
                      className="text-red-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                onClick={() => setCostDetails([...costDetails, { name: "", amount: 0, unit: "Per Shipment" }])}
              >
                <Plus className="h-4 w-4 mr-2" />Add Item
              </Button>
            </div>
          )}

          <Separator />

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label>Margin Type</Label>
                <div className="flex gap-2 mt-2">
                  {(["percentage", "fixed"] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => form.setValue("margin_type", type)}
                      className={cn(
                        "px-4 py-2 rounded-lg border-2 capitalize",
                        watchedValues.margin_type === type
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-muted"
                      )}
                    >
                      {type === "percentage" ? <Percent className="h-4 w-4 inline mr-2" /> : <DollarSign className="h-4 w-4 inline mr-2" />}
                      {type}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <Label>Margin Value</Label>
                <Input type="number" step="0.01" {...form.register("margin_value", { valueAsNumber: true })} className="mt-1" />
              </div>
            </div>

            <div className="bg-primary/10 rounded-xl p-6 space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Cost</span>
                <span className="font-mono">{formatCurrency(getTotalCost(), watchedValues.currency)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Margin</span>
                <span className="font-mono text-green-600">+{formatCurrency(getSellingRate() - getTotalCost(), watchedValues.currency)}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Selling Rate</span>
                <span className="font-mono text-primary">{formatCurrency(getSellingRate(), watchedValues.currency)}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Terms */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" />Terms</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Validity (Days)</Label>
              <Input type="number" min={1} {...form.register("validity_days", { valueAsNumber: true })} className="mt-1" />
            </div>
            <div>
              <Label>Payment Terms</Label>
              <Input {...form.register("payment_terms")} className="mt-1" />
            </div>
          </div>
          <div>
            <Label>Included Services</Label>
            <Textarea {...form.register("included_services")} rows={2} className="mt-1" />
          </div>
          <div>
            <Label>Excluded Services</Label>
            <Textarea {...form.register("excluded_services")} rows={2} className="mt-1" />
          </div>
          <div>
            <Label>Additional Notes</Label>
            <Textarea {...form.register("additional_notes")} rows={2} className="mt-1" />
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="flex justify-end gap-3 pt-6 border-t">
        <Button variant="outline" onClick={() => router.push(`/quotations/${quotationId}`)}>Cancel</Button>
        <Button onClick={handleSubmit} disabled={updateMutation.isPending}>
          {updateMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
          <Save className="h-4 w-4 mr-2" />Save Changes
        </Button>
      </div>
    </div>
  );
}
