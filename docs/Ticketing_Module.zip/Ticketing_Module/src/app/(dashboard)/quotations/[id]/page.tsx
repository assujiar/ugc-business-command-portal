"use client";

import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  Download,
  Send,
  Edit,
  Trash2,
  Mail,
  MessageCircle,
  MapPin,
  Package,
  User,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Ship,
  Plane,
  Truck,
  FileText,
  Building,
  Phone,
  Loader2,
  DollarSign,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useState } from "react";
import {
  useQuotation,
  useDeleteQuotation,
  useDownloadPDF,
  useSendQuotation,
  useUpdateQuotation,
  formatCurrency,
  formatDate,
  getStatusColor,
  getShipmentLabel,
  CostDetail,
} from "@/hooks/useQuotations";

// Status Icon
function StatusIcon({ status }: { status: string }) {
  const icons: Record<string, React.ReactNode> = {
    draft: <Clock className="h-4 w-4" />,
    sent: <Send className="h-4 w-4" />,
    accepted: <CheckCircle className="h-4 w-4" />,
    rejected: <XCircle className="h-4 w-4" />,
    expired: <AlertCircle className="h-4 w-4" />,
  };
  return <>{icons[status] || <Clock className="h-4 w-4" />}</>;
}

// Shipment Icon
function ShipmentIcon({ type, className }: { type: string; className?: string }) {
  const icons: Record<string, React.ReactNode> = {
    sea: <Ship className={className} />,
    air: <Plane className={className} />,
    land: <Truck className={className} />,
  };
  return <>{icons[type] || <Ship className={className} />}</>;
}

export default function QuotationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const quotationId = params.id as string;

  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showStatusDialog, setShowStatusDialog] = useState<string | null>(null);

  // Queries & Mutations
  const { data, isLoading, error } = useQuotation(quotationId);
  const deleteMutation = useDeleteQuotation();
  const downloadMutation = useDownloadPDF();
  const sendMutation = useSendQuotation();
  const updateMutation = useUpdateQuotation();

  const quotation = data?.data;

  // Handlers
  const handleDelete = async () => {
    try {
      await deleteMutation.mutateAsync(quotationId);
      toast.success("Quotation deleted successfully");
      router.push("/quotations");
    } catch (error: any) {
      toast.error(error.message || "Failed to delete quotation");
    }
  };

  const handleDownload = async () => {
    if (!quotation) return;
    try {
      await downloadMutation.mutateAsync({ id: quotationId, quotationNumber: quotation.quotation_number });
      toast.success("PDF downloaded successfully");
    } catch (error) {
      toast.error("Failed to download PDF");
    }
  };

  const handleSend = async (method: "email" | "whatsapp") => {
    try {
      const result = await sendMutation.mutateAsync({ id: quotationId, method });
      if (method === "email") {
        toast.success(`Quotation sent to ${result.recipient}`);
      } else {
        toast.success("Opening WhatsApp...");
      }
      setShowSendDialog(false);
    } catch (error: any) {
      toast.error(error.message || `Failed to send via ${method}`);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    try {
      await updateMutation.mutateAsync({ id: quotationId, data: { status: newStatus as any } });
      toast.success(`Status updated to ${newStatus}`);
      setShowStatusDialog(null);
    } catch (error: any) {
      toast.error(error.message || "Failed to update status");
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-40" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 space-y-6">
            <Skeleton className="h-48" />
            <Skeleton className="h-64" />
          </div>
          <Skeleton className="h-96" />
        </div>
      </div>
    );
  }

  // Error state
  if (error || !quotation) {
    return (
      <Card>
        <CardContent className="py-16 text-center">
          <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Quotation Not Found</h2>
          <p className="text-muted-foreground mb-4">The quotation does not exist or has been deleted.</p>
          <Button onClick={() => router.push("/quotations")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Quotations
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/quotations")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold font-mono">{quotation.quotation_number}</h1>
              <Badge className={`gap-1 ${getStatusColor(quotation.status)}`}>
                <StatusIcon status={quotation.status} />
                <span className="capitalize">{quotation.status}</span>
              </Badge>
            </div>
            <p className="text-muted-foreground">Created on {formatDate(quotation.created_at)}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleDownload} disabled={downloadMutation.isPending}>
            {downloadMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Download className="h-4 w-4 mr-2" />}
            Download PDF
          </Button>
          <Button variant="outline" onClick={() => setShowSendDialog(true)}>
            <Send className="h-4 w-4 mr-2" />
            Send
          </Button>
          <Button variant="outline" onClick={() => router.push(`/quotations/${quotationId}/edit`)}>
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <Button variant="destructive" onClick={() => setShowDeleteDialog(true)} disabled={quotation.status === "accepted"}>
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="col-span-2 space-y-6">
          {/* Route Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShipmentIcon type={quotation.shipment_type} className="h-5 w-5" />
                {getShipmentLabel(quotation.shipment_type)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-6">
                {/* Origin */}
                <div className="flex-1 bg-green-50 dark:bg-green-950/30 rounded-xl p-4 border border-green-200 dark:border-green-900">
                  <div className="flex items-center gap-2 text-green-600 mb-2">
                    <MapPin className="h-4 w-4" />
                    <span className="text-sm font-medium">Origin</span>
                  </div>
                  <p className="font-semibold text-lg">
                    {quotation.origin_city}{quotation.origin_country ? `, ${quotation.origin_country}` : ""}
                  </p>
                  {quotation.origin_port && (
                    <p className="text-sm text-muted-foreground mt-1">{quotation.origin_port}</p>
                  )}
                </div>

                <div className="text-3xl text-muted-foreground">→</div>

                {/* Destination */}
                <div className="flex-1 bg-red-50 dark:bg-red-950/30 rounded-xl p-4 border border-red-200 dark:border-red-900">
                  <div className="flex items-center gap-2 text-red-600 mb-2">
                    <MapPin className="h-4 w-4" />
                    <span className="text-sm font-medium">Destination</span>
                  </div>
                  <p className="font-semibold text-lg">
                    {quotation.destination_city}{quotation.destination_country ? `, ${quotation.destination_country}` : ""}
                  </p>
                  {quotation.destination_port && (
                    <p className="text-sm text-muted-foreground mt-1">{quotation.destination_port}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                <div>
                  <span className="text-sm text-muted-foreground">Incoterm</span>
                  <p className="font-medium">{quotation.incoterm || "FOB"}</p>
                </div>
                {quotation.container_type && (
                  <div>
                    <span className="text-sm text-muted-foreground">Container</span>
                    <p className="font-medium">{quotation.container_quantity || 1}× {quotation.container_type}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Cargo Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Cargo Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg mb-4">{quotation.cargo_description}</p>
              <div className="grid grid-cols-4 gap-4">
                {quotation.quantity && (
                  <div>
                    <span className="text-sm text-muted-foreground">Quantity</span>
                    <p className="font-medium">{quotation.quantity} {quotation.unit_of_measure || "units"}</p>
                  </div>
                )}
                {quotation.weight_kg && (
                  <div>
                    <span className="text-sm text-muted-foreground">Weight</span>
                    <p className="font-medium">{quotation.weight_kg} KG</p>
                  </div>
                )}
                {quotation.volume_cbm && (
                  <div>
                    <span className="text-sm text-muted-foreground">Volume</span>
                    <p className="font-medium">{quotation.volume_cbm} CBM</p>
                  </div>
                )}
                {quotation.hs_code && (
                  <div>
                    <span className="text-sm text-muted-foreground">HS Code</span>
                    <p className="font-medium">{quotation.hs_code}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Cost Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Cost Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-sm text-muted-foreground">Cost Type:</span>
                <Badge variant="outline" className="capitalize">{quotation.cost_type}</Badge>
              </div>

              {quotation.cost_type === "detail" && quotation.cost_details && Array.isArray(quotation.cost_details) ? (
                <div className="space-y-2 mb-4">
                  {(quotation.cost_details as CostDetail[]).map((item, index) => (
                    <div key={index} className="flex items-center justify-between py-2 border-b last:border-0">
                      <div>
                        <span className="font-medium">{item.name}</span>
                        {item.unit && <span className="text-sm text-muted-foreground ml-2">({item.unit})</span>}
                      </div>
                      <span className="font-mono">{formatCurrency(item.amount, quotation.currency)}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-between py-2 mb-4">
                  <span className="font-medium">
                    {quotation.cost_type === "operations" ? "Operations Rate" : "Bundled Rate"}
                  </span>
                  <span className="font-mono">{formatCurrency(quotation.base_cost || 0, quotation.currency)}</span>
                </div>
              )}

              <Separator className="my-4" />

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Total Cost</span>
                  <span className="font-mono">{formatCurrency(quotation.base_cost || 0, quotation.currency)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">
                    Margin ({quotation.margin_type === "percentage" ? `${quotation.margin_value}%` : "Fixed"})
                  </span>
                  <span className="font-mono text-green-600">
                    +{formatCurrency((quotation.selling_rate || 0) - (quotation.base_cost || 0), quotation.currency)}
                  </span>
                </div>
                <Separator />
                <div className="flex items-center justify-between text-lg font-bold">
                  <span>Selling Rate</span>
                  <span className="font-mono text-primary">{formatCurrency(quotation.selling_rate || 0, quotation.currency)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Terms */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Terms & Conditions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm text-muted-foreground">Validity</span>
                  <p className="font-medium">{quotation.validity_days || 14} days (until {formatDate(quotation.valid_until || "")})</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Payment Terms</span>
                  <p className="font-medium">{quotation.payment_terms || "30 days from invoice date"}</p>
                </div>
              </div>

              {quotation.included_services && (
                <div className="p-3 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
                  <span className="text-sm text-green-600 font-medium">✓ Included Services</span>
                  <p className="mt-1 text-sm">{quotation.included_services}</p>
                </div>
              )}

              {quotation.excluded_services && (
                <div className="p-3 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900">
                  <span className="text-sm text-red-600 font-medium">✗ Excluded Services</span>
                  <p className="mt-1 text-sm">{quotation.excluded_services}</p>
                </div>
              )}

              {quotation.additional_notes && (
                <div>
                  <span className="text-sm text-muted-foreground font-medium">Additional Notes</span>
                  <p className="mt-1">{quotation.additional_notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Customer Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Customer
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {quotation.customer_company && (
                <div className="flex items-start gap-3">
                  <Building className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{quotation.customer_company}</p>
                  </div>
                </div>
              )}
              <div className="flex items-start gap-3">
                <User className="h-4 w-4 mt-1 text-muted-foreground" />
                <div>
                  <p className="font-medium">{quotation.customer_name}</p>
                  <p className="text-sm text-muted-foreground">Contact Person</p>
                </div>
              </div>
              {quotation.customer_email && (
                <div className="flex items-start gap-3">
                  <Mail className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{quotation.customer_email}</p>
                    <p className="text-sm text-muted-foreground">Email</p>
                  </div>
                </div>
              )}
              {quotation.customer_phone && (
                <div className="flex items-start gap-3">
                  <Phone className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{quotation.customer_phone}</p>
                    <p className="text-sm text-muted-foreground">Phone</p>
                  </div>
                </div>
              )}
              {quotation.customer_whatsapp && quotation.customer_whatsapp !== quotation.customer_phone && (
                <div className="flex items-start gap-3">
                  <MessageCircle className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{quotation.customer_whatsapp}</p>
                    <p className="text-sm text-muted-foreground">WhatsApp</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Update Status */}
          <Card>
            <CardHeader>
              <CardTitle>Update Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {["draft", "sent", "accepted", "rejected", "expired"].map((status) => (
                <Button
                  key={status}
                  variant={quotation.status === status ? "default" : "outline"}
                  className="w-full justify-start capitalize"
                  onClick={() => quotation.status !== status && setShowStatusDialog(status)}
                  disabled={quotation.status === status || updateMutation.isPending}
                >
                  <StatusIcon status={status} />
                  <span className="ml-2">{status}</span>
                </Button>
              ))}
            </CardContent>
          </Card>

          {/* Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3">
                <Calendar className="h-4 w-4 mt-1 text-muted-foreground" />
                <div>
                  <p className="text-sm">Created</p>
                  <p className="text-xs text-muted-foreground">{formatDate(quotation.created_at)}</p>
                </div>
              </div>
              {quotation.sent_at && (
                <div className="flex items-start gap-3">
                  <Send className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="text-sm">Sent via {quotation.sent_via === "email" ? "Email" : "WhatsApp"}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(quotation.sent_at)}</p>
                  </div>
                </div>
              )}
              {quotation.updated_at !== quotation.created_at && (
                <div className="flex items-start gap-3">
                  <Edit className="h-4 w-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="text-sm">Last Updated</p>
                    <p className="text-xs text-muted-foreground">{formatDate(quotation.updated_at)}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Delete Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Quotation</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this quotation? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Send Dialog */}
      <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send Quotation</DialogTitle>
            <DialogDescription>Choose how to send quotation {quotation.quotation_number}</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <Button
              variant="outline"
              className="h-24 flex flex-col items-center justify-center gap-2"
              onClick={() => handleSend("email")}
              disabled={sendMutation.isPending || !quotation.customer_email}
            >
              {sendMutation.isPending ? <Loader2 className="h-8 w-8 animate-spin" /> : <Mail className="h-8 w-8" />}
              <span>Send via Email</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex flex-col items-center justify-center gap-2"
              onClick={() => handleSend("whatsapp")}
              disabled={sendMutation.isPending || (!quotation.customer_whatsapp && !quotation.customer_phone)}
            >
              {sendMutation.isPending ? <Loader2 className="h-8 w-8 animate-spin" /> : <MessageCircle className="h-8 w-8" />}
              <span>Send via WhatsApp</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Status Change Dialog */}
      <AlertDialog open={!!showStatusDialog} onOpenChange={() => setShowStatusDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Change Status</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to change the status to "{showStatusDialog}"?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => showStatusDialog && handleStatusChange(showStatusDialog)}>
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
