﻿import CreateQuotationForm from "@/components/quotations/create-quotation-form";

export default function Page() {
  return <CreateQuotationForm />;
}
