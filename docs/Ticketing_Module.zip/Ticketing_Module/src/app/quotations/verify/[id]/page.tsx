import { createAdminClient } from "@/lib/supabase/admin";
import { notFound } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Calendar, Building2, User, FileText, MapPin, Package } from "lucide-react";

interface PageProps {
  params: Promise<{ id: string }>;
}

function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function formatCurrency(amount: number, currency: string = "IDR"): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export default async function QuotationVerifyPage({ params }: PageProps) {
  const { id } = await params;
  const supabase = createAdminClient();

  const { data, error } = await (supabase as any)
    .from("quotations")
    .select("*, creator:users!quotations_created_by_fkey(full_name, email)")
    .eq("id", id)
    .single();

  if (error || !data) {
    notFound();
  }

  const quotation = data as any;
  const isExpired = quotation.valid_until ? new Date(quotation.valid_until) < new Date() : false;
  const isValid = !isExpired && quotation.status !== "rejected";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader className="text-center border-b border-white/10 pb-6">
          {/* Logo */}
          <div className="flex justify-center mb-4">
            <div className="bg-[#ff4600] rounded-lg px-4 py-2">
              <span className="text-white font-bold text-xl">UGC</span>
              <span className="text-white/80 text-xs ml-1">LOGISTICS</span>
            </div>
          </div>
          
          <CardTitle className="text-white text-lg">Quotation Verification</CardTitle>
          
          {/* Status Badge */}
          <div className="mt-4">
            {isValid ? (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2 text-base">
                <CheckCircle2 className="h-5 w-5 mr-2" />
                Valid Document
              </Badge>
            ) : (
              <Badge className="bg-red-500/20 text-red-400 border-red-500/30 px-4 py-2 text-base">
                <XCircle className="h-5 w-5 mr-2" />
                {isExpired ? "Expired" : "Invalid"}
              </Badge>
            )}
          </div>
        </CardHeader>

        <CardContent className="pt-6 space-y-4">
          {/* Quotation Number */}
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <div className="p-2 bg-[#ff4600]/20 rounded-lg">
              <FileText className="h-5 w-5 text-[#ff4600]" />
            </div>
            <div>
              <p className="text-white/60 text-xs">Quotation Number</p>
              <p className="text-white font-bold text-lg font-mono">{quotation.quotation_number}</p>
            </div>
          </div>

          {/* Customer */}
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Building2 className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <p className="text-white/60 text-xs">Customer</p>
              <p className="text-white font-medium">{quotation.customer_company || quotation.customer_name}</p>
              {quotation.customer_company && quotation.customer_name && (
                <p className="text-white/60 text-sm">Attn: {quotation.customer_name}</p>
              )}
            </div>
          </div>

          {/* Route */}
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <MapPin className="h-5 w-5 text-purple-400" />
            </div>
            <div>
              <p className="text-white/60 text-xs">Route</p>
              <p className="text-white font-medium">
                {quotation.origin_city}, {quotation.origin_country} → {quotation.destination_city}, {quotation.destination_country}
              </p>
            </div>
          </div>

          {/* Amount */}
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <Package className="h-5 w-5 text-green-400" />
            </div>
            <div>
              <p className="text-white/60 text-xs">Total Rate</p>
              <p className="text-white font-bold text-lg">
                {formatCurrency(quotation.selling_rate || 0, quotation.currency || "IDR")}
              </p>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
              <div className="p-2 bg-yellow-500/20 rounded-lg">
                <Calendar className="h-4 w-4 text-yellow-400" />
              </div>
              <div>
                <p className="text-white/60 text-xs">Issue Date</p>
                <p className="text-white text-sm">{formatDate(quotation.created_at)}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
              <div className={`p-2 rounded-lg ${isExpired ? "bg-red-500/20" : "bg-green-500/20"}`}>
                <Calendar className={`h-4 w-4 ${isExpired ? "text-red-400" : "text-green-400"}`} />
              </div>
              <div>
                <p className="text-white/60 text-xs">Valid Until</p>
                <p className={`text-sm ${isExpired ? "text-red-400" : "text-white"}`}>
                  {quotation.valid_until ? formatDate(quotation.valid_until) : "-"}
                </p>
              </div>
            </div>
          </div>

          {/* Creator */}
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <div className="p-2 bg-cyan-500/20 rounded-lg">
              <User className="h-5 w-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-white/60 text-xs">Issued By</p>
              <p className="text-white font-medium">{(quotation as any).creator?.full_name || "Sales Team"}</p>
              <p className="text-white/60 text-xs">Sales & Commercial Department</p>
            </div>
          </div>

          {/* Footer Note */}
          <div className="pt-4 border-t border-white/10 text-center">
            <p className="text-white/40 text-xs">
              This document was verified on {formatDate(new Date())}
            </p>
            <p className="text-white/40 text-xs mt-1">
              PT Utama Globalindo Cargo | We Care What We Deliver
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export async function generateMetadata({ params }: PageProps) {
  const { id } = await params;
  return {
    title: `Verify Quotation | UGC Logistics`,
    description: `Verify quotation document authenticity`,
  };
}